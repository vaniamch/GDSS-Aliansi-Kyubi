import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('./Aplikasi/dist', import.meta.url));
const port = 4173;
const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.pdf': 'application/pdf',
  '.csv': 'text/csv; charset=utf-8',
};

const server = createServer(async (request, response) => {
  const pathname = new URL(request.url, 'http://127.0.0.1').pathname;
  if (pathname === '/api/state') {
    // The standalone demo stores changes in the current browser.
    response.writeHead(request.method === 'GET' ? 200 : 204, { 'Content-Type': 'application/json' });
    response.end(request.method === 'GET' ? '{"state":null}' : undefined);
    return;
  }

  try {
    const relative = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
    const file = resolve(root, relative);
    if (!file.startsWith(root + sep)) throw new Error('Di luar folder demo');
    const bytes = await readFile(file);
    response.writeHead(200, { 'Content-Type': types[extname(file)] ?? 'application/octet-stream' });
    response.end(bytes);
  } catch {
    response.writeHead(404).end('File demo tidak ditemukan.');
  }
});

server.on('error', (error) => {
  console.error(error.code === 'EADDRINUSE' ? 'Port 4173 sudah digunakan. Tutup server demo lain dan coba lagi.' : error.message);
  process.exitCode = 1;
});
server.listen(port, '127.0.0.1', () => {
  console.log(`GDSS Aliansi Kyubi siap. Buka http://127.0.0.1:${port} di browser.`);
});
