# Demo GDSS Aliansi Kyubi

## Menjalankan demo

1. Ekstrak seluruh ZIP. Buka terminal di folder yang berisi `JALANKAN-DEMO.mjs`.
2. Gunakan Node.js 22 atau lebih baru dan jalankan `node JALANKAN-DEMO.mjs`.
3. Buka [127.0.0.1:4173](http://127.0.0.1:4173) di browser. Versi demo sudah dibangun dan dapat dijalankan tanpa `npm install` atau koneksi internet. Biarkan terminal terbuka selama demo.

Masuk dengan `admin` / `admin123` (input nilai) atau `dm1` / `dm1123` (halaman khusus DM 1 untuk mengisi penilaian BWM sendiri). Admin mengetik nilai langsung di tabel **Data Alternatif** (Mode Input Nilai). Akun DM 2 dan DM 3 memakai pola yang sama. Admin tidak dapat membuka Halaman DM dan tidak dapat mengubah penilaian BWM Jeno, James, atau Karina; penilaian itu hanya bisa diisi lewat akun DM masing-masing (Admin hanya meninjau di Linear BWM Solver). Buka Admin dan DM 1 di dua tab untuk memperlihatkan pembaruan real-time. Perubahan di mode demo tersimpan di browser yang digunakan. Jika sebelumnya pernah mengimpor data lain, pilih **Data Alternatif → Data Penelitian 62 Kab.** untuk membuka dataset tugas lagi.

## Alur presentasi 3–4 menit

1. **Beranda.** Jelaskan bahwa perencana kabupaten perlu menentukan daerah yang diprioritaskan ketika sumber daya terbatas. Tampilkan 62 alternatif dari workbook, delapan kriteria, dan hasil utama **Nduga, skor MARCOS 0,7664**.
2. **Linear BWM Solver → Agregasi Bobot.** Tunjukkan tiga persona Jeno, James, dan Karina, cara BO dan OW membentuk bobot, dan cara bobot digabung dengan λ 0,40 / 0,30 / 0,30. Bobot gabungan C1 adalah 0,2063.
3. **MARCOS Solver → Hasil Ranking.** Buka satu tahap perhitungan, lalu tampilkan lima besar. Untuk Nduga, tunjukkan C2 sebagai kriteria paling kritis dan akses serta beasiswa pendidikan sebagai program yang disarankan.
4. **Analisis & Konsensus.** Tunjukkan Spearman MARCOS–TOPSIS 0,9423 dan Kendall’s W 0,9378. Jelaskan bahwa korelasi SAW 1,0000 berasal dari normalisasi dan bobot yang sama. Nduga tetap di urutan pertama untuk semua skenario S0–S7.
5. **Excel.** Buka `Workbook/Aliansi Kyubi Project 2 - Revisi Sensitivitas.xlsx` pada sheet `Sensitivitas`. Tunjukkan bahwa `Z6:Z13` berisi 0, 11, 19, 7, 13, 4, 6, 6.

## Jika diminta memperagakan impor

Pilih **Data Alternatif → Import Excel / CSV** dan pilih workbook revisi dalam ZIP. Aplikasi membaca sheet `Data_3T`. Setelah impor, ranking MARCOS langsung diperbarui otomatis. Bandingkan kembali lima besar dan skor Nduga dengan workbook.

## Cakupan dan bahan rujukan

- Cakupan kabupaten mengikuti daftar daerah tertinggal periode 2020–2024. Tahun indikator tidak tercantum di dataset, dan tiga pengambil keputusan adalah persona simulasi.
- `Referensi/Laporan SPK Grup Aliansi Kyubi.docx` berisi metodologi dan hasil pembanding. Perbaikan aplikasi mencakup pemuatan data awal, impor Excel, dan validasi nilai. Perbaikan workbook mencakup rumus pergeseran peringkat.
- Untuk melanjutkan pengembangan aplikasi, ikuti `Aplikasi/README.md`.
