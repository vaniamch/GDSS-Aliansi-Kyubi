# GDSS Aliansi Kyubi

Aplikasi Linear BWM dan MARCOS untuk menentukan prioritas intervensi pada 62 kabupaten daerah tertinggal. Preset awal memakai matriks keputusan dari sheet `Data_3T` dalam workbook Aliansi Kyubi. Cakupan penetapan wilayah adalah 2020–2024. Dataset tidak mencantumkan tahun pengukuran indikator.

## Menjalankan aplikasi

Gunakan Node.js 22.12 atau lebih baru. Ekstrak ZIP, buka terminal di folder proyek, lalu jalankan:

```bash
npm ci
npm run dev
```

Buka [localhost:3000](http://localhost:3000). Beranda menampilkan Nduga di peringkat pertama dengan skor MARCOS 0,7664. Untuk kembali ke pengaturan awal penelitian dari data tersimpan, buka **Data Alternatif → Data Penelitian 62 Kab.**

## Akun multi-user

| Akun | Username / password | Hak akses |
|---|---|---|
| Administrator | `admin` / `admin123` | Satu-satunya akun yang dapat menginput/mengubah nilai data (ketik langsung di tabel **Data Alternatif → Mode Input Nilai**), kriteria, λ, dan meninjau (hanya baca) penilaian BWM semua DM. **Tidak dapat** membuka Halaman DM maupun mengubah penilaian BWM (kriteria Best/Worst, BO, OW) milik Jeno, James, atau Karina |
| DM 1 (Jeno) | `dm1` / `dm1123` | Halaman khusus DM 1: mengisi penilaian Linear BWM miliknya sendiri, melihat bobot, CRI, dan ranking real-time, serta menulis catatan |
| DM 2 (James) | `dm2` / `dm2123` | Sama seperti DM 1 untuk DM 2 |
| DM 3 (Karina) | `dm3` / `dm3123` | Sama seperti DM 1 untuk DM 3 |

Penilaian BWM tiap DM hanya dapat diisi dan diubah oleh akun DM pemiliknya sendiri. Akun DM hanya dapat membuka Halaman Saya, Beranda, Hasil Ranking, Analisis, Diskusi, dan Panduan. Halaman pengelolaan data tetap khusus Admin.

Akun DM dibuat otomatis mengikuti urutan Decision Maker. Sesi tersimpan per tab browser, jadi Admin dan DM dapat dibuka berdampingan. Perubahan Admin langsung tampil di tab DM. Pada `npm run dev`, perubahan juga tersinkron antar-perangkat melalui server.

## Impor dan verifikasi

- Impor workbook tugas melalui **Data Alternatif → Import Excel / CSV**. Aplikasi membaca `Data_3T` mulai dari header di baris 4. Untuk CSV atau Excel umum, gunakan header `Kabupaten`, `Provinsi`, dan kode kriteria aktif. C5 dan C6 harus berupa defisit akses.
- Seluruh perhitungan berjalan **real-time**: setiap perubahan data, kriteria, λ, atau penilaian BWM langsung memperbarui Linear BWM Solver, agregasi bobot, MARCOS, ranking, dan analisis tanpa tombol hitung ulang.
- Jalankan pemeriksaan bawaan dengan `npm run verify`. Untuk membandingkan hasil dengan workbook, jalankan `npm run verify -- "path/ke/Aliansi Kyubi Project 2.xlsx"`.

[Proyek awal di Google AI Studio](https://ai.studio/apps/0c4c62fc-3bff-4676-a26a-24b31e216362)
