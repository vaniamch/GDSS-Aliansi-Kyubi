import React, { useState } from 'react';
import { AlertTriangle, Calculator, Eye, X } from 'lucide-react';
import { AutoCalcBadge } from '../components/AccessBadges';
import { validateDecisionMatrix } from '../engine/mcdmEngine';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import type { MARCOSAlternativeRow, PageId } from '../types/gdss';

type MarcosTab =
  | 'matrix'
  | 'aai_ai'
  | 'normalized'
  | 'weighted'
  | 'si'
  | 'ki'
  | 'utility'
  | 'ranking';

const TABS: Array<{ id: MarcosTab; label: string }> = [
  { id: 'matrix', label: '1. Matriks Keputusan' },
  { id: 'aai_ai', label: '2. AI dan AAI' },
  { id: 'normalized', label: '3. Matriks Normalisasi' },
  { id: 'weighted', label: '4. Matriks Terbobot' },
  { id: 'si', label: '5. Nilai Si' },
  { id: 'ki', label: '6. Ki- dan Ki+' },
  { id: 'utility', label: '7. Fungsi Utilitas' },
  { id: 'ranking', label: '8. Ranking' },
];

interface MarcosPageProps {
  onNavigate: (page: PageId) => void;
}

export function MarcosPage({ onNavigate }: MarcosPageProps) {
  const {
    state,
    activeCriteria,
    isAggregationFresh,
    isMarcosFresh,
  } = useGDSS();

  const [activeTab, setActiveTab] = useState<MarcosTab>('ranking');
  const [detailRow, setDetailRow] = useState<MARCOSAlternativeRow | null>(null);

  const res = state.marcosResult;
  // MARCOS dihitung otomatis; bila belum bisa dihitung, tampilkan alasan validasinya.
  const errors =
    isAggregationFresh && !isMarcosFresh && state.groupAggregation
      ? validateDecisionMatrix(state.alternatives, activeCriteria, state.groupAggregation.weights)
      : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="MARCOS Method Solver"
        description="Measurement of Alternatives and Ranking according to COmpromise Solution (Stević et al., 2020). Seluruh 8 tahap antara ditampilkan secara transparan dari matriks keputusan aktual."
        statusLabel={
          isMarcosFresh
            ? `Perhitungan MARCOS mutakhir (${res?.rows.length ?? 0} kabupaten)`
            : res?.stale
              ? 'Hasil MARCOS kedaluwarsa — periksa validasi input di bawah'
              : 'Dihitung otomatis setelah Agregasi Bobot tersedia'
        }
        statusTone={isMarcosFresh ? 'ok' : 'warning'}
        actions={
          <AutoCalcBadge label="MARCOS real-time" />
        }
      />

      {/* Input Summary Before Running */}
      <div className="rounded-xl border border-slate-200 bg-white p-4">
        <div className="text-xs font-semibold text-slate-800 mb-3">
          Ringkasan Input MARCOS
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs">
          <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
            <div className="text-slate-500">Matriks Keputusan</div>
            <div className="mt-1 font-mono font-semibold text-slate-900 tabular-nums">
              {state.alternatives.length} Alternatif × {activeCriteria.length} Kriteria
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
            <div className="text-slate-500">Bobot Kelompok (Agregasi)</div>
            <div
              className={`mt-1 font-semibold ${
                isAggregationFresh ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {isAggregationFresh ? 'Valid & Mutakhir (ΣW = 1,0000)' : 'Belum Siap / Kedaluwarsa'}
            </div>
          </div>
          <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
            <div className="text-slate-500">Tipe Kriteria Aktif</div>
            <div className="mt-1 font-mono text-slate-800 tabular-nums">
              {activeCriteria.filter((c) => c.type === 'Benefit').length} Benefit ·{' '}
              {activeCriteria.filter((c) => c.type === 'Cost').length} Cost
            </div>
          </div>
        </div>

        {!isAggregationFresh && (
          <div className="mt-3 flex items-center justify-between gap-3 rounded-lg border border-amber-200 bg-amber-50 px-3.5 py-2.5 text-xs text-amber-900">
            <span>
              Agregasi Bobot Kelompok harus valid dan mutakhir agar MARCOS dapat dihitung otomatis.
            </span>
            <button
              type="button"
              onClick={() => onNavigate('agregasi')}
              className="rounded-md bg-amber-700 px-3 py-1 text-xs font-semibold text-white hover:bg-amber-800 whitespace-nowrap"
            >
              Buka Agregasi Bobot
            </button>
          </div>
        )}
      </div>

      {errors.length > 0 && (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-xs text-rose-900 space-y-1.5">
          <div className="font-semibold flex items-center gap-1.5">
            <AlertTriangle className="h-4 w-4 text-rose-600" />
            <span>Validasi MARCOS Gagal</span>
          </div>
          {errors.map((err, i) => (
            <div key={i}>• {err}</div>
          ))}
        </div>
      )}

      {!res ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <Calculator className="mx-auto h-9 w-9 text-slate-300" />
          <p className="mt-3 text-sm font-medium text-slate-700">
            Perhitungan MARCOS Belum Dijalankan
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Seluruh tabel antara dan ranking akhir muncul otomatis setelah bobot kelompok
            tersedia.
          </p>
        </div>
      ) : (
        <>
          {res.stale && (
            <div className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
              <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
              <span>
                Hasil di bawah ini kedaluwarsa karena input saat ini belum valid. Perbaiki input agar
                seluruh angka diperbarui otomatis.
              </span>
            </div>
          )}

          {/* 8 Intermediate Tabs */}
          <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white p-1.5">
            <div className="flex items-center gap-1 min-w-max">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`rounded-lg px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'bg-[#0B1528] text-white'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
            {activeTab === 'aai_ai' ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                      <th className="py-3 px-4 font-medium">Titik Acuan</th>
                      {activeCriteria.map((c) => (
                        <th key={c.id} className="py-3 px-3 font-medium text-right whitespace-nowrap">
                          {c.code} ({c.type})
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                    <tr className="bg-rose-50/40">
                      <td className="py-3 px-4 font-sans font-semibold text-rose-900">
                        AAI (Anti-Ideal)
                      </td>
                      {activeCriteria.map((c) => (
                        <td key={c.id} className="py-3 px-3 text-right text-slate-800">
                          {(res.aai[c.id] ?? 0).toLocaleString('id-ID', {
                            maximumFractionDigits: 4,
                          })}
                        </td>
                      ))}
                    </tr>
                    <tr className="bg-blue-50/40">
                      <td className="py-3 px-4 font-sans font-semibold text-blue-900">
                        AI (Ideal)
                      </td>
                      {activeCriteria.map((c) => (
                        <td key={c.id} className="py-3 px-3 text-right text-slate-900 font-semibold">
                          {(res.ai[c.id] ?? 0).toLocaleString('id-ID', {
                            maximumFractionDigits: 4,
                          })}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-sans text-slate-600">Normalisasi AAI (n_AAI)</td>
                      {activeCriteria.map((c) => (
                        <td key={c.id} className="py-3 px-3 text-right text-slate-600">
                          {(res.nAai[c.id] ?? 0).toFixed(4)}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-sans text-slate-600">Normalisasi AI (n_AI)</td>
                      {activeCriteria.map((c) => (
                        <td key={c.id} className="py-3 px-3 text-right text-slate-600">
                          {(res.nAi[c.id] ?? 0).toFixed(4)}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-sans text-slate-600">Terbobot AAI (v_AAI)</td>
                      {activeCriteria.map((c) => (
                        <td key={c.id} className="py-3 px-3 text-right text-slate-600">
                          {(res.vAai[c.id] ?? 0).toFixed(4)}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-sans text-slate-600">Terbobot AI (v_AI)</td>
                      {activeCriteria.map((c) => (
                        <td key={c.id} className="py-3 px-3 text-right text-slate-600">
                          {(res.vAi[c.id] ?? 0).toFixed(4)}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                  <tfoot>
                    <tr className="border-t border-slate-200 bg-slate-50 font-semibold text-xs">
                      <td className="py-3 px-4 text-slate-700" colSpan={activeCriteria.length + 1}>
                        S_AAI = <span className="font-mono">{res.sAai.toFixed(4)}</span> · S_AI ={' '}
                        <span className="font-mono">{res.sAi.toFixed(4)}</span>
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            ) : (
              <div className="overflow-x-auto max-h-[560px]">
                <table className="w-full text-left text-xs">
                  <thead className="sticky top-0 bg-slate-50 border-b border-slate-200 text-slate-600 z-10">
                    <tr>
                      <th className="py-3 px-3 font-medium">Kabupaten</th>
                      {(activeTab === 'matrix' ||
                        activeTab === 'normalized' ||
                        activeTab === 'weighted') &&
                        activeCriteria.map((c) => (
                          <th key={c.id} className="py-3 px-3 font-medium text-right whitespace-nowrap">
                            {c.code}
                          </th>
                        ))}
                      {activeTab === 'si' && (
                        <th className="py-3 px-3 font-medium text-right">
                          Sᵢ = Σvᵢⱼ (S_AAI={res.sAai.toFixed(4)}, S_AI={res.sAi.toFixed(4)})
                        </th>
                      )}
                      {activeTab === 'ki' && (
                        <>
                          <th className="py-3 px-3 font-medium text-right">Sᵢ</th>
                          <th className="py-3 px-3 font-medium text-right">Kᵢ⁻ = Sᵢ/S_AAI</th>
                          <th className="py-3 px-3 font-medium text-right">Kᵢ⁺ = Sᵢ/S_AI</th>
                        </>
                      )}
                      {activeTab === 'utility' && (
                        <>
                          <th className="py-3 px-3 font-medium text-right">f(Kᵢ⁻)</th>
                          <th className="py-3 px-3 font-medium text-right">f(Kᵢ⁺)</th>
                          <th className="py-3 px-3 font-medium text-right text-blue-800">
                            f(Kᵢ)
                          </th>
                        </>
                      )}
                      {activeTab === 'ranking' && (
                        <>
                          <th className="py-3 px-3 font-medium text-right">Rank</th>
                          <th className="py-3 px-3 font-medium">Provinsi</th>
                          <th className="py-3 px-3 font-medium text-right">Sᵢ</th>
                          <th className="py-3 px-3 font-medium text-right">f(Kᵢ)</th>
                          <th className="py-3 px-3 font-medium">Paling Kritis</th>
                        </>
                      )}
                      <th className="py-3 px-3 font-medium text-right">Detail</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {res.rows.map((r) => (
                      <tr key={r.alternativeId} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-medium text-slate-900 whitespace-nowrap">
                          {r.name}
                        </td>
                        {activeTab === 'matrix' &&
                          activeCriteria.map((c) => (
                            <td
                              key={c.id}
                              className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700"
                            >
                              {(r.rawValues[c.id] ?? 0).toLocaleString('id-ID', {
                                maximumFractionDigits: 2,
                              })}
                            </td>
                          ))}
                        {activeTab === 'normalized' &&
                          activeCriteria.map((c) => (
                            <td
                              key={c.id}
                              className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700"
                            >
                              {(r.normalizedValues[c.id] ?? 0).toFixed(4)}
                            </td>
                          ))}
                        {activeTab === 'weighted' &&
                          activeCriteria.map((c) => (
                            <td
                              key={c.id}
                              className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700"
                            >
                              {(r.weightedValues[c.id] ?? 0).toFixed(4)}
                            </td>
                          ))}
                        {activeTab === 'si' && (
                          <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-900">
                            {r.si.toFixed(4)}
                          </td>
                        )}
                        {activeTab === 'ki' && (
                          <>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                              {r.si.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-800">
                              {r.kMinus.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-800">
                              {r.kPlus.toFixed(4)}
                            </td>
                          </>
                        )}
                        {activeTab === 'utility' && (
                          <>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                              {r.fKMinus.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                              {r.fKPlus.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-blue-800">
                              {r.fK.toFixed(4)}
                            </td>
                          </>
                        )}
                        {activeTab === 'ranking' && (
                          <>
                            <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                              #{r.rank}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                              {r.province}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                              {r.si.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-blue-800">
                              {r.fK.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-3 whitespace-nowrap text-slate-700">
                              <span className="font-mono font-semibold">
                                {r.mostCriticalCriterionCode}
                              </span>{' '}
                              · {r.recommendedProgram}
                            </td>
                          </>
                        )}
                        <td className="py-2.5 px-3 text-right">
                          <button
                            type="button"
                            onClick={() => setDetailRow(r)}
                            className="inline-flex items-center gap-1 rounded px-2 py-1 text-xs font-medium text-blue-700 hover:bg-blue-50"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span>Rincian</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {/* Alternative Calculation Detail Modal */}
      {detailRow && res && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-xl border border-slate-200 bg-white p-6 shadow-xl space-y-5">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <div className="text-xs font-mono text-blue-700 font-semibold">
                  Peringkat #{detailRow.rank} · {detailRow.province}
                </div>
                <h2 className="font-display text-xl font-bold text-slate-900">
                  Detail Perhitungan MARCOS: {detailRow.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setDetailRow(null)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 text-xs">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-slate-500">Sᵢ (Jumlah Terbobot)</div>
                <div className="mt-1 font-mono text-base font-bold text-slate-900">
                  {detailRow.si.toFixed(4)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-slate-500">Kᵢ⁻ = Sᵢ / S_AAI</div>
                <div className="mt-1 font-mono text-base font-bold text-slate-900">
                  {detailRow.kMinus.toFixed(4)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-slate-500">Kᵢ⁺ = Sᵢ / S_AI</div>
                <div className="mt-1 font-mono text-base font-bold text-slate-900">
                  {detailRow.kPlus.toFixed(4)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-slate-500">f(Kᵢ⁻)</div>
                <div className="mt-1 font-mono text-base font-semibold text-slate-800">
                  {detailRow.fKMinus.toFixed(4)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3">
                <div className="text-slate-500">f(Kᵢ⁺)</div>
                <div className="mt-1 font-mono text-base font-semibold text-slate-800">
                  {detailRow.fKPlus.toFixed(4)}
                </div>
              </div>
              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3">
                <div className="text-blue-700 font-medium">Skor Akhir f(Kᵢ)</div>
                <div className="mt-1 font-mono text-lg font-bold text-blue-900">
                  {detailRow.fK.toFixed(4)}
                </div>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2 px-3 font-medium">Kriteria</th>
                    <th className="py-2 px-3 font-medium text-right">Nilai Asli (xᵢⱼ)</th>
                    <th className="py-2 px-3 font-medium text-right">AI</th>
                    <th className="py-2 px-3 font-medium text-right">Normalisasi (nᵢⱼ)</th>
                    <th className="py-2 px-3 font-medium text-right">Terbobot (vᵢⱼ)</th>
                    <th className="py-2 px-3 font-medium text-right">Keparahan Relatif</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                  {activeCriteria.map((c) => (
                    <tr key={c.id}>
                      <td className="py-2 px-3 font-sans">
                        <span className="font-mono font-semibold">{c.code}</span> · {c.name}{' '}
                        <span className="text-slate-400">({c.type})</span>
                      </td>
                      <td className="py-2 px-3 text-right">
                        {(detailRow.rawValues[c.id] ?? 0).toLocaleString('id-ID', {
                          maximumFractionDigits: 2,
                        })}
                      </td>
                      <td className="py-2 px-3 text-right text-slate-500">
                        {(res.ai[c.id] ?? 0).toLocaleString('id-ID', {
                          maximumFractionDigits: 2,
                        })}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {(detailRow.normalizedValues[c.id] ?? 0).toFixed(4)}
                      </td>
                      <td className="py-2 px-3 text-right font-semibold text-slate-900">
                        {(detailRow.weightedValues[c.id] ?? 0).toFixed(4)}
                      </td>
                      <td className="py-2 px-3 text-right">
                        {((detailRow.severityIndex[c.id] ?? 0) * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-xs text-slate-700">
              <span className="font-semibold">Kriteria Paling Kritis:</span>{' '}
              {detailRow.mostCriticalCriterionCode} — {detailRow.mostCriticalCriterionName} ·{' '}
              <span className="font-semibold">Program Disarankan:</span>{' '}
              {detailRow.recommendedProgram}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
