import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BarChart2,
  CheckCircle2,
  Database,
  Play,
  SlidersHorizontal,
  Trophy,
  Users,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import { STUDY_SOURCE } from '../data/demoPresets';
import type { PageId } from '../types/gdss';

interface BerandaPageProps {
  onNavigate: (page: PageId) => void;
}

export function BerandaPage({ onNavigate }: BerandaPageProps) {
  const {
    state,
    activeCriteria,
    activeDMs,
    lambdaSum,
    isLambdaValid,
    allDMsAssessed,
    allBWMFreshAndValid,
    isAggregationFresh,
    isMarcosFresh,
    runAllBWM,
    runGroupAggregation,
    runMARCOS,
    isAdmin,
  } = useGDSS();

  const assessedCount = activeDMs.filter((dm) => {
    const a = state.bwmAssessments[dm.id];
    return Boolean(a && a.bestCriterionId && a.worstCriterionId && a.bestCriterionId !== a.worstCriterionId);
  }).length;

  const bwmSolvedCount = activeDMs.filter((dm) => {
    const r = state.bwmResults[dm.id];
    return Boolean(r && !r.stale && !r.error && r.constraintCheckOk);
  }).length;

  const topAlt =
    isMarcosFresh && state.marcosResult?.rows[0] ? state.marcosResult.rows[0] : null;

  const weightChartData =
    isAggregationFresh && state.groupAggregation
      ? activeCriteria.map((c) => ({
          code: c.code,
          name: c.name,
          bobot: Number(((state.groupAggregation?.weights[c.id] ?? 0) * 100).toFixed(2)),
          raw: state.groupAggregation?.weights[c.id] ?? 0,
        }))
      : [];

  const dmProgressData = activeDMs.map((dm) => {
    const ass = state.bwmAssessments[dm.id];
    const res = state.bwmResults[dm.id];
    const hasAss = Boolean(ass && ass.bestCriterionId && ass.worstCriterionId);
    const bwmOk = Boolean(res && !res.stale && !res.error && res.constraintCheckOk);
    return {
      id: dm.id,
      name: dm.name,
      perspective: dm.perspective,
      lambda: dm.lambda,
      hasAss,
      bwmOk,
      stale: Boolean(res?.stale),
      xi: res && !res.error ? res.xi : null,
      cri: res && !res.error ? res.cri : null,
      isConsistent: res?.isConsistent ?? false,
    };
  });

  const top10ChartData =
    isMarcosFresh && state.marcosResult
      ? state.marcosResult.rows.slice(0, 10).map((r) => ({
          name: r.name,
          fK: Number(r.fK.toFixed(4)),
          rank: r.rank,
        }))
      : [];

  const handleRunPipeline = () => {
    const bwmOut = runAllBWM();
    const allOk = activeDMs.every((dm) => {
      const r = bwmOut[dm.id];
      return r && !r.error && r.constraintCheckOk;
    });
    if (!allOk) return;
    // Wait a tick for state or navigate directly: since context updates async,
    // guide user clearly or run via subsequent button click if state isn't committed yet.
    onNavigate('bwm');
  };

  const isDemo = state.datasetMode.startsWith('DEMO');

  return (
    <div className="space-y-6">
      <PageHeader
        title="Ringkasan Sistem Pengambilan Keputusan Grup"
        description="Prioritas intervensi pengentasan kemiskinan pada kabupaten daerah tertinggal menggunakan Linear Best-Worst Method (BWM), Weighted Geometric Mean, dan MARCOS."
        statusLabel={
          isMarcosFresh
            ? `Seluruh perhitungan mutakhir · Prioritas #1: ${topAlt?.name ?? '-'}`
            : 'Perhitungan belum lengkap — ikuti panduan langkah pada alur kerja'
        }
        statusTone={isMarcosFresh ? 'ok' : 'info'}
        actions={
          <>
            {isAdmin && !allBWMFreshAndValid && allDMsAssessed && (
              <button
                type="button"
                onClick={handleRunPipeline}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors whitespace-nowrap"
              >
                <Play className="h-3.5 w-3.5" />
                <span>Jalankan Optimasi BWM Semua DM</span>
              </button>
            )}
            {isAdmin && allBWMFreshAndValid && !isAggregationFresh && isLambdaValid && (
              <button
                type="button"
                onClick={() => runGroupAggregation()}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors whitespace-nowrap"
              >
                <Play className="h-3.5 w-3.5" />
                <span>Hitung Agregasi Bobot</span>
              </button>
            )}
            {isAdmin && isAggregationFresh && !isMarcosFresh && (
              <button
                type="button"
                onClick={() => runMARCOS()}
                className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors whitespace-nowrap"
              >
                <Play className="h-3.5 w-3.5" />
                <span>Jalankan MARCOS Solver</span>
              </button>
            )}
          </>
        }
      />

      {isDemo && (
        <div className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50/70 px-4 py-3 text-xs text-amber-900">
          <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-semibold">Mode Dataset Demonstrasi (DEMO):</span> Data
            indikator kabupaten yang sedang dimuat merupakan data simulasi untuk keperluan
            demonstrasi dan pengujian algoritma. Anda dapat menggantinya dengan dataset aktual
            melalui menu <span className="font-semibold">Data Alternatif → Import Excel/CSV</span>.
          </div>
        </div>
      )}

      {state.datasetMode === 'PENELITIAN' && (
        <p className="text-sm text-slate-600">
          Sumber data: {STUDY_SOURCE}. Cakupan: 62 kabupaten daerah tertinggal periode 2020–2024.
          Tahun pengukuran indikator tidak tercantum pada dataset.
        </p>
      )}

      {/* 4-column Primary KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Alternatif</span>
            <Database className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {state.alternatives.length}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Kabupaten · {state.datasetMode === 'PENELITIAN' ? 'Data Penelitian' : isDemo ? 'Dataset DEMO' : state.datasetMode}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Kriteria Aktif</span>
            <SlidersHorizontal className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {activeCriteria.length}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            {activeCriteria.filter((c) => c.type === 'Benefit').length} Benefit ·{' '}
            {activeCriteria.filter((c) => c.type === 'Cost').length} Cost
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Decision Makers</span>
            <Users className="h-4 w-4 text-slate-400" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {activeDMs.length}
          </div>
          <div className="mt-1 text-xs text-slate-500">
            Total Σλ ={' '}
            <span
              className={`font-mono font-semibold ${
                isLambdaValid ? 'text-emerald-700' : 'text-rose-700'
              }`}
            >
              {lambdaSum.toFixed(2)}
            </span>{' '}
            {isLambdaValid ? '(Valid)' : '(Harus 1,00)'}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Prioritas Tertinggi</span>
            <Trophy className="h-4 w-4 text-slate-400" />
          </div>
          {topAlt ? (
            <>
              <div className="mt-2 font-display text-xl font-bold text-blue-800 truncate">
                {topAlt.name}
              </div>
              <div className="mt-1 text-xs text-slate-600 tabular-nums">
                f(Ki) = <span className="font-mono font-semibold">{topAlt.fK.toFixed(4)}</span> ·{' '}
                {topAlt.province}
              </div>
            </>
          ) : (
            <>
              <div className="mt-2 font-display text-lg font-semibold text-slate-400">
                Belum Dihitung
              </div>
              <div className="mt-1 text-xs text-slate-500">
                Lengkapi penilaian BWM → hasil dihitung otomatis
              </div>
            </>
          )}
        </div>
      </div>

      {/* Stage Status Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Status Penilaian DM</div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="font-mono text-base font-semibold text-slate-900 tabular-nums">
              {assessedCount} / {activeDMs.length} Lengkap
            </span>
            <span
              className={`text-xs font-medium ${
                allDMsAssessed ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {allDMsAssessed ? 'Siap Optimasi' : 'Perlu Input'}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Status Optimasi Linear BWM</div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="font-mono text-base font-semibold text-slate-900 tabular-nums">
              {bwmSolvedCount} / {activeDMs.length} Optimal
            </span>
            <span
              className={`text-xs font-medium ${
                allBWMFreshAndValid ? 'text-emerald-700' : 'text-amber-700'
              }`}
            >
              {allBWMFreshAndValid ? 'Valid & Mutakhir' : 'Belum / Kedaluwarsa'}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Status Agregasi Kelompok</div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-900">
              {isAggregationFresh
                ? 'Selesai (Geo-Mean)'
                : state.groupAggregation?.stale
                  ? 'Kedaluwarsa'
                  : 'Belum Dihitung'}
            </span>
            <button
              type="button"
              onClick={() => onNavigate('agregasi')}
              className="text-xs font-medium text-blue-700 hover:underline whitespace-nowrap"
            >
              Buka
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs text-slate-500">Status Perhitungan MARCOS</div>
          <div className="mt-1.5 flex items-center justify-between">
            <span className="text-sm font-semibold text-slate-900">
              {isMarcosFresh
                ? `Selesai (${state.marcosResult?.rows.length ?? 0} Kab.)`
                : state.marcosResult?.stale
                  ? 'Kedaluwarsa'
                  : 'Belum Dihitung'}
            </span>
            <button
              type="button"
              onClick={() => onNavigate('marcos')}
              className="text-xs font-medium text-blue-700 hover:underline whitespace-nowrap"
            >
              Buka
            </button>
          </div>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Chart 1: Distribusi Bobot Kriteria */}
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900">
                Distribusi Bobot Kriteria Kelompok
              </h2>
              <p className="text-xs text-slate-500">
                Hasil Weighted Geometric Mean seluruh Decision Maker (%)
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('agregasi')}
              className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:underline whitespace-nowrap"
            >
              <span>Detail</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          {weightChartData.length > 0 ? (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weightChartData} margin={{ top: 8, right: 12, left: -12, bottom: 4 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="code" tick={{ fontSize: 12, fill: '#475569' }} />
                  <YAxis tick={{ fontSize: 12, fill: '#475569' }} unit="%" />
                  <Tooltip
                    formatter={(val) => [`${Number(val ?? 0).toFixed(2)}%`, 'Bobot Kelompok']}
                    labelFormatter={(label) => {
                      const found = weightChartData.find((w) => w.code === label);
                      return found ? `${found.code} — ${found.name}` : String(label);
                    }}
                  />
                  <Bar dataKey="bobot" radius={[6, 6, 0, 0]} fill="#1D4ED8" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="flex h-64 flex-col items-center justify-center rounded-lg border border-dashed border-slate-200 bg-slate-50/70 p-6 text-center">
              <BarChart2 className="h-8 w-8 text-slate-300" />
              <p className="mt-2 text-sm font-medium text-slate-700">
                Grafik Bobot Kelompok Belum Tersedia
              </p>
              <p className="mt-1 max-w-sm text-xs text-slate-500">
                Lengkapi penilaian Linear BWM setiap DM; bobot kelompok dihitung otomatis.
              </p>
              <button
                type="button"
                onClick={() => onNavigate(allBWMFreshAndValid ? 'agregasi' : 'bwm')}
                className="mt-4 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors"
              >
                {allBWMFreshAndValid ? 'Ke Agregasi Bobot' : 'Ke Linear BWM Solver'}
              </button>
            </div>
          )}
        </div>

        {/* Chart 2: Progress Penilaian & Optimasi DM */}
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900">
                Progress Penilaian &amp; Optimasi DM
              </h2>
              <p className="text-xs text-slate-500">
                Status vektor BO/OW, nilai deviasi ξ, dan konsistensi CRI per Decision Maker
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('bwm')}
              className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:underline whitespace-nowrap"
            >
              <span>BWM Solver</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2.5 pr-3 font-medium">Decision Maker</th>
                  <th className="py-2.5 px-3 font-medium text-right">λ</th>
                  <th className="py-2.5 px-3 font-medium">Input BO/OW</th>
                  <th className="py-2.5 px-3 font-medium text-right">ξ*</th>
                  <th className="py-2.5 px-3 font-medium text-right">CRI</th>
                  <th className="py-2.5 pl-3 font-medium">Status Solver</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dmProgressData.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/80">
                    <td className="py-3 pr-3">
                      <div className="font-medium text-slate-900">{row.name}</div>
                      <div className="text-[11px] text-slate-500">{row.perspective}</div>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                      {row.lambda.toFixed(2)}
                    </td>
                    <td className="py-3 px-3">
                      {row.hasAss ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                          <CheckCircle2 className="h-3.5 w-3.5" /> Lengkap
                        </span>
                      ) : (
                        <span className="text-amber-700 font-medium">Belum Lengkap</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {row.xi !== null ? row.xi.toFixed(4) : '—'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {row.cri !== null ? row.cri.toFixed(4) : '—'}
                    </td>
                    <td className="py-3 pl-3">
                      {row.bwmOk ? (
                        <span className="text-emerald-700 font-medium">
                          Optimal {row.isConsistent ? '(Konsisten)' : '(CRI Tinggi)'}
                        </span>
                      ) : row.stale ? (
                        <span className="text-amber-700 font-medium">Kedaluwarsa</span>
                      ) : (
                        <span className="text-slate-400">Belum Dijalankan</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Temporary Ranking Preview (Only shown when MARCOS is computed and fresh) */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              10 Besar Prioritas Intervensi (MARCOS)
            </h2>
            <p className="text-xs text-slate-500">
              Nilai fungsi utilitas kompromi f(Ki) terbesar menunjukkan prioritas intervensi tertinggi
            </p>
          </div>
          {isMarcosFresh && (
            <button
              type="button"
              onClick={() => onNavigate('ranking')}
              className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 hover:underline whitespace-nowrap"
            >
              <span>Lihat Semua ({state.marcosResult?.rows.length})</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        {top10ChartData.length > 0 ? (
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={top10ChartData}
                layout="vertical"
                margin={{ top: 4, right: 28, left: 24, bottom: 4 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" horizontal={false} />
                <XAxis type="number" domain={[0, 1]} tick={{ fontSize: 12, fill: '#475569' }} />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={150}
                  tick={{ fontSize: 12, fill: '#0F172A' }}
                />
                <Tooltip formatter={(val) => [Number(val ?? 0).toFixed(4), 'Skor f(Ki)']} />
                <Bar dataKey="fK" radius={[0, 6, 6, 0]}>
                  {top10ChartData.map((entry, idx) => (
                    <Cell key={entry.name} fill={idx < 3 ? '#1D4ED8' : '#3B82F6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="flex h-52 flex-col items-center justify-center rounded-lg border border-dashed border-slate-200 bg-slate-50/70 p-6 text-center">
            <Trophy className="h-8 w-8 text-slate-300" />
            <p className="mt-2 text-sm font-medium text-slate-700">
              Ranking MARCOS Belum Dijalankan
            </p>
            <p className="mt-1 max-w-md text-xs text-slate-500">
              Angka ranking tidak ditampilkan sebelum Solver Linear BWM, Agregasi Bobot, dan
              MARCOS Solver dijalankan dengan data terkini.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('marcos')}
              className="mt-4 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Buka MARCOS Solver
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
