import React, { useState } from 'react';
import { KeyRound, LogIn, ShieldCheck, UserRound } from 'lucide-react';
import { ADMIN_ACCOUNT, useGDSS } from '../context/GDSSContext';

/** Halaman masuk multi-user: Admin (input nilai) dan akun per Decision Maker (DM 1, DM 2, …). */
export function LoginPage() {
  const { login, dmAccounts } = useGDSS();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const out = login(username, password);
    setError(out.ok ? '' : out.error ?? 'Gagal masuk.');
  };

  const pick = (u: string) => {
    setUsername(u);
    setPassword('');
    setError('');
  };

  const accounts = [
    {
      username: ADMIN_ACCOUNT.username,
      password: ADMIN_ACCOUNT.password,
      title: 'Administrator',
      subtitle: 'Kelola data & tinjau hasil',
      isAdmin: true,
    },
    ...dmAccounts.map((a) => ({
      username: a.username,
      password: a.password,
      title: `${a.label} — ${a.dm.name}`,
      subtitle: a.dm.perspective,
      isAdmin: false,
    })),
  ];

  return (
    <div className="min-h-screen bg-[#F4F7FB] text-slate-900 flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-4xl grid grid-cols-1 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm md:grid-cols-5">
        <div className="md:col-span-2 bg-[#0B1528] p-7 text-slate-100 flex flex-col justify-between gap-8">
          <div>
            <div className="font-display text-lg font-bold tracking-tight text-white">
              GDSS BWM + MARCOS
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
              Prioritas Pengentasan Kemiskinan Daerah Tertinggal
            </p>
          </div>
          <div className="space-y-3 text-xs leading-relaxed text-slate-300">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="h-4 w-4 shrink-0 text-blue-400 mt-0.5" />
              <span>
                <span className="font-semibold text-white">Admin</span> menginput dan mengubah
                nilai matriks keputusan langsung di tabel, kriteria, dan λ. Admin hanya dapat meninjau (tidak dapat mengubah) penilaian BWM setiap DM.
              </span>
            </div>
            <div className="flex items-start gap-2.5">
              <UserRound className="h-4 w-4 shrink-0 text-emerald-400 mt-0.5" />
              <span>
                <span className="font-semibold text-white">Decision Maker</span> membuka halaman
                khususnya untuk mengisi penilaian Linear BWM sendiri (Best/Worst, BO, OW) dan
                langsung melihat bobot, konsistensi, serta ranking secara real-time.
              </span>
            </div>
          </div>
        </div>

        <div className="md:col-span-3 p-7">
          <h1 className="font-display text-xl font-bold text-slate-900">Masuk ke Sistem</h1>
          <p className="mt-1 text-xs text-slate-500">Pilih akun lalu masukkan password.</p>

          <div className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-2">
            {accounts.map((a) => {
              const selected = username.trim().toLowerCase() === a.username;
              return (
                <button
                  key={a.username}
                  type="button"
                  onClick={() => pick(a.username)}
                  className={`rounded-xl border px-3.5 py-2.5 text-left transition-colors ${
                    selected
                      ? 'border-blue-600 bg-blue-50 ring-2 ring-blue-100'
                      : 'border-slate-200 bg-white hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-900">
                    {a.isAdmin ? (
                      <ShieldCheck className="h-3.5 w-3.5 text-blue-700" />
                    ) : (
                      <UserRound className="h-3.5 w-3.5 text-emerald-700" />
                    )}
                    <span className="truncate">{a.title}</span>
                  </div>
                  <div className="mt-0.5 truncate text-[11px] text-slate-500">{a.subtitle}</div>
                </button>
              );
            })}
          </div>

          <form onSubmit={handleSubmit} className="mt-5 space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Username</label>
              <input
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                autoComplete="username"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                placeholder="admin / dm1 / dm2 / dm3"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
              />
            </div>
            {error && (
              <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">
                {error}
              </div>
            )}
            <button
              type="submit"
              disabled={!username.trim() || !password}
              className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-40"
            >
              <LogIn className="h-4 w-4" />
              <span>Masuk</span>
            </button>
          </form>

          <div className="mt-5 rounded-lg border border-slate-200 bg-slate-50 p-3">
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-700">
              <KeyRound className="h-3.5 w-3.5" />
              <span>Akun demo</span>
            </div>
            <div className="mt-1.5 grid grid-cols-2 gap-x-4 gap-y-0.5 font-mono text-[11px] text-slate-600">
              {accounts.map((a) => (
                <span key={a.username} className="whitespace-nowrap">
                  {a.username} / {a.password}
                </span>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-slate-500">
              Buka Admin dan DM di tab berbeda untuk melihat pembaruan real-time berdampingan.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
