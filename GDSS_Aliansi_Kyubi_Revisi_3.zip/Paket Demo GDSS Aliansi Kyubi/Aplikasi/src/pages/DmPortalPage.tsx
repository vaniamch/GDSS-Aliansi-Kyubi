import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  MessageSquarePlus,
  Minus,
  PenLine,
  Trash2,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { AutoCalcBadge, ReadOnlyNotice } from '../components/AccessBadges';
import { BwmStepOne } from '../components/BwmStepOne';
import { BwmStepper, BwmVectorInputs } from '../components/BwmInputs';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import { computeMARCOS } from '../engine/mcdmEngine';
import type { DiscussionNote, PageId } from '../types/gdss';

interface DmPortalPageProps {
  onNavigate: (page: PageId) => void;
}

/**
 * Halaman khusus Decision Maker (mis. DM 1). Hanya akun DM pemilik yang dapat membukanya;
 * Admin tidak memiliki akses ke halaman ini. Seluruh angka ikut diperbarui real-time.
 */
export function DmPortalPage({ onNavigate }: DmPortalPageProps) {
  const {
    state,
    activeCriteria,
    isAdmin,
    currentDM,
    dmAccounts,
    addDiscussion,
    deleteDiscussion,
    updateBWMAssessment,
    canEditDM,
  } = useGDSS();

  // Halaman ini hanya untuk akun DM pemilik; Admin tidak memiliki akses.
  const dm = isAdmin ? null : currentDM;
  const account = dmAccounts.find((a) => a.dm.id === dm?.id);
  const assessment = dm ? state.bwmAssessments[dm.id] : undefined;
  const result = dm ? state.bwmResults[dm.id] : undefined;
  const agg = state.groupAggregation;
  const resultOk = Boolean(result && !result.error && !result.stale);

  const canEditBwm = Boolean(dm && canEditDM(dm.id));
  const isOwnPage = Boolean(dm && currentDM?.id === dm.id);

  const handlePairChange = (bestId: string, worstId: string) => {
    if (!dm || !assessment) return;
    updateBWMAssessment(dm.id, {
      bestCriterionId: bestId,
      worstCriterionId: worstId,
      bo: { ...assessment.bo, [bestId]: 1 },
      ow: { ...assessment.ow, [worstId]: 1 },
    });
  };
  const handleBO = (critId: string, v: number) => {
    if (!dm || !assessment || critId === assessment.bestCriterionId) return;
    updateBWMAssessment(dm.id, { bo: { ...assessment.bo, [critId]: v } });
  };
  const handleOW = (critId: string, v: number) => {
    if (!dm || !assessment || critId === assessment.worstCriterionId) return;
    updateBWMAssessment(dm.id, { ow: { ...assessment.ow, [critId]: v } });
  };

  const [category, setCategory] = useState<DiscussionNote['category']>('Catatan');
  const [content, setContent] = useState('');

  const weightRows = activeCriteria.map((c) => ({
    c,
    bo: assessment?.bo[c.id],
    ow: assessment?.ow[c.id],
    w: resultOk ? result!.weights[c.id] ?? 0 : null,
    g: agg && !agg.stale ? agg.weights[c.id] ?? 0 : null,
  }));
  const topCrit = resultOk
    ? [...weightRows].sort((a, b) => (b.w ?? 0) - (a.w ?? 0))[0]?.c
    : undefined;

  const chartData = weightRows.map((r) => ({
    code: r.c.code,
    [dm?.name ?? 'DM']: r.w !== null ? Number((r.w * 100).toFixed(2)) : 0,
    'Bobot Grup': r.g !== null ? Number((r.g * 100).toFixed(2)) : 0,
  }));

  // Ranking bila hanya memakai bobot DM ini, dibandingkan dengan ranking kelompok.
  const dmRanking = useMemo(() => {
    if (!resultOk || !result) return null;
    const { result: m } = computeMARCOS(state.alternatives, activeCriteria, result.weights);
    if (!m) return null;
    const groupRank = new Map(
      (state.marcosResult?.rows ?? []).map((r) => [r.alternativeId, r.rank])
    );
    return m.rows.slice(0, 10).map((r) => ({
      ...r,
      groupRank: groupRank.get(r.alternativeId),
    }));
  }, [resultOk, result, state.alternatives, activeCriteria, state.marcosResult]);

  const myNotes = state.discussions.filter((n) => dm && n.dmId === dm.id);
  const canWriteNote = Boolean(dm && currentDM?.id === dm.id);

  const submitNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dm || !content.trim()) return;
    addDiscussion({
      author: `${dm.name} (${dm.perspective})`,
      dmId: dm.id,
      category,
      content: content.trim(),
    });
    setContent('');
  };

  if (!dm) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-600">
        Decision Maker untuk akun ini tidak ditemukan.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Halaman ${account?.label ?? 'DM'}: ${dm.name}`}
        description={`${dm.perspective} · ${dm.institution}. Halaman khusus Decision Maker berisi penilaian Linear BWM, bobot optimal, tingkat konsistensi, dan dampaknya terhadap ranking kelompok.`}
        statusLabel={
          !dm.active
            ? 'DM ini sedang nonaktif dan tidak ikut agregasi'
            : resultOk
              ? `Bobot optimal tersedia · CRI ${result!.cri.toFixed(4)} ${
                  result!.isConsistent ? '(konsisten)' : '(melebihi ambang)'
                }`
              : 'Penilaian BWM belum valid'
        }
        statusTone={!dm.active || !resultOk ? 'warning' : result!.isConsistent ? 'ok' : 'warning'}
        actions={
          <>
            <AutoCalcBadge />
          </>
        }
      />

      {isOwnPage && (
        <div className="flex items-start gap-2.5 rounded-xl border border-blue-200 bg-blue-50/70 px-4 py-3 text-xs text-blue-900">
          <PenLine className="h-4 w-4 text-blue-600 shrink-0 mt-0.5" />
          <span>
            <span className="font-semibold">Halaman kerja {account?.label ?? 'DM'}.</span> Isi
            penilaian Linear BWM Anda sendiri pada Langkah 1–3; bobot, konsistensi, dan ranking
            langsung dihitung ulang. Data alternatif, kriteria, dan bobot λ hanya dapat diubah Admin.
          </span>
        </div>
      )}
      {!isOwnPage && <ReadOnlyNotice />}

      {/* Ringkasan */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-[11px] text-slate-500">Bobot Kepentingan λ</div>
          <div className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {dm.lambda.toFixed(2)}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-[11px] text-slate-500">Nilai ξ* Optimal</div>
          <div className="mt-1 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {resultOk ? result!.xi.toFixed(4) : '—'}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-[11px] text-slate-500">
            CRI (≤ {state.crThreshold})
          </div>
          <div
            className={`mt-1 font-mono text-2xl font-bold tabular-nums ${
              !resultOk ? 'text-slate-400' : result!.isConsistent ? 'text-emerald-700' : 'text-rose-700'
            }`}
          >
            {resultOk ? result!.cri.toFixed(4) : '—'}
          </div>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-[11px] text-slate-500">Kriteria Terpenting (w* tertinggi)</div>
          <div className="mt-1 text-sm font-semibold text-slate-900 leading-snug">
            {topCrit ? (
              <>
                <span className="font-mono text-blue-700">{topCrit.code}</span> {topCrit.name}
              </>
            ) : (
              '—'
            )}
          </div>
        </div>
      </div>

      {/* Langkah 1 – 4 */}
      {assessment ? (
        <>
          <BwmStepper criteria={activeCriteria} assessment={assessment} result={result} />
          <BwmStepOne
            criteria={activeCriteria}
            bestId={assessment.bestCriterionId}
            worstId={assessment.worstCriterionId}
            aBW={assessment.bo[assessment.worstCriterionId]}
            dmName={dm.name}
            readOnly={!canEditBwm}
            onChange={handlePairChange}
          />
        </>
      ) : (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
          Penilaian BWM untuk DM ini belum tersedia.
        </div>
      )}

      {assessment && (
        <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
          {/* Langkah 2 & 3 */}
          <div className="xl:col-span-7 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="font-display text-base font-semibold text-slate-900">
                  Form Penilaian: {dm.name}
                </h2>
                <p className="text-xs text-slate-500">
                  Skala 1–9 · terakhir diubah{' '}
                  {assessment.updatedBy ? `oleh ${assessment.updatedBy} ` : ''}
                  {new Date(assessment.updatedAt).toLocaleString('id-ID')}
                </p>
              </div>
              {!canEditBwm && (
                <span className="text-xs font-semibold text-slate-500">Mode baca</span>
              )}
            </div>
            {result?.error && (
              <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800">
                <AlertTriangle className="h-3.5 w-3.5 text-rose-600 shrink-0 mt-0.5" />
                <span>{result.error}</span>
              </div>
            )}
            <BwmVectorInputs
              criteria={activeCriteria}
              assessment={assessment}
              readOnly={!canEditBwm}
              onBO={handleBO}
              onOW={handleOW}
            />
          </div>

          {/* Langkah 4 */}
          <div
            id="bwm-step-4"
            className="xl:col-span-5 scroll-mt-6 rounded-xl border border-slate-200 bg-white p-5 space-y-4"
          >
            <div className="border-b border-slate-100 pb-3">
              <h2 className="font-display text-base font-semibold text-slate-900">
                <span className="mr-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-800 text-[11px] font-bold text-white align-middle">
                  4
                </span>
                Bobot Optimal {dm.name}
              </h2>
              <p className="text-xs text-slate-500">
                Hasil Linear BWM Solver · diperbarui otomatis, dibanding bobot grup (WGM)
              </p>
            </div>
            <div className="rounded-lg border border-slate-200 overflow-hidden">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                    <th className="py-2 px-3 text-left font-medium">Kriteria</th>
                    <th className="py-2 px-3 text-right font-medium">Bobot w*</th>
                    <th className="py-2 px-3 text-right font-medium">Bobot Grup</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {weightRows.map(({ c, w, g }) => (
                    <tr
                      key={c.id}
                      className={
                        c.id === assessment.bestCriterionId
                          ? 'bg-emerald-50/60'
                          : c.id === assessment.worstCriterionId
                            ? 'bg-rose-50/60'
                            : ''
                      }
                    >
                      <td className="py-2 px-3">
                        <span className="font-mono font-semibold text-slate-800">{c.code}</span>{' '}
                        <span className="text-slate-600">{c.name}</span>
                      </td>
                      <td className="py-2 px-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                        {w !== null ? w.toFixed(4) : '—'}
                      </td>
                      <td className="py-2 px-3 text-right font-mono text-slate-500 tabular-nums">
                        {g !== null ? g.toFixed(4) : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 6, right: 8, left: -16, bottom: 2 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="code" tick={{ fontSize: 11, fill: '#475569' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#475569' }} />
                  <Tooltip formatter={(v) => [`${Number(v ?? 0).toFixed(2)}%`]} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey={dm.name} fill="#1D4ED8" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Bobot Grup" fill="#94A3B8" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Ranking menurut DM */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="border-b border-slate-200 px-5 py-3.5">
          <h2 className="font-display text-sm font-semibold text-slate-900">
            10 Besar Menurut Preferensi {dm.name} (MARCOS dengan bobot DM)
          </h2>
          <p className="text-xs text-slate-500">
            Dibandingkan dengan peringkat kelompok hasil agregasi seluruh DM
          </p>
        </div>
        {!dmRanking ? (
          <div className="p-8 text-center text-xs text-slate-500">
            Ranking belum tersedia — penilaian BWM atau data alternatif belum valid.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <th className="py-2 px-4 text-left font-medium w-20">Rank DM</th>
                  <th className="py-2 px-4 text-left font-medium">Kabupaten</th>
                  <th className="py-2 px-4 text-left font-medium">Provinsi</th>
                  <th className="py-2 px-4 text-right font-medium">f(Ki) DM</th>
                  <th className="py-2 px-4 text-right font-medium">Rank Grup</th>
                  <th className="py-2 px-4 text-right font-medium">Selisih</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {dmRanking.map((r) => {
                  const diff = r.groupRank !== undefined ? r.groupRank - r.rank : null;
                  return (
                    <tr key={r.alternativeId}>
                      <td className="py-2 px-4 font-mono font-bold text-slate-900">#{r.rank}</td>
                      <td className="py-2 px-4 font-medium text-slate-900">{r.name}</td>
                      <td className="py-2 px-4 text-slate-600">{r.province}</td>
                      <td className="py-2 px-4 text-right font-mono tabular-nums">
                        {r.fK.toFixed(4)}
                      </td>
                      <td className="py-2 px-4 text-right font-mono tabular-nums">
                        {r.groupRank !== undefined ? `#${r.groupRank}` : '—'}
                      </td>
                      <td className="py-2 px-4 text-right">
                        {diff === null ? (
                          '—'
                        ) : diff === 0 ? (
                          <span className="inline-flex items-center gap-1 text-slate-500">
                            <Minus className="h-3 w-3" /> sama
                          </span>
                        ) : diff > 0 ? (
                          <span className="inline-flex items-center gap-1 font-mono text-emerald-700">
                            <ArrowUp className="h-3 w-3" /> {diff}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-mono text-rose-700">
                            <ArrowDown className="h-3 w-3" /> {Math.abs(diff)}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Catatan DM */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {canWriteNote && (
          <div className="lg:col-span-5 rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="font-display text-sm font-semibold text-slate-900 mb-3">
              Tulis Catatan sebagai {dm.name}
            </h2>
            <form onSubmit={submitNote} className="space-y-3">
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as DiscussionNote['category'])}
                className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
              >
                <option value="Catatan">Catatan</option>
                <option value="Keputusan">Keputusan</option>
                <option value="Validasi">Validasi</option>
              </select>
              <textarea
                rows={3}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Tuliskan alasan penilaian atau tanggapan terhadap hasil kelompok..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!content.trim()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:opacity-40"
              >
                <MessageSquarePlus className="h-3.5 w-3.5" />
                <span>Simpan Catatan</span>
              </button>
            </form>
          </div>
        )}
        <div
          className={`${canWriteNote ? 'lg:col-span-7' : 'lg:col-span-12'} rounded-xl border border-slate-200 bg-white divide-y divide-slate-100`}
        >
          <div className="px-5 py-3.5 font-display text-sm font-semibold text-slate-900">
            Catatan {dm.name} ({myNotes.length})
          </div>
          {myNotes.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">Belum ada catatan.</div>
          ) : (
            myNotes.map((note) => (
              <div key={note.id} className="p-4 space-y-1.5">
                <div className="flex items-start justify-between gap-2 text-xs">
                  <span className="font-medium text-blue-700">{note.category}</span>
                  {canWriteNote && (
                    <button
                      type="button"
                      onClick={() => deleteDiscussion(note.id)}
                      className="rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-700"
                      title="Hapus catatan"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
                <p className="text-xs leading-relaxed text-slate-700">{note.content}</p>
                <div className="font-mono text-[11px] text-slate-400">
                  {new Date(note.createdAt).toLocaleString('id-ID')}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
