import React, { useState } from 'react';
import { AlertTriangle, Pencil, Plus, Trash2 } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import { ReadOnlyNotice } from '../components/AccessBadges';
import type { Criterion, CriterionType } from '../types/gdss';

export function KriteriaPage() {
  const { state, activeCriteria, addCriterion, updateCriterion, deleteCriterion, isAdmin } =
    useGDSS();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingCrit, setEditingCrit] = useState<Criterion | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [unit, setUnit] = useState('');
  const [type, setType] = useState<CriterionType>('Benefit');
  const [active, setActive] = useState(true);
  const [error, setError] = useState('');

  const openAdd = () => {
    setEditingCrit(null);
    setName('');
    setDescription('');
    setUnit('%');
    setType('Benefit');
    setActive(true);
    setError('');
    setModalOpen(true);
  };

  const openEdit = (c: Criterion) => {
    setEditingCrit(c);
    setName(c.name);
    setDescription(c.description);
    setUnit(c.unit);
    setType(c.type);
    setActive(c.active);
    setError('');
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Nama kriteria wajib diisi.');
      return;
    }
    if (editingCrit) {
      updateCriterion(editingCrit.id, {
        name: name.trim(),
        description: description.trim(),
        unit: unit.trim() || '-',
        type,
        active,
      });
    } else {
      addCriterion({
        name: name.trim(),
        description: description.trim(),
        unit: unit.trim() || '-',
        type,
        active,
      });
    }
    setModalOpen(false);
  };

  const zeroCostConflicts = activeCriteria.filter(
    (c) =>
      c.type === 'Cost' &&
      state.alternatives.some((alt) => (alt.values[c.id] ?? 0) <= 0)
  );

  return (
    <div className="space-y-6">
      <PageHeader
        title="Kelola Kriteria Penilaian"
        description="Atur daftar kriteria secara dinamis (tidak terkunci pada 8 kriteria). Penambahan C9 dan seterusnya akan otomatis menyesuaikan form BO/OW, Linear BWM, Agregasi, MARCOS, dan grafik."
        statusLabel={`${activeCriteria.length} kriteria aktif dari total ${state.criteria.length} kriteria`}
        statusTone={activeCriteria.length >= 2 ? 'ok' : 'warning'}
        actions={
          isAdmin ? (
            <button
              type="button"
              onClick={openAdd}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors whitespace-nowrap"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Tambah Kriteria Baru</span>
            </button>
          ) : undefined
        }
      />

      {!isAdmin && <ReadOnlyNotice />}

      {/* Direction Guide */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-semibold text-blue-800">
            Kriteria BENEFIT (Makin Tinggi = Makin Butuh Intervensi)
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-600">
            Semakin besar nilainya, semakin mendesak kabupaten tersebut untuk diprioritaskan
            (contoh: Persentase Penduduk Miskin, Defisit Sanitasi, Defisit Air Minum).
          </p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="text-xs font-semibold text-slate-900">
            Kriteria COST (Makin Rendah = Makin Butuh Intervensi)
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-600">
            Semakin rendah nilainya, semakin tinggi kebutuhan intervensi (contoh: Rata-rata Lama
            Sekolah, Pengeluaran per Kapita, Umur Harapan Hidup, PDRB). Nilai Cost tidak boleh ≤ 0.
          </p>
        </div>
      </div>

      {zeroCostConflicts.length > 0 && (
        <div className="flex items-start gap-2.5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-900">
          <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Peringatan Pembagian Nol MARCOS:</span> Kriteria{' '}
            {zeroCostConflicts.map((c) => c.code).join(', ')} bertipe Cost namun memiliki nilai ≤ 0
            pada salah satu kabupaten. Ubah menjadi Benefit (seperti defisit 100 - % akses) atau
            perbaiki nilainya pada Data Alternatif sebelum menjalankan MARCOS.
          </div>
        </div>
      )}

      {/* Criteria Table */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600">
                <th className="py-3 px-4 font-medium">Kode</th>
                <th className="py-3 px-4 font-medium">Nama Kriteria &amp; Deskripsi</th>
                <th className="py-3 px-4 font-medium">Satuan</th>
                <th className="py-3 px-4 font-medium">Jenis (Klik untuk Ubah)</th>
                <th className="py-3 px-4 font-medium">Status</th>
                {isAdmin && <th className="py-3 px-4 font-medium text-right">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {state.criteria.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/80">
                  <td className="py-3.5 px-4 font-mono font-semibold text-slate-900 whitespace-nowrap">
                    {c.code}
                  </td>
                  <td className="py-3.5 px-4 max-w-md">
                    <div className="font-semibold text-slate-900">{c.name}</div>
                    <div className="mt-0.5 text-[11px] text-slate-500 leading-relaxed">
                      {c.description || '—'}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 whitespace-nowrap">{c.unit}</td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <button
                      type="button"
                      disabled={!isAdmin}
                      onClick={() =>
                        updateCriterion(c.id, {
                          type: c.type === 'Benefit' ? 'Cost' : 'Benefit',
                        })
                      }
                      className={`rounded-md border px-2.5 py-1 text-xs font-semibold transition-colors ${
                        c.type === 'Benefit'
                          ? 'border-blue-200 bg-blue-50 text-blue-800 hover:bg-blue-100'
                          : 'border-slate-300 bg-slate-100 text-slate-800 hover:bg-slate-200'
                      }`}
                    >
                      {c.type}
                    </button>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap">
                    <button
                      type="button"
                      disabled={!isAdmin}
                      onClick={() => updateCriterion(c.id, { active: !c.active })}
                      className={`text-xs font-medium ${
                        c.active ? 'text-emerald-700' : 'text-slate-400'
                      }`}
                    >
                      {c.active ? 'Aktif' : 'Nonaktif'}
                    </button>
                  </td>
                  {isAdmin && (
                  <td className="py-3.5 px-4 text-right whitespace-nowrap">
                    <div className="inline-flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openEdit(c)}
                        className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-blue-700"
                        title="Edit kriteria"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        disabled={state.criteria.length <= 2}
                        onClick={() => deleteCriterion(c.id)}
                        className="rounded p-1.5 text-slate-500 hover:bg-rose-50 hover:text-rose-700 disabled:opacity-30"
                        title="Hapus kriteria (minimal 2 kriteria)"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-xl">
            <h2 className="font-display text-lg font-bold text-slate-900">
              {editingCrit ? `Edit Kriteria ${editingCrit.code}` : 'Tambah Kriteria Baru'}
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Kode kriteria baru dibuat berurutan secara otomatis (mis. C9, C10).
            </p>

            <form onSubmit={handleSave} className="mt-5 space-y-4">
              {error && (
                <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nama Kriteria
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Rasio Ketergantungan Infrastruktur"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Deskripsi
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Jelaskan arah interpretasi terhadap kebutuhan intervensi..."
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Satuan
                  </label>
                  <input
                    type="text"
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    placeholder="%, tahun, indeks"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Jenis Kriteria
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as CriterionType)}
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                  >
                    <option value="Benefit">Benefit (Makin tinggi = prioritas)</option>
                    <option value="Cost">Cost (Makin rendah = prioritas)</option>
                  </select>
                </div>
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={(e) => setActive(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600"
                />
                <span>Kriteria aktif digunakan dalam perhitungan BWM &amp; MARCOS</span>
              </label>

              <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                >
                  Simpan Kriteria
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
