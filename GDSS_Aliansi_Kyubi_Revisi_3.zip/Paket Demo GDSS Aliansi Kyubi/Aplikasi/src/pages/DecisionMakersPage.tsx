import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Pencil,
  Plus,
  Scale,
  Trash2,
} from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import { ReadOnlyNotice } from '../components/AccessBadges';
import type { DecisionMaker, PageId } from '../types/gdss';

interface DecisionMakersPageProps {
  onNavigate: (page: PageId) => void;
}

export function DecisionMakersPage({ onNavigate }: DecisionMakersPageProps) {
  const {
    state,
    activeCriteria,
    activeDMs,
    lambdaSum,
    isLambdaValid,
    addDecisionMaker,
    updateDecisionMaker,
    deleteDecisionMaker,
    normalizeLambdas,
    isAdmin,
    dmAccounts,
  } = useGDSS();

  const [modalOpen, setModalOpen] = useState(false);
  const [editingDm, setEditingDm] = useState<DecisionMaker | null>(null);
  const [name, setName] = useState('');
  const [perspective, setPerspective] = useState('');
  const [institution, setInstitution] = useState('');
  const [lambdaStr, setLambdaStr] = useState('0.25');
  const [active, setActive] = useState(true);
  const [error, setError] = useState('');

  const openAdd = () => {
    setEditingDm(null);
    setName('');
    setPerspective('');
    setInstitution('');
    setLambdaStr('0.25');
    setActive(true);
    setError('');
    setModalOpen(true);
  };

  const openEdit = (dm: DecisionMaker) => {
    setEditingDm(dm);
    setName(dm.name);
    setPerspective(dm.perspective);
    setInstitution(dm.institution);
    setLambdaStr(String(dm.lambda));
    setActive(dm.active);
    setError('');
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Nama Decision Maker wajib diisi.');
      return;
    }
    const parsed = Number(lambdaStr.replace(',', '.'));
    if (!Number.isFinite(parsed) || parsed < 0 || parsed > 1) {
      setError('Bobot kepentingan λ harus bernilai antara 0 sampai 1.');
      return;
    }

    if (editingDm) {
      updateDecisionMaker(editingDm.id, {
        name: name.trim(),
        perspective: perspective.trim() || 'Umum',
        institution: institution.trim() || '-',
        lambda: parsed,
        active,
      });
    } else {
      addDecisionMaker({
        name: name.trim(),
        perspective: perspective.trim() || 'Umum',
        institution: institution.trim() || '-',
        lambda: parsed,
        active,
      });
    }
    setModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Pengelolaan Decision Makers"
        description="Atur panel pengambil keputusan (DM), perspektif instansi, serta bobot kepentingan relatif (λ). Setiap DM memiliki penilaian Linear BWM secara independen."
        statusLabel={`${activeDMs.length} DM aktif · Total Σλ = ${lambdaSum.toFixed(4)} ${
          isLambdaValid ? '(Valid)' : '(Harus tepat 1,0000)'
        }`}
        statusTone={isLambdaValid ? 'ok' : 'warning'}
        actions={
          <>
            {isAdmin && !isLambdaValid && activeDMs.length > 0 && (
              <button
                type="button"
                onClick={normalizeLambdas}
                className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-900 hover:bg-amber-100 whitespace-nowrap"
              >
                <Scale className="h-3.5 w-3.5" />
                <span>Normalisasi ke Σλ = 1</span>
              </button>
            )}
            {isAdmin && (
              <button
                type="button"
                onClick={openAdd}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Tambah Decision Maker</span>
              </button>
            )}
          </>
        }
      />

      {!isAdmin && <ReadOnlyNotice />}

      {!isLambdaValid && (
        <div className="flex items-start justify-between gap-3 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-900">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Validasi Σλ = 1 Gagal:</span> Total bobot
              kepentingan DM aktif saat ini adalah{' '}
              <span className="font-mono font-semibold">{lambdaSum.toFixed(4)}</span>. Agregasi
              bobot kelompok tidak dapat dijalankan sebelum Σλ = 1,0000.
            </div>
          </div>
          {isAdmin && activeDMs.length > 0 && (
            <button
              type="button"
              onClick={normalizeLambdas}
              className="rounded-lg bg-rose-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-800 whitespace-nowrap shrink-0"
            >
              Normalisasi Sekarang
            </button>
          )}
        </div>
      )}

      {/* DM Table */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600">
                <th className="py-3 px-4 font-medium">ID</th>
                <th className="py-3 px-4 font-medium">Nama Decision Maker</th>
                <th className="py-3 px-4 font-medium">Perspektif &amp; Instansi</th>
                <th className="py-3 px-4 font-medium w-36">Bobot λ</th>
                <th className="py-3 px-4 font-medium">Status Penilaian</th>
                <th className="py-3 px-4 font-medium">Status Optimasi BWM</th>
                <th className="py-3 px-4 font-medium">Aktif</th>
                {isAdmin && <th className="py-3 px-4 font-medium text-right">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {state.decisionMakers.map((dm, idx) => {
                const ass = state.bwmAssessments[dm.id];
                const res = state.bwmResults[dm.id];
                const hasAss = Boolean(
                  ass &&
                    ass.bestCriterionId &&
                    ass.worstCriterionId &&
                    ass.bestCriterionId !== ass.worstCriterionId &&
                    activeCriteria.every(
                      (c) => ass.bo[c.id] >= 1 && ass.ow[c.id] >= 1
                    )
                );

                return (
                  <tr key={dm.id} className="hover:bg-slate-50/80">
                    <td className="py-3.5 px-4 font-mono text-slate-500 whitespace-nowrap">
                      DM{idx + 1}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900 whitespace-nowrap">
                      {dm.name}
                      {isAdmin && dmAccounts[idx] && (
                        <div className="mt-0.5 font-mono text-[10px] font-normal text-slate-400">
                          login: {dmAccounts[idx].username}
                        </div>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-medium text-slate-800">{dm.perspective}</div>
                      <div className="text-[11px] text-slate-500">{dm.institution}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <input
                        type="number"
                        step="0.05"
                        min="0"
                        max="1"
                        value={dm.lambda}
                        disabled={!isAdmin}
                        onChange={(e) => {
                          const v = Number(e.target.value);
                          if (Number.isFinite(v) && v >= 0 && v <= 1) {
                            updateDecisionMaker(dm.id, { lambda: v });
                          }
                        }}
                        className="w-24 rounded-lg border border-slate-300 px-2.5 py-1.5 font-mono text-xs tabular-nums focus:border-blue-500 focus:outline-none"
                      />
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {hasAss ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                          <CheckCircle2 className="h-3.5 w-3.5" /> Lengkap
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onNavigate('bwm')}
                          className="text-amber-700 font-medium hover:underline"
                        >
                          Belum Lengkap (Isi)
                        </button>
                      )}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      {res && !res.stale && !res.error && res.constraintCheckOk ? (
                        <span className="text-emerald-700 font-medium font-mono">
                          Optimal (ξ={res.xi.toFixed(4)})
                        </span>
                      ) : res?.stale ? (
                        <span className="text-amber-700 font-medium">Kedaluwarsa</span>
                      ) : res?.error ? (
                        <span className="text-rose-700 font-medium">Error</span>
                      ) : (
                        <span className="text-slate-400">Belum Dijalankan</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">
                      <button
                        type="button"
                        disabled={!isAdmin}
                        onClick={() => updateDecisionMaker(dm.id, { active: !dm.active })}
                        className={`text-xs font-medium ${
                          dm.active ? 'text-emerald-700' : 'text-slate-400'
                        }`}
                      >
                        {dm.active ? 'Aktif' : 'Nonaktif'}
                      </button>
                    </td>
                    {isAdmin && (
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEdit(dm)}
                          className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-blue-700"
                          title="Edit DM"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          disabled={state.decisionMakers.length <= 1}
                          onClick={() => deleteDecisionMaker(dm.id)}
                          className="rounded p-1.5 text-slate-500 hover:bg-rose-50 hover:text-rose-700 disabled:opacity-30"
                          title="Hapus DM (minimal 1 DM)"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t border-slate-200 bg-slate-50/70 font-semibold">
                <td colSpan={3} className="py-3 px-4 text-right text-slate-700">
                  Total Bobot Kepentingan DM Aktif (Σλ)
                </td>
                <td
                  className={`py-3 px-4 font-mono tabular-nums ${
                    isLambdaValid ? 'text-emerald-700' : 'text-rose-700'
                  }`}
                >
                  {lambdaSum.toFixed(4)}
                </td>
                <td colSpan={4} className="py-3 px-4 text-xs text-slate-500">
                  {isLambdaValid
                    ? 'Memenuhi syarat agregasi (Σλ = 1)'
                    : 'Harus tepat sama dengan 1,0000'}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Add/Edit DM Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 shadow-xl">
            <h2 className="font-display text-lg font-bold text-slate-900">
              {editingDm ? `Edit DM: ${editingDm.name}` : 'Tambah Decision Maker'}
            </h2>

            <form onSubmit={handleSave} className="mt-4 space-y-4">
              {error && (
                <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">
                  {error}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Nama Decision Maker
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Dr. Andi Pratama"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Perspektif Bidang
                </label>
                <input
                  type="text"
                  value={perspective}
                  onChange={(e) => setPerspective(e.target.value)}
                  placeholder="Contoh: Infrastruktur & Aksesibilitas"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Instansi / Rujukan Tupoksi
                </label>
                <input
                  type="text"
                  value={institution}
                  onChange={(e) => setInstitution(e.target.value)}
                  placeholder="Contoh: Dinas PUPR"
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Bobot Kepentingan (λ)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  max="1"
                  value={lambdaStr}
                  onChange={(e) => setLambdaStr(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>

              <label className="inline-flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={(e) => setActive(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600"
                />
                <span>Decision Maker aktif dalam agregasi grup</span>
              </label>

              <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                >
                  Simpan DM
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
