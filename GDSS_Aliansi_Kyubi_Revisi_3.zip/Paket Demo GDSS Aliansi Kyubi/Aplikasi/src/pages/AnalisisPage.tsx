import React, { useMemo } from 'react';
import { AlertTriangle, BarChart3 } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import {
  computeComparisonMethods,
  computeConsensusAnalysis,
  computeSensitivityAnalysis,
} from '../engine/mcdmEngine';
import type { PageId } from '../types/gdss';

interface AnalisisPageProps {
  onNavigate: (page: PageId) => void;
}

export function AnalisisPage({ onNavigate }: AnalisisPageProps) {
  const {
    state,
    activeCriteria,
    activeDMs,
    isMarcosFresh,
    updateSensitivityParams,
    isAdmin,
  } = useGDSS();

  const res = state.marcosResult;
  const agg = state.groupAggregation;

  const comparison = useMemo(() => {
    if (!res || !agg) return null;
    return computeComparisonMethods(
      state.alternatives,
      activeCriteria,
      agg.weights,
      res
    );
  }, [state.alternatives, activeCriteria, agg, res]);

  const consensus = useMemo(() => {
    if (!res) return null;
    return computeConsensusAnalysis(
      state.alternatives,
      activeCriteria,
      activeDMs,
      state.bwmResults,
      res
    );
  }, [state.alternatives, activeCriteria, activeDMs, state.bwmResults, res]);

  const sensitivity = useMemo(() => {
    if (!res || !agg) return [];
    return computeSensitivityAnalysis(
      state.alternatives,
      activeCriteria,
      activeDMs,
      state.bwmResults,
      agg.weights,
      res,
      state.sensitivityCriterionId || activeCriteria[0]?.id || '',
      state.sensitivityPct || 20
    );
  }, [
    state.alternatives,
    activeCriteria,
    activeDMs,
    state.bwmResults,
    agg,
    res,
    state.sensitivityCriterionId,
    state.sensitivityPct,
  ]);

  const cvChartData = useMemo(() => {
    if (!agg) return [];
    return activeCriteria.map((c) => ({
      code: c.code,
      cv: Number((agg.cv[c.id] ?? 0).toFixed(4)),
    }));
  }, [agg, activeCriteria]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Analisis Konsensus, Pembanding & Sensitivitas"
        description="Membandingkan ranking MARCOS antar-DM, korelasi Spearman, konkordansi Kendall's W, perbandingan metode TOPSIS/SAW, variasi bobot (CV), serta 8 skenario uji sensitivitas."
        statusLabel={
          isMarcosFresh && consensus
            ? `Kendall's W = ${consensus.kendallsW.toFixed(4)} · ρ(MARCOS, TOPSIS) = ${
                comparison?.spearmanMarcosTopsis.toFixed(4) ?? '—'
              }`
            : 'Menunggu hasil MARCOS mutakhir untuk dianalisis'
        }
        statusTone={isMarcosFresh ? 'ok' : 'warning'}
      />

      {!res || !agg || !consensus || !comparison ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <BarChart3 className="mx-auto h-9 w-9 text-slate-300" />
          <p className="mt-3 text-sm font-medium text-slate-700">
            Analisis Konsensus Belum Tersedia
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Lengkapi penilaian Linear BWM; agregasi dan MARCOS dihitung otomatis.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('marcos')}
            className="mt-4 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
          >
            Buka MARCOS Solver
          </button>
        </div>
      ) : (
        <>
          {!isMarcosFresh && (
            <div className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
              <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
              <span>
                Analisis ini didasarkan pada hasil MARCOS sebelumnya yang kedaluwarsa karena input saat
                ini belum valid. Perbaiki input agar korelasi dan uji sensitivitas diperbarui otomatis.
              </span>
            </div>
          )}

          {/* Top Metrics: Kendall's W + Method Comparison Spearman */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs text-slate-500">Koefisien Konkordansi Kendall&apos;s W</div>
              <div className="mt-1.5 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                {consensus.kendallsW.toFixed(4)}
              </div>
              <p className="mt-1.5 text-xs text-slate-600">
                {consensus.kendallsW >= 0.7
                  ? 'Kesepakatan antar-DM tergolong kuat.'
                  : consensus.kendallsW >= 0.4
                    ? 'Kesepakatan antar-DM tergolong sedang.'
                    : 'Terdapat perbedaan preferensi yang cukup besar antar-DM.'}
              </p>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs text-slate-500">Korelasi Spearman: MARCOS vs TOPSIS</div>
              <div className="mt-1.5 font-mono text-2xl font-bold text-blue-800 tabular-nums">
                {comparison.spearmanMarcosTopsis.toFixed(4)}
              </div>
              <p className="mt-1.5 text-xs text-slate-600">
                TOPSIS memakai normalisasi vektor &amp; jarak Euclidean sebagai pembanding independen.
              </p>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <div className="text-xs text-slate-500">Korelasi Spearman: MARCOS vs SAW</div>
              <div className="mt-1.5 font-mono text-2xl font-bold text-slate-900 tabular-nums">
                {comparison.spearmanMarcosSaw.toFixed(4)}
              </div>
              <p className="mt-1.5 text-xs text-slate-600">
                SAW memakai normalisasi linear yang sama sehingga skor sebanding dengan Sᵢ MARCOS.
              </p>
            </div>
          </div>

          {/* 1. Spearman Matrix antar-DM & Group */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
              <div className="border-b border-slate-200 px-5 py-3.5">
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Matriks Korelasi Rank Spearman (ρ) Antar-DM &amp; Kelompok
                </h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                      <th className="py-2.5 px-4 font-medium">ρ</th>
                      {consensus.spearmanMatrix.labels.map((lbl) => (
                        <th key={lbl} className="py-2.5 px-3 font-medium text-right">
                          {lbl}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                    {consensus.spearmanMatrix.labels.map((rowLbl, i) => (
                      <tr key={rowLbl}>
                        <td className="py-2.5 px-4 font-sans font-semibold text-slate-900">
                          {rowLbl}
                        </td>
                        {consensus.spearmanMatrix.values[i].map((val, j) => (
                          <td
                            key={j}
                            className={`py-2.5 px-3 text-right ${
                              i === j
                                ? 'text-slate-400'
                                : val >= 0.9
                                  ? 'text-emerald-700 font-semibold'
                                  : 'text-slate-800'
                            }`}
                          >
                            {val.toFixed(4)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* CV Chart */}
            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <h2 className="font-display text-sm font-semibold text-slate-900">
                Variasi Bobot Kriteria Antar-DM (Coefficient of Variation)
              </h2>
              <p className="text-xs text-slate-500 mb-3">
                Kesepakatan tertinggi: {agg.highestAgreementCode} · Perbedaan terbesar:{' '}
                {agg.highestDisagreementCode}
              </p>
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={cvChartData}
                    margin={{ top: 6, right: 8, left: -16, bottom: 2 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="code" tick={{ fontSize: 11, fill: '#475569' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#475569' }} />
                    <Tooltip formatter={(v) => [Number(v ?? 0).toFixed(4), 'CV']} />
                    <Bar dataKey="cv" fill="#1D4ED8" radius={[5, 5, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* 2. Perbandingan Ranking Antar-DM & Metode Pembanding (Top 15 + Debated/Agreed) */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
              <div className="border-b border-slate-200 px-5 py-3.5">
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Kabupaten Paling Diperdebatkan (Rentang Peringkat Terbesar)
                </h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                      <th className="py-2.5 px-4 font-medium">Kabupaten</th>
                      {activeDMs.map((dm) => (
                        <th key={dm.id} className="py-2.5 px-3 font-medium text-right">
                          {dm.name}
                        </th>
                      ))}
                      <th className="py-2.5 px-3 font-medium text-right">Rentang</th>
                      <th className="py-2.5 px-4 font-medium text-right">Kelompok</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {consensus.alternativeRanges
                      .slice()
                      .sort((a, b) => b.range - a.range || a.groupRank - b.groupRank)
                      .slice(0, 7)
                      .map((item) => (
                        <tr key={item.alternativeId}>
                          <td className="py-2.5 px-4 font-medium text-slate-900">
                            {item.name}
                          </td>
                          {activeDMs.map((dm) => (
                            <td
                              key={dm.id}
                              className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600"
                            >
                              #{item.ranksByDm[dm.id] ?? '-'}
                            </td>
                          ))}
                          <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-amber-700">
                            {item.range}
                          </td>
                          <td className="py-2.5 px-4 text-right font-mono font-semibold tabular-nums text-blue-800">
                            #{item.groupRank}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
              <div className="border-b border-slate-200 px-5 py-3.5">
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Perbandingan Top 10: MARCOS vs TOPSIS vs SAW
                </h2>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                      <th className="py-2.5 px-4 font-medium">Kabupaten</th>
                      <th className="py-2.5 px-3 font-medium text-right">MARCOS</th>
                      <th className="py-2.5 px-3 font-medium text-right">TOPSIS</th>
                      <th className="py-2.5 px-3 font-medium text-right">CC TOPSIS</th>
                      <th className="py-2.5 px-4 font-medium text-right">SAW</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {res.rows.slice(0, 10).map((row) => {
                      const t = comparison.topsisRanks[row.alternativeId];
                      const s = comparison.sawRanks[row.alternativeId];
                      return (
                        <tr key={row.alternativeId}>
                          <td className="py-2.5 px-4 font-medium text-slate-900">{row.name}</td>
                          <td className="py-2.5 px-3 text-right font-mono font-semibold text-blue-800 tabular-nums">
                            #{row.rank}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-700 tabular-nums">
                            #{t?.rank ?? '-'}
                          </td>
                          <td className="py-2.5 px-3 text-right font-mono text-slate-600 tabular-nums">
                            {t ? t.cc.toFixed(4) : '-'}
                          </td>
                          <td className="py-2.5 px-4 text-right font-mono text-slate-700 tabular-nums">
                            #{s?.rank ?? '-'}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* 3. Sensitivity Analysis (8 Scenarios) */}
          <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="flex flex-col gap-3 border-b border-slate-200 p-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="font-display text-sm font-semibold text-slate-900">
                  Analisis Sensitivitas Bobot Kelompok ({sensitivity.length} Skenario)
                </h2>
                <p className="text-xs text-slate-500">
                  Menguji kestabilan ranking saat bobot kriteria atau bobot DM λ diubah
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-600">Kriteria Uji:</span>
                <select
                  disabled={!isAdmin}
                  value={state.sensitivityCriterionId || activeCriteria[0]?.id || ''}
                  onChange={(e) =>
                    updateSensitivityParams(state.sensitivityPct, e.target.value)
                  }
                  className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                >
                  {activeCriteria.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code} — {c.name}
                    </option>
                  ))}
                </select>
                <span className="text-slate-600 ml-2">Perubahan ±%:</span>
                <input
                  type="number"
                  min={5}
                  max={80}
                  step={5}
                  value={state.sensitivityPct}
                  disabled={!isAdmin}
                  onChange={(e) => {
                    const v = Number(e.target.value);
                    if (Number.isFinite(v) && v >= 5 && v <= 90) {
                      updateSensitivityParams(v, state.sensitivityCriterionId);
                    }
                  }}
                  className="w-16 rounded-lg border border-slate-300 px-2 py-1.5 font-mono text-xs"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                    <th className="py-3 px-4 font-medium">Skenario</th>
                    <th className="py-3 px-4 font-medium">Keterangan</th>
                    <th className="py-3 px-3 font-medium text-right">ρ vs S0</th>
                    <th className="py-3 px-3 font-medium">Peringkat #1</th>
                    <th className="py-3 px-3 font-medium text-right">Top-5 Tetap</th>
                    <th className="py-3 px-3 font-medium text-right">Top-10 Tetap</th>
                    <th className="py-3 px-4 font-medium text-right">Geser Maks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {sensitivity.map((sc) => (
                    <tr key={sc.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono font-semibold text-slate-900 whitespace-nowrap">
                        {sc.id}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{sc.name}</div>
                        <div className="text-[11px] text-slate-500">{sc.description}</div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-semibold tabular-nums text-blue-800">
                        {sc.spearmanVsBase.toFixed(4)}
                      </td>
                      <td className="py-3 px-3 font-medium text-slate-800 whitespace-nowrap">
                        {sc.rank1Name}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                        {sc.top5Retained} / {Math.min(5, state.alternatives.length)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                        {sc.top10Retained} / {Math.min(10, state.alternatives.length)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                        {sc.maxRankShift}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
