import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Info,
  Plus,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { AutoCalcBadge, ReadOnlyNotice } from '../components/AccessBadges';
import { BwmStepOne } from '../components/BwmStepOne';
import { BwmStepper, BwmVectorInputs } from '../components/BwmInputs';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import { validateBWMInput } from '../engine/linearBwmSolver';
import type { PageId } from '../types/gdss';

const SCALE_GUIDE = [
  { val: 1, label: 'Sama penting (Equal importance)' },
  { val: 2, label: 'Sedikit lebih penting (Weak)' },
  { val: 3, label: 'Cukup lebih penting (Moderate)' },
  { val: 4, label: 'Moderate plus' },
  { val: 5, label: 'Jauh lebih penting (Strong)' },
  { val: 6, label: 'Strong plus' },
  { val: 7, label: 'Sangat lebih penting (Very strong)' },
  { val: 8, label: 'Very, very strong' },
  { val: 9, label: 'Mutlak lebih penting (Extreme)' },
];

interface LinearBwmPageProps {
  onNavigate: (page: PageId) => void;
}

export function LinearBwmPage({ onNavigate }: LinearBwmPageProps) {
  const {
    state,
    activeCriteria,
    activeDMs,
    allBWMFreshAndValid,
    updateBWMAssessment,
    updateCrThreshold,
    isAdmin,
    canEditDM,
  } = useGDSS();

  const [selectedDmId, setSelectedDmId] = useState<string>(
    activeDMs[0]?.id ?? state.decisionMakers[0]?.id ?? ''
  );

  useEffect(() => {
    if (!activeDMs.some((d) => d.id === selectedDmId) && activeDMs.length > 0) {
      setSelectedDmId(activeDMs[0].id);
    }
  }, [activeDMs, selectedDmId]);

  const currentDm = activeDMs.find((d) => d.id === selectedDmId) ?? activeDMs[0];
  const assessment = currentDm ? state.bwmAssessments[currentDm.id] : undefined;
  const result = currentDm ? state.bwmResults[currentDm.id] : undefined;

  const inputValidation = validateBWMInput(assessment, activeCriteria);

  const canEdit = Boolean(currentDm && canEditDM(currentDm.id));

  const handlePairChange = (bestId: string, worstId: string) => {
    if (!currentDm || !assessment) return;
    updateBWMAssessment(currentDm.id, {
      bestCriterionId: bestId,
      worstCriterionId: worstId,
      bo: { ...assessment.bo, [bestId]: 1 },
      ow: { ...assessment.ow, [worstId]: 1 },
    });
  };

  const handleBOValue = (critId: string, val: number) => {
    if (!currentDm || !assessment) return;
    if (critId === assessment.bestCriterionId) return;
    const clamped = Math.max(1, Math.min(9, Math.round(val) || 1));
    updateBWMAssessment(currentDm.id, {
      bo: { ...assessment.bo, [critId]: clamped },
    });
  };

  const handleOWValue = (critId: string, val: number) => {
    if (!currentDm || !assessment) return;
    if (critId === assessment.worstCriterionId) return;
    const clamped = Math.max(1, Math.min(9, Math.round(val) || 1));
    updateBWMAssessment(currentDm.id, {
      ow: { ...assessment.ow, [critId]: clamped },
    });
  };

  const chartData =
    result && !result.error
      ? activeCriteria.map((c) => ({
          code: c.code,
          name: c.name,
          weight: Number((result.weights[c.id] ?? 0).toFixed(4)),
          pct: Number(((result.weights[c.id] ?? 0) * 100).toFixed(2)),
        }))
      : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Linear Best-Worst Method (BWM) Solver"
        description="Penilaian perbandingan berpasangan Best-to-Others (BO) dan Others-to-Worst (OW) skala 1–9 untuk setiap Decision Maker, diselesaikan menggunakan Simplex Linear Programming (Rezaei, 2016)."
        statusLabel={
          allBWMFreshAndValid
            ? `Semua ${activeDMs.length} DM telah memiliki bobot Linear BWM optimal & mutakhir`
            : 'Lengkapi penilaian BWM yang belum valid — bobot dihitung otomatis setelah valid'
        }
        statusTone={allBWMFreshAndValid ? 'ok' : 'warning'}
        actions={
          <>
            <div className="flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs">
              <span className="text-slate-600">Ambang CRI:</span>
              <input
                type="number"
                step="0.001"
                min="0.05"
                max="1"
                value={state.crThreshold}
                disabled={!isAdmin}
                onChange={(e) => {
                  const v = Number(e.target.value);
                  if (Number.isFinite(v) && v > 0) updateCrThreshold(v);
                }}
                className="w-16 font-mono font-semibold text-slate-900 focus:outline-none"
              />
            </div>
            <AutoCalcBadge label="Solver real-time · semua DM" />
          </>
        }
      />

      {/* DM Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        {activeDMs.map((dm) => {
          const isSelected = currentDm?.id === dm.id;
          const dmRes = state.bwmResults[dm.id];
          const isOk = Boolean(dmRes && !dmRes.stale && !dmRes.error && dmRes.constraintCheckOk);
          return (
            <button
              key={dm.id}
              type="button"
              onClick={() => setSelectedDmId(dm.id)}
              className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold border transition-colors whitespace-nowrap ${
                isSelected
                  ? 'bg-[#0B1528] text-white border-[#0B1528]'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span>{dm.name}</span>
              <span
                className={`font-mono text-[11px] ${
                  isSelected ? 'text-slate-300' : 'text-slate-400'
                }`}
              >
                λ={dm.lambda.toFixed(2)}
              </span>
              {isOk && (
                <CheckCircle2
                  className={`h-3.5 w-3.5 ${
                    isSelected ? 'text-emerald-400' : 'text-emerald-600'
                  }`}
                />
              )}
              {dmRes?.stale && (
                <AlertTriangle
                  className={`h-3.5 w-3.5 ${
                    isSelected ? 'text-amber-300' : 'text-amber-600'
                  }`}
                />
              )}
            </button>
          );
        })}

        {isAdmin && (
          <button
            type="button"
            onClick={() => onNavigate('dm')}
            className="inline-flex items-center gap-1.5 rounded-lg border border-dashed border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50 whitespace-nowrap"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Tambah / Kelola DM</span>
          </button>
        )}
      </div>

      {!canEdit && (
        <ReadOnlyNotice text="Penilaian BWM (kriteria terbaik/terburuk, BO, dan OW) hanya dapat diisi oleh masing-masing Decision Maker melalui akunnya sendiri. Admin hanya dapat meninjau." />
      )}

      {!currentDm || !assessment ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-600">
          Tidak ada Decision Maker aktif. Tambahkan DM pada halaman Decision Makers.
        </div>
      ) : (
        <>
        {/* Alur Langkah 1–4 + Langkah 1 (Best & Worst) ditampilkan lebar penuh agar menonjol */}
        <BwmStepper criteria={activeCriteria} assessment={assessment} result={result} />
        <BwmStepOne
          criteria={activeCriteria}
          bestId={assessment.bestCriterionId}
          worstId={assessment.worstCriterionId}
          aBW={assessment.bo[assessment.worstCriterionId]}
          dmName={currentDm.name}
          readOnly={!canEdit}
          onChange={handlePairChange}
        />

        <div className="grid grid-cols-1 gap-6 xl:grid-cols-12">
          {/* Left 7 cols: Input Assessment Form */}
          <div className="xl:col-span-7 space-y-5">
            <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-900">
                    Form Penilaian: {currentDm.name}
                  </h2>
                  <p className="text-xs text-slate-500">
                    Perspektif {currentDm.perspective} · {currentDm.institution}
                  </p>
                </div>
                <span
                  className={`inline-flex items-center gap-1.5 text-xs font-semibold whitespace-nowrap ${
                    inputValidation.valid ? 'text-emerald-700' : 'text-rose-700'
                  }`}
                >
                  {inputValidation.valid ? (
                    <CheckCircle2 className="h-3.5 w-3.5" />
                  ) : (
                    <AlertTriangle className="h-3.5 w-3.5" />
                  )}
                  <span>
                    {inputValidation.valid
                      ? 'Bobot diperbarui otomatis'
                      : 'Input belum valid'}
                  </span>
                </span>
              </div>

              {!inputValidation.valid && (
                <div className="rounded-lg border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-800 space-y-1">
                  {inputValidation.errors.map((err, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-rose-600" />
                      <span>{err}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Langkah 2 & 3: vektor BO dan OW */}
              <BwmVectorInputs
                criteria={activeCriteria}
                assessment={assessment}
                readOnly={!canEdit}
                onBO={handleBOValue}
                onOW={handleOWValue}
              />
            </div>

            {/* Scale 1-9 Guide */}
            <div className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-800 mb-2.5">
                <Info className="h-4 w-4 text-blue-600" />
                <span>Panduan Skala Perbandingan Berpasangan (1–9)</span>
              </div>
              <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-3 text-[11px] text-slate-600">
                {SCALE_GUIDE.map((s) => (
                  <div key={s.val}>
                    <span className="font-mono font-semibold text-slate-900">{s.val}</span> ={' '}
                    {s.label}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right 5 cols: LP Simplex Output & Weights */}
          <div className="xl:col-span-5 space-y-5">
            <div id="bwm-step-4" className="scroll-mt-6 rounded-xl border border-slate-200 bg-white p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-900">
                    <span className="mr-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-800 text-[11px] font-bold text-white align-middle">4</span>
                    Hasil Optimasi Simplex LP
                  </h2>
                  <p className="text-xs text-slate-500">
                    Variabel keputusan w₁…wₙ dan deviasi minimum ξ* · diperbarui otomatis
                  </p>
                </div>
                {result?.stale && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700">
                    <AlertTriangle className="h-3.5 w-3.5" /> Kedaluwarsa
                  </span>
                )}
              </div>

              {!result ? (
                <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50/70 p-8 text-center">
                  <p className="text-sm font-medium text-slate-700">
                    Solver Belum Dijalankan untuk {currentDm.name}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Lengkapi Langkah 1–3; bobot optimal langsung dihitung otomatis.
                  </p>
                </div>
              ) : result.error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-xs text-rose-800">
                  {result.error}
                </div>
              ) : (
                <>
                  {/* Consistency Warning if CRI > threshold */}
                  {!result.isConsistent && (
                    <div className="flex items-start gap-2 rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-900">
                      <AlertTriangle className="h-4 w-4 text-rose-600 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-semibold">Penilaian Tidak Konsisten:</span> CRI ={' '}
                        <span className="font-mono font-semibold">{result.cri.toFixed(4)}</span>{' '}
                        melebihi ambang batas{' '}
                        <span className="font-mono">{result.threshold.toFixed(3)}</span>. Tinjau
                        ulang vektor BO dan OW agar aBj × ajW mendekati aBW.
                      </div>
                    </div>
                  )}

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
                      <div className="text-[11px] text-slate-500">Nilai ξ* Optimal</div>
                      <div className="mt-1 font-mono text-lg font-bold text-slate-900 tabular-nums">
                        {result.xi.toFixed(4)}
                      </div>
                    </div>
                    <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
                      <div className="text-[11px] text-slate-500">
                        CRI Input-Based (≤ {result.threshold})
                      </div>
                      <div
                        className={`mt-1 font-mono text-lg font-bold tabular-nums ${
                          result.isConsistent ? 'text-emerald-700' : 'text-rose-700'
                        }`}
                      >
                        {result.cri.toFixed(4)}
                      </div>
                    </div>
                    <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
                      <div className="text-[11px] text-slate-500">Total Bobot (Σw)</div>
                      <div className="mt-1 font-mono text-base font-semibold text-slate-900 tabular-nums">
                        {result.totalWeight.toFixed(4)}
                      </div>
                    </div>
                    <div className="rounded-lg border border-slate-200 bg-slate-50/60 p-3">
                      <div className="text-[11px] text-slate-500">Verifikasi Kendala LP</div>
                      <div
                        className={`mt-1 text-sm font-semibold ${
                          result.constraintCheckOk ? 'text-emerald-700' : 'text-rose-700'
                        }`}
                      >
                        {result.constraintCheckOk ? 'OK (Valid)' : 'Gagal'}
                      </div>
                    </div>
                  </div>

                  {/* Weights Table */}
                  <div className="rounded-lg border border-slate-200 overflow-hidden">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                          <th className="py-2 px-3 text-left font-medium">Kriteria</th>
                          <th className="py-2 px-3 text-right font-medium">Bobot w*</th>
                          <th className="py-2 px-3 text-right font-medium">Persen</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {activeCriteria.map((c) => {
                          const w = result.weights[c.id] ?? 0;
                          return (
                            <tr key={c.id}>
                              <td className="py-2 px-3">
                                <span className="font-mono font-semibold text-slate-800">
                                  {c.code}
                                </span>{' '}
                                <span className="text-slate-600">{c.name}</span>
                              </td>
                              <td className="py-2 px-3 text-right font-mono font-semibold text-slate-900 tabular-nums">
                                {w.toFixed(4)}
                              </td>
                              <td className="py-2 px-3 text-right font-mono text-slate-500 tabular-nums">
                                {(w * 100).toFixed(2)}%
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* Chart */}
                  <div className="h-56 w-full pt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={chartData}
                        margin={{ top: 6, right: 8, left: -16, bottom: 2 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                        <XAxis dataKey="code" tick={{ fontSize: 11, fill: '#475569' }} />
                        <YAxis tick={{ fontSize: 11, fill: '#475569' }} />
                        <Tooltip
                          formatter={(v) => [Number(v ?? 0).toFixed(4), 'Bobot Optimal']}
                        />
                        <Bar dataKey="weight" fill="#1D4ED8" radius={[5, 5, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
        </>
      )}
    </div>
  );
}
