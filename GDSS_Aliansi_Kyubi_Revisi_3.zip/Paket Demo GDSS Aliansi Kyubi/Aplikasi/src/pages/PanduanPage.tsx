import React from 'react';
import { ArrowRight, BookOpen } from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import type { PageId } from '../types/gdss';

const STEPS: Array<{
  num: string;
  title: string;
  page: PageId;
  pageName: string;
  detail: string;
  buttonHint: string;
}> = [
  {
    num: '01',
    title: 'Tambahkan atau Import Data Alternatif',
    page: 'alternatif',
    pageName: 'Data Alternatif',
    detail:
      'Preset penelitian memuat 62 kabupaten dari workbook Aliansi Kyubi. Untuk menggunakan workbook tugas, unggah langsung melalui Import Excel / CSV. Data buatan sendiri dapat diimpor dengan header Kabupaten, Provinsi, dan kode kriteria aktif.',
    buttonHint: 'Tombol: “Data Penelitian 62 Kab.”, “Import Excel / CSV”, atau “Tambah Alternatif”.',
  },
  {
    num: '02',
    title: 'Atur Kriteria Penilaian (Benefit / Cost)',
    page: 'kriteria',
    pageName: 'Kelola Kriteria',
    detail:
      'Tentukan kriteria secara dinamis (bisa lebih dari 8, mis. C9, C10). Benefit berarti makin tinggi nilai makin butuh intervensi; Cost berarti makin rendah nilai makin butuh intervensi (nilai Cost tidak boleh ≤ 0).',
    buttonHint: 'Tombol: "Tambah Kriteria Baru" atau klik label Benefit/Cost pada tabel.',
  },
  {
    num: '03',
    title: 'Tambahkan Decision Makers (DM)',
    page: 'dm',
    pageName: 'Decision Makers',
    detail:
      'Kelola pengambil keputusan beserta perspektif instansi. Default demonstrasi terdiri dari Jeno (0,40), James (0,30), dan Karina (0,30).',
    buttonHint: 'Tombol: "Tambah Decision Maker" atau edit inline.',
  },
  {
    num: '04',
    title: 'Atur Bobot Kepentingan λ',
    page: 'dm',
    pageName: 'Decision Makers',
    detail:
      'Pastikan total bobot kepentingan seluruh DM aktif memenuhi Σλk = 1,0000. Sistem otomatis memblokir agregasi jika Σλ ≠ 1.',
    buttonHint: 'Tombol: "Normalisasi ke Σλ = 1" jika total belum tepat 1.',
  },
  {
    num: '05',
    title: 'Isi Penilaian Linear BWM (BO & OW)',
    page: 'bwm',
    pageName: 'Linear BWM Solver',
    detail:
      'Pada setiap tab DM, pilih 1 Best Criterion dan 1 Worst Criterion (harus berbeda), lalu isi vektor Best-to-Others (BO) dan Others-to-Worst (OW) menggunakan skala 1–9.',
    buttonHint: 'Pastikan aBB = 1 pada BO dan aWW = 1 pada OW.',
  },
  {
    num: '06',
    title: 'Jalankan Solver Linear BWM (Simplex LP)',
    page: 'bwm',
    pageName: 'Linear BWM Solver',
    detail:
      'Solver meminimumkan deviasi maksimum ξ menggunakan Two-Phase Simplex LP dan menghitung Input-Based Consistency Ratio (CRI). Pastikan CRI ≤ ambang batas (default 0,284).',
    buttonHint: 'Otomatis: bobot setiap DM dihitung ulang real-time setiap kali nilai BO/OW atau Best/Worst diubah.',
  },
  {
    num: '07',
    title: 'Hitung Agregasi Bobot Kelompok',
    page: 'agregasi',
    pageName: 'Agregasi Bobot',
    detail:
      'Menggabungkan bobot optimal tiap DM menggunakan Weighted Geometric Mean serta menghitung Coefficient of Variation (CV) untuk mengukur kesepakatan antar-DM.',
    buttonHint: 'Otomatis: agregasi diperbarui real-time mengikuti bobot BWM dan λ.',
  },
  {
    num: '08',
    title: 'Jalankan Perhitungan MARCOS',
    page: 'marcos',
    pageName: 'MARCOS Solver',
    detail:
      'Menghitung AAI, AI, matriks normalisasi, matriks terbobot, Si, derajat utilitas Ki- dan Ki+, fungsi utilitas f(Ki), serta indeks keparahan relatif per kriteria.',
    buttonHint: 'Otomatis: ranking MARCOS diperbarui real-time setiap kali data atau bobot berubah.',
  },
  {
    num: '09',
    title: 'Lihat Hasil Ranking & Analisis Konsensus',
    page: 'ranking',
    pageName: 'Hasil Ranking',
    detail:
      'Tinjau Top-5, Top-10, ranking lengkap, rekomendasi program intervensi, korelasi Spearman dengan TOPSIS/SAW, Kendall’s W, dan 8 skenario sensitivitas.',
    buttonHint: 'Navigasi ke "Hasil Ranking" dan "Analisis & Konsensus".',
  },
  {
    num: '10',
    title: 'Export Laporan Akademik',
    page: 'ranking',
    pageName: 'Hasil Ranking',
    detail:
      'Unduh hasil ranking lengkap beserta bobot kelompok dalam format Excel (.xlsx), PDF (.pdf), atau cetak langsung melalui fitur Print Laporan.',
    buttonHint: 'Tombol: "Export Excel", "Export PDF", atau "Print Laporan".',
  },
];

interface PanduanPageProps {
  onNavigate: (page: PageId) => void;
}

export function PanduanPage({ onNavigate }: PanduanPageProps) {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Panduan Lengkap Penggunaan & Referensi Matematika"
        description="Langkah operasional terstruktur dari pengisian data hingga pelaporan, beserta rumusan matematis Linear BWM, Weighted Geometric Mean, MARCOS, TOPSIS, dan Konsensus."
        statusLabel="Dokumentasi interaktif 10 langkah"
        statusTone="info"
      />

      {/* 10 Steps */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {STEPS.map((s) => (
          <div
            key={s.num}
            className="rounded-xl border border-slate-200 bg-white p-5 flex flex-col justify-between gap-4"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-blue-700">
                  LANGKAH {s.num}
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate(s.page)}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap"
                >
                  <span>Buka {s.pageName}</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
              <h2 className="font-display text-base font-semibold text-slate-900">
                {s.title}
              </h2>
              <p className="text-xs leading-relaxed text-slate-600">{s.detail}</p>
            </div>
            <div className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-[11px] font-medium text-slate-700">
              {s.buttonHint}
            </div>
          </div>
        ))}
      </div>

      {/* Mathematical Formulas Reference */}
      <div className="rounded-xl border border-slate-200 bg-white p-6 space-y-4">
        <div className="flex items-center gap-2">
          <BookOpen className="h-4 w-4 text-blue-700" />
          <h2 className="font-display text-base font-semibold text-slate-900">
            Ringkasan Formulasi Matematika Sistem
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 text-xs text-slate-700">
          <div className="rounded-lg border border-slate-200 p-4 space-y-1.5">
            <div className="font-semibold text-slate-900">
              1. Linear Best-Worst Method (Rezaei, 2016)
            </div>
            <div className="font-mono text-[11px] bg-slate-50 p-2.5 rounded border border-slate-200 leading-relaxed">
              min ξ <br />
              s.t. |wB − aBj·wj| ≤ ξ ; |wj − ajW·wW| ≤ ξ ∀j <br />
              Σ wj = 1, wj ≥ 0, ξ ≥ 0
            </div>
            <p className="text-[11px] text-slate-500">
              Input-Based CRI (Liang et al., 2020): CRI = max_j |aBj·ajW − aBW| / (aBW² − aBW),
              dengan ambang default 0,284.
            </p>
          </div>

          <div className="rounded-lg border border-slate-200 p-4 space-y-1.5">
            <div className="font-semibold text-slate-900">
              2. Agregasi Bobot Kelompok (Aczél &amp; Saaty, 1983)
            </div>
            <div className="font-mono text-[11px] bg-slate-50 p-2.5 rounded border border-slate-200 leading-relaxed">
              Gj = Πk (wj^(k))^λk <br />
              Wj = Gj / Σj Gj <br />
              CVj = STDEV(wj^(k)) / MEAN(wj^(k))
            </div>
            <p className="text-[11px] text-slate-500">
              Menggunakan rata-rata geometrik berbobot untuk menjaga sifat rasio bobot BWM.
            </p>
          </div>

          <div className="rounded-lg border border-slate-200 p-4 space-y-1.5">
            <div className="font-semibold text-slate-900">
              3. MARCOS (Stević et al., 2020)
            </div>
            <div className="font-mono text-[11px] bg-slate-50 p-2.5 rounded border border-slate-200 leading-relaxed">
              nij = xij / xAI (Benefit) ; nij = xAI / xij (Cost) <br />
              vij = nij · Wj ; Si = Σj vij <br />
              Ki⁻ = Si / S_AAI ; Ki⁺ = Si / S_AI <br />
              f(Ki) = (Ki⁻ + Ki⁺) / [1 + (1−f(Ki⁺))/f(Ki⁺) + (1−f(Ki⁻))/f(Ki⁻)]
            </div>
            <p className="text-[11px] text-slate-500">
              Alternatif diurutkan dari f(Ki) terbesar ke terkecil sebagai prioritas intervensi.
            </p>
          </div>

          <div className="rounded-lg border border-slate-200 p-4 space-y-1.5">
            <div className="font-semibold text-slate-900">
              4. Konsensus &amp; Uji Pembanding
            </div>
            <div className="font-mono text-[11px] bg-slate-50 p-2.5 rounded border border-slate-200 leading-relaxed">
              Spearman: ρ = 1 − 6Σdi² / (n(n²−1)) <br />
              Kendall&apos;s W = 12Σ(Ri − R̄)² / (m²(n³−n))
            </div>
            <p className="text-[11px] text-slate-500">
              TOPSIS memakai normalisasi vektor &amp; jarak Euclidean sebagai pembanding
              independen terhadap MARCOS.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
