import React, { useMemo, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  MessageSquarePlus,
  Trash2,
} from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import type { DiscussionNote, HistoryEntry } from '../types/gdss';

export function DiskusiPage() {
  const { state, activeDMs, addDiscussion, deleteDiscussion, isAdmin, currentDM } = useGDSS();

  const [author, setAuthor] = useState(currentDM?.name ?? activeDMs[0]?.name ?? 'Tim Peneliti');
  const [category, setCategory] = useState<DiscussionNote['category']>('Catatan');
  const [content, setContent] = useState('');
  const [histFilter, setHistFilter] = useState<HistoryEntry['category'] | 'all'>('all');

  const handleSubmitNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    const dmMatch = activeDMs.find((d) => d.name === author);
    addDiscussion({
      author: dmMatch ? `${dmMatch.name} (${dmMatch.perspective})` : author,
      dmId: dmMatch?.id,
      category,
      content: content.trim(),
    });
    setContent('');
  };

  const filteredHistory = useMemo(() => {
    if (histFilter === 'all') return state.history;
    return state.history.filter((h) => h.category === histFilter);
  }, [state.history, histFilter]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Diskusi Kelompok & Riwayat Keputusan"
        description="Pantau status pengisian tiap Decision Maker, catat argumen atau justifikasi keputusan kelompok, serta telusuri log versi perhitungan dan perubahan data."
        statusLabel={`Versi state saat ini: v${state.version} · ${state.history.length} catatan riwayat`}
        statusTone="info"
      />

      {/* DM Completion Status */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="border-b border-slate-200 px-5 py-3.5">
          <h2 className="font-display text-sm font-semibold text-slate-900">
            Status Pengisian &amp; Waktu Proses Decision Makers
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-slate-600">
                <th className="py-2.5 px-4 font-medium">Decision Maker</th>
                <th className="py-2.5 px-4 font-medium">Terakhir Diisi (BO/OW)</th>
                <th className="py-2.5 px-4 font-medium">Terakhir Optimasi BWM</th>
                <th className="py-2.5 px-4 font-medium">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {activeDMs.map((dm) => {
                const ass = state.bwmAssessments[dm.id];
                const res = state.bwmResults[dm.id];
                return (
                  <tr key={dm.id}>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{dm.name}</div>
                      <div className="text-[11px] text-slate-500">{dm.perspective}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {ass?.updatedAt
                        ? new Date(ass.updatedAt).toLocaleString('id-ID')
                        : 'Belum diisi'}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      {res?.computedAt
                        ? new Date(res.computedAt).toLocaleString('id-ID')
                        : 'Belum dioptimasi'}
                    </td>
                    <td className="py-3 px-4">
                      {res && !res.stale && !res.error && res.constraintCheckOk ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                          <CheckCircle2 className="h-3.5 w-3.5" /> Mutakhir (ξ={res.xi.toFixed(4)})
                        </span>
                      ) : res?.stale ? (
                        <span className="text-amber-700 font-medium">Kedaluwarsa</span>
                      ) : (
                        <span className="text-slate-400">Menunggu</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Discussions & History 2-col */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left 5 cols: Discussion Notes */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="font-display text-sm font-semibold text-slate-900 mb-3">
              Tambah Catatan / Diskusi Keputusan
            </h2>
            <form onSubmit={handleSubmitNote} className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Penulis
                  </label>
                  <select
                    value={isAdmin ? author : currentDM?.name ?? author}
                    disabled={!isAdmin}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                  >
                    {(isAdmin ? activeDMs : currentDM ? [currentDM] : []).map((dm) => (
                      <option key={dm.id} value={dm.name}>
                        {dm.name}
                      </option>
                    ))}
                    {isAdmin && <option value="Moderator / Analis">Moderator / Analis</option>}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-600 mb-1">
                    Kategori
                  </label>
                  <select
                    value={category}
                    onChange={(e) =>
                      setCategory(e.target.value as DiscussionNote['category'])
                    }
                    className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs"
                  >
                    <option value="Catatan">Catatan</option>
                    <option value="Keputusan">Keputusan</option>
                    <option value="Validasi">Validasi</option>
                  </select>
                </div>
              </div>
              <textarea
                rows={3}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Tuliskan rasional penilaian, kesepakatan bobot, atau catatan revisi..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-xs focus:border-blue-500 focus:outline-none"
              />
              <button
                type="submit"
                disabled={!content.trim()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:opacity-40"
              >
                <MessageSquarePlus className="h-3.5 w-3.5" />
                <span>Simpan Catatan</span>
              </button>
            </form>
          </div>

          <div className="rounded-xl border border-slate-200 bg-white divide-y divide-slate-100">
            <div className="px-5 py-3.5 font-display text-sm font-semibold text-slate-900">
              Catatan Diskusi ({state.discussions.length})
            </div>
            {state.discussions.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                Belum ada catatan diskusi.
              </div>
            ) : (
              state.discussions.map((note) => (
                <div key={note.id} className="p-4 space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div className="text-xs">
                      <span className="font-semibold text-slate-900">{note.author}</span>
                      <span className="mx-1.5 text-slate-300">·</span>
                      <span className="font-medium text-blue-700">{note.category}</span>
                    </div>
                    <button
                      type="button"
                      hidden={!isAdmin && note.dmId !== currentDM?.id}
                      onClick={() => deleteDiscussion(note.id)}
                      className="rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-700"
                      title="Hapus catatan"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <p className="text-xs leading-relaxed text-slate-700">{note.content}</p>
                  <div className="font-mono text-[11px] text-slate-400">
                    {new Date(note.createdAt).toLocaleString('id-ID')}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right 7 cols: Audit & Version History */}
        <div className="lg:col-span-7 rounded-xl border border-slate-200 bg-white overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 px-5 py-3.5">
            <h2 className="font-display text-sm font-semibold text-slate-900">
              Riwayat Proses &amp; Versi Keputusan
            </h2>
            <select
              value={histFilter}
              onChange={(e) =>
                setHistFilter(e.target.value as HistoryEntry['category'] | 'all')
              }
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs"
            >
              <option value="all">Semua Aktivitas</option>
              <option value="data">Data Alternatif</option>
              <option value="criteria">Kriteria</option>
              <option value="dm">Decision Makers</option>
              <option value="bwm">Linear BWM</option>
              <option value="aggregation">Agregasi</option>
              <option value="marcos">MARCOS</option>
            </select>
          </div>

          <div className="divide-y divide-slate-100 max-h-[540px] overflow-y-auto">
            {filteredHistory.map((h) => (
              <div key={h.id} className="flex items-start justify-between gap-4 px-5 py-3.5">
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-mono font-semibold text-blue-700">
                      v{h.version}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="font-semibold text-slate-900">{h.action}</span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">{h.summary}</p>
                </div>
                <div className="flex items-center gap-1 font-mono text-[11px] text-slate-400 whitespace-nowrap shrink-0">
                  <Clock className="h-3 w-3" />
                  <span>{new Date(h.timestamp).toLocaleString('id-ID')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
