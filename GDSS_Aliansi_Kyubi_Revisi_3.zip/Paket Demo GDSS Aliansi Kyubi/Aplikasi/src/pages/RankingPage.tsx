import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  FileSpreadsheet,
  FileText,
  Printer,
  Search,
  Trophy,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import type { PageId } from '../types/gdss';
import { exportRankingToExcel, exportRankingToPDF } from '../utils/exportUtils';

interface RankingPageProps {
  onNavigate: (page: PageId) => void;
}

export function RankingPage({ onNavigate }: RankingPageProps) {
  const { state, activeCriteria, isMarcosFresh } = useGDSS();
  const [viewScope, setViewScope] = useState<'top5' | 'top10' | 'all'>('all');
  const [search, setSearch] = useState('');

  const res = state.marcosResult;
  const agg = state.groupAggregation;

  const visibleRows = useMemo(() => {
    if (!res) return [];
    let base = res.rows;
    if (viewScope === 'top5') base = base.slice(0, 5);
    else if (viewScope === 'top10') base = base.slice(0, 10);

    const q = search.trim().toLowerCase();
    if (!q) return base;
    return base.filter(
      (r) =>
        r.name.toLowerCase().includes(q) ||
        r.province.toLowerCase().includes(q) ||
        r.recommendedProgram.toLowerCase().includes(q)
    );
  }, [res, viewScope, search]);

  const chartData = useMemo(() => {
    if (!res) return [];
    const sliceCount = viewScope === 'top5' ? 5 : 15;
    return res.rows.slice(0, sliceCount).map((r) => ({
      name: `#${r.rank} ${r.name}`,
      fK: Number(r.fK.toFixed(4)),
      rank: r.rank,
    }));
  }, [res, viewScope]);

  const getPriorityTier = (rank: number, total: number) => {
    if (rank <= 5) return { label: 'Sangat Mendesak (Top 5)', cls: 'text-rose-700 font-semibold' };
    if (rank <= 10) return { label: 'Prioritas Tinggi (Top 10)', cls: 'text-amber-700 font-semibold' };
    if (rank <= Math.ceil(total * 0.5)) return { label: 'Prioritas Menengah', cls: 'text-blue-700' };
    return { label: 'Prioritas Reguler', cls: 'text-slate-600' };
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Hasil Ranking Prioritas Intervensi"
        description="Peringkat akhir seluruh kabupaten berdasarkan nilai fungsi utilitas kompromi f(Ki) dari metode MARCOS beserta kriteria paling kritis dan rekomendasi program."
        statusLabel={
          isMarcosFresh && res
            ? `Ranking mutakhir (${res.rows.length} kabupaten) · Prioritas #1: ${res.rows[0]?.name}`
            : 'Hasil ranking belum tersedia atau sudah kedaluwarsa'
        }
        statusTone={isMarcosFresh ? 'ok' : 'warning'}
        actions={
          res && agg ? (
            <>
              <button
                type="button"
                onClick={() =>
                  exportRankingToExcel(
                    res,
                    activeCriteria,
                    agg,
                    state.decisionMakers,
                    state.datasetMode
                  )
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap no-print"
              >
                <FileSpreadsheet className="h-3.5 w-3.5" />
                <span>Export Excel</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  exportRankingToPDF(res, activeCriteria, agg, state.datasetMode)
                }
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 whitespace-nowrap no-print"
              >
                <FileText className="h-3.5 w-3.5" />
                <span>Export PDF</span>
              </button>
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap no-print"
              >
                <Printer className="h-3.5 w-3.5" />
                <span>Print Laporan</span>
              </button>
            </>
          ) : undefined
        }
      />

      {!res || !agg ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <Trophy className="mx-auto h-9 w-9 text-slate-300" />
          <p className="mt-3 text-sm font-medium text-slate-700">
            Ranking Akhir Belum Tersedia
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Lengkapi penilaian Linear BWM; agregasi dan MARCOS dihitung otomatis.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('marcos')}
            className="mt-4 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
          >
            Buka MARCOS Solver
          </button>
        </div>
      ) : (
        <>
          {(!isMarcosFresh || state.datasetMode.startsWith('DEMO')) && (
            <div className="space-y-2">
              {!isMarcosFresh && (
                <div className="flex items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
                    <span>
                      Perhatian: Hasil ranking ini kedaluwarsa karena input saat ini belum valid. Periksa
                      validasi pada MARCOS Solver agar laporan akurat.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => onNavigate('marcos')}
                    className="rounded-lg bg-amber-700 px-3 py-1.5 font-semibold text-white hover:bg-amber-800 whitespace-nowrap"
                  >
                    Periksa MARCOS
                  </button>
                </div>
              )}
              {state.datasetMode.startsWith('DEMO') && (
                <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-xs text-slate-600">
                  <span className="font-mono font-semibold text-amber-700">[DEMO]</span>
                  <span>
                    Ranking dihitung dari Dataset Simulasi DEMO (bukan data mentah resmi 514
                    kabupaten).
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Group Weights Strip */}
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="text-xs font-semibold text-slate-800 mb-2.5">
              Bobot Kelompok yang Digunakan (Weighted Geometric Mean)
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-8">
              {activeCriteria.map((c) => (
                <div
                  key={c.id}
                  className="rounded-lg border border-slate-200 bg-slate-50/60 px-3 py-2"
                >
                  <div className="text-[11px] font-mono font-semibold text-slate-700">
                    {c.code} ({c.type === 'Benefit' ? 'B' : 'C'})
                  </div>
                  <div className="mt-0.5 font-mono text-sm font-bold text-blue-800 tabular-nums">
                    {(agg.weights[c.id] ?? 0).toFixed(4)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Horizontal Bar Chart */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="font-display text-sm font-semibold text-slate-900">
              Grafik Horizontal Skor Utilitas f(Ki)
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Menampilkan {chartData.length} kabupaten teratas berdasarkan nilai f(Ki)
            </p>
            <div className="h-96 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  layout="vertical"
                  margin={{ top: 4, right: 28, left: 32, bottom: 4 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" horizontal={false} />
                  <XAxis type="number" domain={[0, 1]} tick={{ fontSize: 11, fill: '#475569' }} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={165}
                    tick={{ fontSize: 11, fill: '#0F172A' }}
                  />
                  <Tooltip formatter={(val) => [Number(val ?? 0).toFixed(4), 'f(Ki)']} />
                  <Bar dataKey="fK" radius={[0, 5, 5, 0]}>
                    {chartData.map((item) => (
                      <Cell
                        key={item.name}
                        fill={item.rank <= 5 ? '#1D4ED8' : item.rank <= 10 ? '#2563EB' : '#64748B'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Ranking Table with Top 5 / Top 10 / All Switcher */}
          <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="flex flex-col gap-3 border-b border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between no-print">
              <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => setViewScope('top5')}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    viewScope === 'top5'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Top 5
                </button>
                <button
                  type="button"
                  onClick={() => setViewScope('top10')}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    viewScope === 'top10'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Top 10
                </button>
                <button
                  type="button"
                  onClick={() => setViewScope('all')}
                  className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                    viewScope === 'all'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Semua ({res.rows.length})
                </button>
              </div>

              <div className="relative w-full sm:w-64">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Cari kabupaten / program..."
                  className="w-full rounded-lg border border-slate-300 bg-white py-1.5 pl-8 pr-3 text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600">
                    <th className="py-3 px-4 font-medium w-16">Ranking</th>
                    <th className="py-3 px-4 font-medium">Kabupaten</th>
                    <th className="py-3 px-4 font-medium">Provinsi</th>
                    <th className="py-3 px-4 font-medium text-right">Nilai Si</th>
                    <th className="py-3 px-4 font-medium text-right">Nilai Utilitas f(Ki)</th>
                    <th className="py-3 px-4 font-medium">Prioritas</th>
                    <th className="py-3 px-4 font-medium">Kriteria Kritis &amp; Program</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {visibleRows.map((row) => {
                    const tier = getPriorityTier(row.rank, res.rows.length);
                    return (
                      <tr key={row.alternativeId} className="hover:bg-slate-50/80">
                        <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                          #{row.rank}
                        </td>
                        <td className="py-3 px-4 font-semibold text-slate-900 whitespace-nowrap">
                          {row.name}
                        </td>
                        <td className="py-3 px-4 text-slate-600 whitespace-nowrap">
                          {row.province}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                          {row.si.toFixed(4)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-blue-800">
                          {row.fK.toFixed(4)}
                        </td>
                        <td className={`py-3 px-4 whitespace-nowrap ${tier.cls}`}>
                          {tier.label}
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-mono font-semibold text-slate-800">
                            {row.mostCriticalCriterionCode}
                          </span>{' '}
                          <span className="text-slate-600">· {row.recommendedProgram}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
