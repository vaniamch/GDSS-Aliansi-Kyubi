import React from 'react';
import { AlertTriangle, CheckCircle2, GitMerge } from 'lucide-react';
import { AutoCalcBadge } from '../components/AccessBadges';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import type { PageId } from '../types/gdss';

const DM_COLORS = ['#1D4ED8', '#0EA5E9', '#059669', '#7C3AED', '#EA580C'];

interface AgregasiPageProps {
  onNavigate: (page: PageId) => void;
}

export function AgregasiPage({ onNavigate }: AgregasiPageProps) {
  const {
    state,
    activeCriteria,
    activeDMs,
    lambdaSum,
    isLambdaValid,
    allBWMFreshAndValid,
    isAggregationFresh,
    isAdmin,
  } = useGDSS();

  const canAggregate = allBWMFreshAndValid && isLambdaValid;

  const agg = state.groupAggregation;

  const comparisonData =
    agg && !agg.stale
      ? activeCriteria.map((c) => {
          const row: Record<string, string | number> = { code: c.code, name: c.name };
          activeDMs.forEach((dm) => {
            row[dm.name] = Number(
              ((state.bwmResults[dm.id]?.weights[c.id] ?? 0) * 100).toFixed(2)
            );
          });
          row['Bobot Grup'] = Number(((agg.weights[c.id] ?? 0) * 100).toFixed(2));
          return row;
        })
      : [];

  const cvData =
    agg && !agg.stale
      ? activeCriteria.map((c) => ({
          code: c.code,
          name: c.name,
          cv: Number((agg.cv[c.id] ?? 0).toFixed(4)),
        }))
      : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Agregasi Bobot Kelompok (Weighted Geometric Mean)"
        description="Menggabungkan vektor bobot optimal seluruh Decision Maker menggunakan rata-rata geometrik berbobot λ serta mengukur tingkat perbedaan pendapat melalui Koefisien Variasi (CV)."
        statusLabel={
          isAggregationFresh
            ? 'Bobot kelompok mutakhir dan siap digunakan pada MARCOS Solver'
            : agg?.stale
              ? 'Bobot kelompok belum dapat diperbarui — periksa penilaian BWM atau Σλ'
              : 'Menunggu optimasi BWM lengkap dan validasi Σλ = 1'
        }
        statusTone={isAggregationFresh ? 'ok' : 'warning'}
        actions={
          <AutoCalcBadge label="Agregasi real-time" />
        }
      />

      {/* Prerequisite Gate Banner */}
      {!canAggregate && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50/80 px-4 py-3 text-xs text-amber-900">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Syarat Agregasi Belum Terpenuhi:</span>{' '}
              {!isLambdaValid
                ? `Total bobot λ saat ini ${lambdaSum.toFixed(4)} (harus 1,0000). `
                : ''}
              {!allBWMFreshAndValid
                ? 'Seluruh DM aktif harus memiliki hasil optimasi Linear BWM yang mutakhir.'
                : ''}
            </div>
          </div>
          <button
            type="button"
            hidden={!isAdmin}
            onClick={() => onNavigate(!isLambdaValid ? 'dm' : 'bwm')}
            className="rounded-lg bg-amber-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-800 whitespace-nowrap"
          >
            {!isLambdaValid ? 'Perbaiki Bobot DM' : 'Ke Linear BWM Solver'}
          </button>
        </div>
      )}

      {!agg ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <GitMerge className="mx-auto h-9 w-9 text-slate-300" />
          <p className="mt-3 text-sm font-medium text-slate-700">
            Agregasi Bobot Kelompok Belum Dijalankan
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Pastikan seluruh DM memiliki hasil Linear BWM valid, lalu klik tombol &ldquo;Hitung
            Agregasi Bobot&rdquo;.
          </p>
        </div>
      ) : (
        <>
          {agg.stale && (
            <div className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-900">
              <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
              <span>
                Hasil agregasi di bawah ini berasal dari perhitungan sebelumnya dan sudah
                kedaluwarsa karena input saat ini belum valid. Agregasi akan diperbarui otomatis
                begitu penilaian BWM dan Σλ valid.
              </span>
            </div>
          )}

          {/* Agreement / Disagreement Summary */}
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500">Jumlah Geo-Mean (Σ Gⱼ)</div>
              <div className="mt-1.5 font-mono text-xl font-bold text-slate-900 tabular-nums">
                {agg.geoMeanSum.toFixed(4)}
              </div>
              <div className="mt-1 text-[11px] text-slate-500">
                Digunakan sebagai pembagi normalisasi Wⱼ = Gⱼ / ΣGⱼ
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500">Kesepakatan Tertinggi (CV Terkecil)</div>
              <div className="mt-1.5 flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                <span className="font-display text-lg font-bold text-slate-900">
                  {agg.highestAgreementCode}
                </span>
              </div>
              <div className="mt-1 text-[11px] text-slate-500">
                {
                  activeCriteria.find((c) => c.code === agg.highestAgreementCode)
                    ?.name
                }
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-4">
              <div className="text-xs text-slate-500">
                Perbedaan Preferensi Terbesar (CV Tertinggi)
              </div>
              <div className="mt-1.5 flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <span className="font-display text-lg font-bold text-slate-900">
                  {agg.highestDisagreementCode}
                </span>
              </div>
              <div className="mt-1 text-[11px] text-slate-500">
                {
                  activeCriteria.find((c) => c.code === agg.highestDisagreementCode)
                    ?.name
                }
              </div>
            </div>
          </div>

          {/* Dynamic Aggregation Table */}
          <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
            <div className="border-b border-slate-200 px-5 py-3.5">
              <h2 className="font-display text-sm font-semibold text-slate-900">
                Tabel Bobot Per DM, Geo-Mean, Bobot Kelompok, dan CV
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600">
                    <th className="py-3 px-4 font-medium">Kriteria</th>
                    {activeDMs.map((dm) => (
                      <th key={dm.id} className="py-3 px-3 font-medium text-right whitespace-nowrap">
                        {dm.name} (λ={dm.lambda.toFixed(2)})
                      </th>
                    ))}
                    <th className="py-3 px-3 font-medium text-right whitespace-nowrap">
                      Geo-Mean
                    </th>
                    <th className="py-3 px-3 font-medium text-right whitespace-nowrap text-blue-800">
                      Bobot Grup (Wⱼ)
                    </th>
                    <th className="py-3 px-4 font-medium text-right whitespace-nowrap">CV</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeCriteria.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4">
                        <span className="font-mono font-semibold text-slate-900">{c.code}</span>{' '}
                        <span className="text-slate-700">{c.name}</span>
                      </td>
                      {activeDMs.map((dm) => (
                        <td
                          key={dm.id}
                          className="py-3 px-3 text-right font-mono tabular-nums text-slate-600"
                        >
                          {(state.bwmResults[dm.id]?.weights[c.id] ?? 0).toFixed(4)}
                        </td>
                      ))}
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                        {(agg.geoMeans[c.id] ?? 0).toFixed(4)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-blue-800 bg-blue-50/40">
                        {(agg.weights[c.id] ?? 0).toFixed(4)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-800">
                        {(agg.cv[c.id] ?? 0).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t border-slate-200 bg-slate-50/70 font-semibold">
                    <td className="py-3 px-4 text-slate-700">Total (Σ)</td>
                    {activeDMs.map((dm) => (
                      <td
                        key={dm.id}
                        className="py-3 px-3 text-right font-mono tabular-nums text-slate-700"
                      >
                        {(state.bwmResults[dm.id]?.totalWeight ?? 0).toFixed(4)}
                      </td>
                    ))}
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                      {agg.geoMeanSum.toFixed(4)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-blue-800">
                      {activeCriteria
                        .reduce((s, c) => s + (agg.weights[c.id] ?? 0), 0)
                        .toFixed(4)}
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">—</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <h3 className="font-display text-sm font-semibold text-slate-900 mb-1">
                Perbandingan Bobot Antar-DM vs Bobot Kelompok (%)
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                Memperlihatkan kontribusi masing-masing perspektif terhadap bobot akhir kelompok
              </p>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={comparisonData}
                    margin={{ top: 8, right: 8, left: -12, bottom: 4 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="code" tick={{ fontSize: 11, fill: '#475569' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#475569' }} unit="%" />
                    <Tooltip />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    {activeDMs.map((dm, idx) => (
                      <Bar
                        key={dm.id}
                        dataKey={dm.name}
                        fill={DM_COLORS[idx % DM_COLORS.length]}
                        radius={[3, 3, 0, 0]}
                      />
                    ))}
                    <Bar dataKey="Bobot Grup" fill="#0F172A" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5">
              <h3 className="font-display text-sm font-semibold text-slate-900 mb-1">
                Koefisien Variasi (CV) Preferensi Kriteria
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                CV = Standar Deviasi / Rata-rata. Makin tinggi CV, makin besar perbedaan pendapat antar-DM
              </p>
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={cvData}
                    margin={{ top: 8, right: 8, left: -12, bottom: 4 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="code" tick={{ fontSize: 11, fill: '#475569' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#475569' }} />
                    <Tooltip formatter={(val) => [Number(val ?? 0).toFixed(4), 'CV']} />
                    <Bar dataKey="cv" fill="#0284C7" radius={[5, 5, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
