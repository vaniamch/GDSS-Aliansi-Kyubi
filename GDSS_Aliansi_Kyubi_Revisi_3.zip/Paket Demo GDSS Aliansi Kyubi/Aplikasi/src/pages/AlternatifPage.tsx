import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownUp,
  Download,
  FileSpreadsheet,
  Keyboard,
  Pencil,
  Plus,
  Search,
  Trash2,
  Upload,
} from 'lucide-react';
import { ReadOnlyNotice } from '../components/AccessBadges';
import { PageHeader } from '../components/PageHeader';
import { useGDSS } from '../context/GDSSContext';
import { STUDY_SOURCE } from '../data/demoPresets';
import type { Alternative } from '../types/gdss';
import {
  exportAlternativesToCSV,
  exportAlternativesToExcel,
  parseImportedFile,
} from '../utils/exportUtils';

/** Sel input nilai matriks keputusan (khusus Admin). Nilai valid langsung disimpan & dihitung ulang. */
function ValueCell({
  value,
  invalid,
  label,
  onCommit,
}: {
  value: number;
  invalid: boolean;
  label: string;
  onCommit: (v: number) => void;
}) {
  // Tampilkan maksimal 4 desimal (menghindari tampilan seperti 16.840000000001).
  const fmt = (v: number) => String(Number(v.toFixed(4)));
  const [draft, setDraft] = useState(fmt(value));
  const [focused, setFocused] = useState(false);
  useEffect(() => {
    if (!focused) setDraft(fmt(value));
  }, [value, focused]);
  return (
    <input
      type="number"
      step="any"
      aria-label={label}
      value={draft}
      onFocus={(e) => {
        setFocused(true);
        e.target.select();
      }}
      onBlur={() => {
        setFocused(false);
        setDraft(fmt(value));
      }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
      }}
      onChange={(e) => {
        setDraft(e.target.value);
        const v = Number(e.target.value);
        if (e.target.value.trim() !== '' && Number.isFinite(v)) onCommit(v);
      }}
      className={`w-24 rounded-md border px-2 py-1 text-right font-mono text-xs tabular-nums focus:outline-none focus:ring-2 ${
        invalid
          ? 'border-rose-400 bg-rose-50 text-rose-800 focus:ring-rose-200'
          : 'border-blue-200 bg-blue-50/40 text-slate-900 focus:border-blue-500 focus:ring-blue-100'
      }`}
    />
  );
}

export function AlternatifPage() {
  const {
    state,
    activeCriteria,
    loadPreset,
    addAlternative,
    updateAlternative,
    deleteAlternative,
    importAlternatives,
    updateAlternativeValue,
    isAdmin,
    isMarcosFresh,
  } = useGDSS();

  // Mode input nilai manual langsung di tabel (khusus Admin), aktif secara default.
  const [inputMode, setInputMode] = useState(true);
  const editing = isAdmin && inputMode;
  const marcosRank = useMemo(
    () => new Map((state.marcosResult?.rows ?? []).map((r) => [r.alternativeId, r])),
    [state.marcosResult]
  );
  const top1 = state.marcosResult?.rows[0];

  const [search, setSearch] = useState('');
  const [provinceFilter, setProvinceFilter] = useState('ALL');
  const [sortKey, setSortKey] = useState<string>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  const [modalOpen, setModalOpen] = useState(false);
  const [editingAlt, setEditingAlt] = useState<Alternative | null>(null);
  const [formName, setFormName] = useState('');
  const [formProvince, setFormProvince] = useState('');
  const [formValues, setFormValues] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');

  const [importFeedback, setImportFeedback] = useState<{
    type: 'ok' | 'error';
    message: string;
  } | null>(null);
  const [replaceOnImport, setReplaceOnImport] = useState(true);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const provinces = useMemo(() => {
    const set = new Set(state.alternatives.map((a) => a.province));
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'id'));
  }, [state.alternatives]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return state.alternatives
      .filter((a) => {
        if (provinceFilter !== 'ALL' && a.province !== provinceFilter) return false;
        if (!q) return true;
        return (
          a.name.toLowerCase().includes(q) || a.province.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        let cmp = 0;
        if (sortKey === 'name') {
          cmp = a.name.localeCompare(b.name, 'id');
        } else if (sortKey === 'province') {
          cmp = a.province.localeCompare(b.province, 'id');
        } else if (editing) {
          // Saat mengetik nilai, urutan baris dibekukan (urut nama) agar baris tidak berpindah.
          cmp = a.name.localeCompare(b.name, 'id');
        } else {
          const va = a.values[sortKey] ?? 0;
          const vb = b.values[sortKey] ?? 0;
          cmp = va - vb;
        }
        return sortDir === 'asc' ? cmp : -cmp;
      });
  }, [state.alternatives, search, provinceFilter, sortKey, sortDir, editing]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const paginated = useMemo(
    () => filtered.slice((safePage - 1) * pageSize, safePage * pageSize),
    [filtered, safePage, pageSize]
  );

  const toggleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  const openAddModal = () => {
    setEditingAlt(null);
    setFormName('');
    setFormProvince('');
    const initVals: Record<string, string> = {};
    state.criteria.forEach((c) => {
      initVals[c.id] = '1';
    });
    setFormValues(initVals);
    setFormError('');
    setModalOpen(true);
  };

  const openEditModal = (alt: Alternative) => {
    setEditingAlt(alt);
    setFormName(alt.name);
    setFormProvince(alt.province);
    const initVals: Record<string, string> = {};
    state.criteria.forEach((c) => {
      initVals[c.id] = String(alt.values[c.id] ?? 0);
    });
    setFormValues(initVals);
    setFormError('');
    setModalOpen(true);
  };

  const handleSaveModal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formProvince.trim()) {
      setFormError('Nama kabupaten dan provinsi wajib diisi.');
      return;
    }

    const parsedValues: Record<string, number> = {};
    for (const c of state.criteria) {
      const raw = (formValues[c.id] ?? '').replace(',', '.');
      const num = Number(raw);
      if (!Number.isFinite(num) || raw.trim() === '') {
        setFormError(`Nilai untuk ${c.code} (${c.name}) harus berupa angka yang valid.`);
        return;
      }
      parsedValues[c.id] = num;
    }

    if (editingAlt) {
      updateAlternative(editingAlt.id, {
        name: formName.trim(),
        province: formProvince.trim(),
        values: parsedValues,
        isDemo: false,
      });
    } else {
      addAlternative({
        name: formName.trim(),
        province: formProvince.trim(),
        values: parsedValues,
        isDemo: false,
      });
    }
    setModalOpen(false);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const alternatives = await parseImportedFile(file, state.criteria);
      if (!replaceOnImport) {
        const key = ({ name, province }: Alternative) =>
          JSON.stringify([name.toLowerCase(), province.toLowerCase()]);
        const existing = new Set(state.alternatives.map(key));
        const duplicate = alternatives.find((alt) => existing.has(key(alt)));
        if (duplicate) {
          throw new Error(`${duplicate.name} sudah ada. Pilih “Ganti data lama saat import” untuk memuat ulang.`);
        }
      }
      importAlternatives(alternatives, replaceOnImport);
      setImportFeedback({
        type: 'ok',
        message: `Berhasil mengimpor ${alternatives.length} kabupaten dari ${file.name}.`,
      });
      setPage(1);
    } catch (err) {
      setImportFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Gagal membaca file Excel/CSV.',
      });
    } finally {
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Data Alternatif Kabupaten"
        description="Kelola matriks keputusan alternatif kabupaten beserta nilai indikator setiap kriteria. Mendukung CRUD penuh, import/export Excel & CSV, serta preset data simulasi DEMO."
        statusLabel={`${state.alternatives.length} kabupaten terdaftar · ${
          state.datasetMode === 'PENELITIAN' ? STUDY_SOURCE : state.datasetMode
        }`}
        statusTone={state.alternatives.length >= 2 ? 'ok' : 'warning'}
        actions={
          <>
            <button
              type="button"
              onClick={() =>
                exportAlternativesToExcel(state.alternatives, activeCriteria)
              }
              disabled={state.alternatives.length === 0}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap"
            >
              <FileSpreadsheet className="h-3.5 w-3.5" />
              <span>Export Excel</span>
            </button>
            <button
              type="button"
              onClick={() =>
                exportAlternativesToCSV(state.alternatives, activeCriteria)
              }
              disabled={state.alternatives.length === 0}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
            {isAdmin && (
              <button
                type="button"
                onClick={openAddModal}
                className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800 transition-colors whitespace-nowrap"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>Tambah Alternatif</span>
              </button>
            )}
          </>
        }
      />

      {!isAdmin && <ReadOnlyNotice />}

      {/* Preset & Import Bar (khusus Admin) */}
      {isAdmin && (
      <div className="rounded-xl border border-slate-200 bg-white p-4 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-600 mr-1">
            Dataset Cepat:
          </span>
          <button
            type="button"
            onClick={() => {
              if (!window.confirm('Muat ulang data dan pengaturan penelitian Aliansi Kyubi?')) return;
              loadPreset('PENELITIAN');
              setImportFeedback(null);
              setPage(1);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors whitespace-nowrap ${
              state.datasetMode === 'PENELITIAN'
                ? 'bg-blue-50 border-blue-300 text-blue-800'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Data Penelitian 62 Kab.
          </button>
          <button
            type="button"
            onClick={() => {
              loadPreset('DEMO_62');
              setPage(1);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors whitespace-nowrap ${
              state.datasetMode === 'DEMO_62'
                ? 'bg-blue-50 border-blue-300 text-blue-800'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            DEMO 62 Kab. (Perpres 63/2020)
          </button>
          <button
            type="button"
            onClick={() => {
              loadPreset('DEMO_12');
              setPage(1);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors whitespace-nowrap ${
              state.datasetMode === 'DEMO_12'
                ? 'bg-blue-50 border-blue-300 text-blue-800'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Mini DEMO 12 Kab.
          </button>
          <button
            type="button"
            onClick={() => {
              loadPreset('KOSONG');
              setPage(1);
            }}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors whitespace-nowrap ${
              state.datasetMode === 'KOSONG'
                ? 'bg-slate-900 border-slate-900 text-white'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            Mulai Kosong (Nol)
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
            <input
              type="checkbox"
              checked={replaceOnImport}
              onChange={(e) => setReplaceOnImport(e.target.checked)}
              className="rounded border-slate-300 text-blue-600"
            />
            <span>Ganti data lama saat import</span>
          </label>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            onChange={handleFileUpload}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-blue-800 hover:bg-blue-100 transition-colors whitespace-nowrap"
          >
            <Upload className="h-3.5 w-3.5" />
            <span>Import Excel / CSV</span>
          </button>
        </div>
      </div>
      )}

      {importFeedback && (
        <div
          role={importFeedback.type === 'error' ? 'alert' : 'status'}
          className={`rounded-xl border px-4 py-3 text-xs ${
            importFeedback.type === 'ok'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
              : 'border-rose-200 bg-rose-50 text-rose-900'
          }`}
        >
          {importFeedback.message}
        </div>
      )}

      {state.datasetMode.startsWith('DEMO') && (
        <div className="flex items-start gap-2.5 rounded-xl border border-amber-200 bg-amber-50/60 px-4 py-3 text-xs text-amber-900">
          <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0 mt-0.5" />
          <span>
            Baris bertanda <span className="font-mono font-semibold">[DEMO]</span> menggunakan
            nilai indikator simulasi (kecuali baris Nduga yang diambil dari Tabel 4.3 laporan).
            Pilih Data Penelitian 62 Kab. untuk kembali ke dataset tugas.
          </span>
        </div>
      )}

      {/* Search, Filter, Page size */}
      <div className="rounded-xl border border-slate-200 bg-white">
        <div className="flex flex-col gap-3 border-b border-slate-200 p-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-1 flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[220px] max-w-sm">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Cari kabupaten atau provinsi..."
                className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-9 pr-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none"
              />
            </div>

            <select
              value={provinceFilter}
              onChange={(e) => {
                setProvinceFilter(e.target.value);
                setPage(1);
              }}
              className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-700 focus:border-blue-500 focus:outline-none"
            >
              <option value="ALL">Semua Provinsi ({provinces.length})</option>
              {provinces.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span>Tampilkan</span>
            <select
              value={pageSize}
              onChange={(e) => {
                setPageSize(Number(e.target.value));
                setPage(1);
              }}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-700"
            >
              <option value={10}>10</option>
              <option value={15}>15</option>
              <option value={30}>30</option>
              <option value={100}>100</option>
            </select>
            <span>dari {filtered.length} data</span>
          </div>
        </div>

        {/* Mode input nilai manual (Admin) */}
        {isAdmin && (
          <div
            className={`flex flex-col gap-2 border-b px-4 py-3 text-xs md:flex-row md:items-center md:justify-between ${
              editing ? 'border-blue-200 bg-blue-50/70' : 'border-slate-200 bg-slate-50/60'
            }`}
          >
            <div className="flex items-start gap-2.5">
              <Keyboard className={`h-4 w-4 shrink-0 mt-0.5 ${editing ? 'text-blue-700' : 'text-slate-500'}`} />
              <div className="text-slate-700">
                {editing ? (
                  <>
                    <span className="font-semibold text-blue-900">Mode Input Nilai aktif.</span>{' '}
                    Ketik nilai langsung pada sel kriteria; Linear BWM, agregasi, MARCOS, dan ranking
                    diperbarui otomatis.
                    {top1 && (
                      <span className="ml-1 font-medium text-slate-800">
                        Prioritas #1 saat ini:{' '}
                        <span className="font-semibold">{top1.name}</span> (f(Ki) ={' '}
                        <span className="font-mono">{top1.fK.toFixed(4)}</span>
                        {!isMarcosFresh ? ', kedaluwarsa' : ''}).
                      </span>
                    )}
                  </>
                ) : (
                  'Mode lihat. Aktifkan Mode Input Nilai untuk mengetik nilai langsung di tabel.'
                )}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setInputMode((v) => !v)}
              className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold whitespace-nowrap ${
                editing
                  ? 'border border-blue-300 bg-white text-blue-800 hover:bg-blue-50'
                  : 'bg-blue-700 text-white hover:bg-blue-800'
              }`}
            >
              <Keyboard className="h-3.5 w-3.5" />
              <span>{editing ? 'Selesai (Mode Lihat)' : 'Aktifkan Mode Input Nilai'}</span>
            </button>
          </div>
        )}

        {/* Table */}
        {filtered.length === 0 ? (
          <div className="p-12 text-center">
            <p className="text-sm font-medium text-slate-700">
              Belum ada data alternatif yang sesuai.
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Tambahkan alternatif secara manual, import file Excel/CSV, atau muat Dataset DEMO.
            </p>
            <button
              type="button"
              onClick={openAddModal}
              hidden={!isAdmin}
              className="mt-4 inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Tambah Alternatif Pertama</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-slate-600">
                  <th className="py-3 px-3 font-medium w-10">#</th>
                  <th className="py-3 px-3 font-medium">
                    <button
                      type="button"
                      onClick={() => toggleSort('name')}
                      className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap"
                    >
                      <span>Kabupaten</span>
                      <ArrowDownUp className="h-3 w-3" />
                    </button>
                  </th>
                  <th className="py-3 px-3 font-medium">
                    <button
                      type="button"
                      onClick={() => toggleSort('province')}
                      className="inline-flex items-center gap-1 hover:text-slate-900 whitespace-nowrap"
                    >
                      <span>Provinsi</span>
                      <ArrowDownUp className="h-3 w-3" />
                    </button>
                  </th>
                  {activeCriteria.map((c) => (
                    <th key={c.id} className="py-3 px-3 font-medium text-right">
                      <button
                        type="button"
                        onClick={() => toggleSort(c.id)}
                        className="inline-flex items-center justify-end gap-1 hover:text-slate-900 whitespace-nowrap"
                        title={`${c.name} (${c.type} · ${c.unit})`}
                      >
                        <span>{c.code}</span>
                        <ArrowDownUp className="h-3 w-3" />
                      </button>
                    </th>
                  ))}
                  {editing && (
                    <th className="py-3 px-3 font-medium text-right whitespace-nowrap">Rank MARCOS</th>
                  )}
                  {isAdmin && <th className="py-3 px-3 font-medium text-right">Aksi</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {paginated.map((alt, idx) => (
                  <tr key={alt.id} className="hover:bg-slate-50/80">
                    <td className="py-2.5 px-3 font-mono text-slate-400 tabular-nums">
                      {(safePage - 1) * pageSize + idx + 1}
                    </td>
                    <td className="py-2.5 px-3 font-medium text-slate-900 whitespace-nowrap">
                      {alt.name}
                      {alt.isDemo && (
                        <span className="ml-2 font-mono text-[10px] text-amber-700">
                          [DEMO]
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600 whitespace-nowrap">
                      {alt.province}
                    </td>
                    {activeCriteria.map((c) => {
                      const v = alt.values[c.id] ?? 0;
                      const isInvalidCost = c.type === 'Cost' && v <= 0;
                      return (
                        <td
                          key={c.id}
                          className={`py-2.5 px-3 text-right font-mono tabular-nums whitespace-nowrap ${
                            isInvalidCost ? 'text-rose-700 font-semibold' : 'text-slate-700'
                          }`}
                        >
                          {editing ? (
                            <ValueCell
                              value={v}
                              invalid={isInvalidCost}
                              label={`${c.code} ${alt.name}`}
                              onCommit={(nv) => updateAlternativeValue(alt.id, c.id, nv)}
                            />
                          ) : Number.isInteger(v) ? (
                            v.toLocaleString('id-ID')
                          ) : (
                            v.toFixed(2)
                          )}
                        </td>
                      );
                    })}
                    {editing && (
                      <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-900 tabular-nums whitespace-nowrap">
                        {marcosRank.get(alt.id) ? `#${marcosRank.get(alt.id)!.rank}` : '—'}
                      </td>
                    )}
                    {isAdmin && (
                    <td className="py-2.5 px-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEditModal(alt)}
                          className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-blue-700"
                          title="Edit alternatif"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteAlternative(alt.id)}
                          className="rounded p-1.5 text-slate-500 hover:bg-rose-50 hover:text-rose-700"
                          title="Hapus alternatif"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-slate-200 px-4 py-3 text-xs text-slate-600">
            <span className="tabular-nums">
              Halaman {safePage} dari {totalPages}
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={safePage <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 hover:bg-slate-50 disabled:opacity-40"
              >
                Sebelumnya
              </button>
              <button
                type="button"
                disabled={safePage >= totalPages}
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 hover:bg-slate-50 disabled:opacity-40"
              >
                Berikutnya
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-xl border border-slate-200 bg-white p-6 shadow-xl">
            <h2 className="font-display text-lg font-bold text-slate-900">
              {editingAlt ? `Edit Alternatif: ${editingAlt.name}` : 'Tambah Alternatif Kabupaten'}
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Masukkan nama kabupaten, provinsi, serta nilai indikator untuk seluruh kriteria.
            </p>

            <form onSubmit={handleSaveModal} className="mt-5 space-y-4">
              {formError && (
                <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-800">
                  {formError}
                </div>
              )}

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Nama Kabupaten
                  </label>
                  <input
                    type="text"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Contoh: Nduga"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Provinsi
                  </label>
                  <input
                    type="text"
                    value={formProvince}
                    onChange={(e) => setFormProvince(e.target.value)}
                    placeholder="Contoh: Papua"
                    className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="border-t border-slate-200 pt-4">
                <div className="text-xs font-semibold text-slate-700 mb-3">
                  Nilai Indikator Kriteria
                </div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {state.criteria.map((c) => (
                    <div key={c.id}>
                      <label className="block text-xs text-slate-700 mb-1">
                        <span className="font-mono font-semibold">{c.code}</span> · {c.name}{' '}
                        <span className="text-slate-400">({c.unit})</span>
                      </label>
                      <input
                        type="number"
                        step="any"
                        value={formValues[c.id] ?? ''}
                        onChange={(e) =>
                          setFormValues((prev) => ({ ...prev, [c.id]: e.target.value }))
                        }
                        className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-mono text-sm tabular-nums focus:border-blue-500 focus:outline-none"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                >
                  Simpan Alternatif
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
