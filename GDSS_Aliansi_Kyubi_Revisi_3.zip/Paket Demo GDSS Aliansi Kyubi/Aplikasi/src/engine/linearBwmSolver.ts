import type { BWMAssessment, BWMResult, Criterion } from '../types/gdss';

const EPS = 1e-10;

export interface LinearBWMInputValidation {
  valid: boolean;
  errors: string[];
}

export function validateBWMInput(
  assessment: BWMAssessment | undefined,
  activeCriteria: Criterion[]
): LinearBWMInputValidation {
  const errors: string[] = [];

  if (activeCriteria.length < 2) {
    errors.push('Minimal harus terdapat 2 kriteria aktif untuk menjalankan Linear BWM.');
    return { valid: false, errors };
  }

  if (!assessment) {
    errors.push('Penilaian BWM untuk Decision Maker ini belum diisi.');
    return { valid: false, errors };
  }

  const ids = new Set(activeCriteria.map((c) => c.id));
  if (!assessment.bestCriterionId || !ids.has(assessment.bestCriterionId)) {
    errors.push('Kriteria Terbaik (Best) belum dipilih atau tidak aktif.');
  }
  if (!assessment.worstCriterionId || !ids.has(assessment.worstCriterionId)) {
    errors.push('Kriteria Terburuk (Worst) belum dipilih atau tidak aktif.');
  }
  if (
    assessment.bestCriterionId &&
    assessment.worstCriterionId &&
    assessment.bestCriterionId === assessment.worstCriterionId
  ) {
    errors.push('Kriteria Terbaik (Best) dan Terburuk (Worst) tidak boleh sama.');
  }

  for (const c of activeCriteria) {
    const boVal = assessment.bo[c.id];
    const owVal = assessment.ow[c.id];
    if (typeof boVal !== 'number' || Number.isNaN(boVal) || boVal < 1 || boVal > 9) {
      errors.push(`Nilai Best-to-Others untuk ${c.code} (${c.name}) harus antara 1 sampai 9.`);
    }
    if (typeof owVal !== 'number' || Number.isNaN(owVal) || owVal < 1 || owVal > 9) {
      errors.push(`Nilai Others-to-Worst untuk ${c.code} (${c.name}) harus antara 1 sampai 9.`);
    }
  }

  if (assessment.bestCriterionId && ids.has(assessment.bestCriterionId)) {
    if (assessment.bo[assessment.bestCriterionId] !== 1) {
      errors.push('Nilai perbandingan Best terhadap dirinya sendiri (aBB) harus sama dengan 1.');
    }
  }
  if (assessment.worstCriterionId && ids.has(assessment.worstCriterionId)) {
    if (assessment.ow[assessment.worstCriterionId] !== 1) {
      errors.push('Nilai perbandingan Worst terhadap dirinya sendiri (aWW) harus sama dengan 1.');
    }
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Computes Input-Based Consistency Ratio (CRI) proposed by Liang, Brunelli, & Rezaei (2020):
 * CRI = max_j ( |a_Bj * a_jW - a_BW| / (a_BW^2 - a_BW) )
 */
export function computeInputBasedCRI(
  assessment: BWMAssessment,
  activeCriteria: Criterion[]
): number {
  const aBW = assessment.bo[assessment.worstCriterionId] ?? 1;
  if (aBW <= 1) {
    const anyDeviation = activeCriteria.some((c) => {
      const aBj = assessment.bo[c.id] ?? 1;
      const ajW = assessment.ow[c.id] ?? 1;
      return Math.abs(aBj * ajW - aBW) > EPS;
    });
    return anyDeviation ? 1 : 0;
  }

  const denom = aBW * aBW - aBW;
  let maxVal = 0;
  for (const c of activeCriteria) {
    const aBj = assessment.bo[c.id] ?? 1;
    const ajW = assessment.ow[c.id] ?? 1;
    const ratio = Math.abs(aBj * ajW - aBW) / denom;
    if (ratio > maxVal) {
      maxVal = ratio;
    }
  }
  return maxVal;
}

/**
 * Solves Rezaei (2016) Linear Best-Worst Method using Two-Phase Simplex LP with Bland's anti-cycling rule.
 *
 * Variables: x = [w_0, w_1, ..., w_{n-1}, xi] >= 0
 * Minimize xi
 * Subject to:
 *   w_B - a_{B,j} * w_j - xi <= 0   (for all j != B)
 *  -w_B + a_{B,j} * w_j - xi <= 0   (for all j != B)
 *   w_j - a_{j,W} * w_W - xi <= 0   (for all j != W)
 *  -w_j + a_{j,W} * w_W - xi <= 0   (for all j != W)
 *   sum_{j=0}^{n-1} w_j = 1
 */
export function solveLinearBWM(
  dmId: string,
  assessment: BWMAssessment,
  activeCriteria: Criterion[],
  crThreshold = 0.284
): BWMResult {
  const validation = validateBWMInput(assessment, activeCriteria);
  const now = new Date().toISOString();

  if (!validation.valid) {
    return {
      dmId,
      weights: {},
      xi: 0,
      cri: 0,
      threshold: crThreshold,
      isConsistent: false,
      constraintCheckOk: false,
      maxResidual: 0,
      totalWeight: 0,
      computedAt: now,
      stale: false,
      error: validation.errors[0],
    };
  }

  const n = activeCriteria.length;
  const idxMap = new Map<string, number>();
  activeCriteria.forEach((c, idx) => idxMap.set(c.id, idx));

  const bestIdx = idxMap.get(assessment.bestCriterionId)!;
  const worstIdx = idxMap.get(assessment.worstCriterionId)!;
  const xiCol = n;

  // Build inequality rows (<= 0)
  const ineqRows: number[][] = [];
  for (let j = 0; j < n; j++) {
    if (j !== bestIdx) {
      const aBj = assessment.bo[activeCriteria[j].id];
      const row1 = new Array(n + 1).fill(0);
      row1[bestIdx] = 1;
      row1[j] = -aBj;
      row1[xiCol] = -1;
      ineqRows.push(row1);

      const row2 = new Array(n + 1).fill(0);
      row2[bestIdx] = -1;
      row2[j] = aBj;
      row2[xiCol] = -1;
      ineqRows.push(row2);
    }
    if (j !== worstIdx) {
      const ajW = assessment.ow[activeCriteria[j].id];
      const row3 = new Array(n + 1).fill(0);
      row3[j] = 1;
      row3[worstIdx] = -ajW;
      row3[xiCol] = -1;
      ineqRows.push(row3);

      const row4 = new Array(n + 1).fill(0);
      row4[j] = -1;
      row4[worstIdx] = ajW;
      row4[xiCol] = -1;
      ineqRows.push(row4);
    }
  }

  const mIneq = ineqRows.length;
  const numRows = mIneq + 1; // +1 for sum(w) = 1
  const slackStart = n + 1;
  const artCol = n + 1 + mIneq;
  const totalColsPhase1 = artCol + 1;

  // Build Phase 1 tableau: rows 0..numRows-1, plus objective row at index numRows
  // Each row has [coeffs..., rhs]
  const tableau: number[][] = Array.from({ length: numRows + 1 }, () =>
    new Array(totalColsPhase1 + 1).fill(0)
  );

  for (let r = 0; r < mIneq; r++) {
    for (let c = 0; c <= n; c++) {
      tableau[r][c] = ineqRows[r][c];
    }
    tableau[r][slackStart + r] = 1;
    tableau[r][totalColsPhase1] = 0; // RHS = 0
  }

  // Equality row: sum_{j=0}^{n-1} w_j + a_0 = 1
  const eqRow = mIneq;
  for (let j = 0; j < n; j++) {
    tableau[eqRow][j] = 1;
  }
  tableau[eqRow][artCol] = 1;
  tableau[eqRow][totalColsPhase1] = 1; // RHS = 1

  const basis: number[] = [];
  for (let r = 0; r < mIneq; r++) {
    basis.push(slackStart + r);
  }
  basis.push(artCol);

  // Phase 1 Objective: Minimize artificial variable a_0
  // Canonical form: z - sum(w_j) = -1  (Wait: min a_0 => z = a_0 = 1 - sum w_j => z + sum w_j = 1 -> reduced cost of w_j is -1)
  // Let's keep objective row as: z + sum(r_c * x_c) = z_val, where pivoting eliminates negative r_c
  // Wait: if we store row = [c_0..c_k, rhs] where c_j is reduced cost (we want c_j >= 0 for minimization),
  // z = rhs - sum(r_j * x_j). Actually simpler:
  // Standard row: z - sum(r_j * x_j) = z_0, wait let's be crystal clear:
  // If objRow stores r_j = c_j - c_B^T B^{-1} A_j, and objRow[rhs] stores -z_0 (or z_0):
  // Let's explicitly do row operation: start with objRow = [0,...,0, 1 (at artCol), 0 (rhs)]
  // Subtract 1 * eqRow from objRow so artCol becomes 0:
  // objRow becomes [-1, -1, ..., -1 (for w_0..w_{n-1}), 0 (xi), 0 (slacks), 0 (artCol), -1 (rhs = -z_val)]
  // When we do standard Gauss-Jordan pivot on (pivotRow, pivotCol) INCLUDING objRow:
  // objRow[j] -= factor * pivotRow[j].
  // A column j with objRow[j] < -EPS can improve (decrease) z!
  tableau[numRows][artCol] = 1;
  for (let c = 0; c <= totalColsPhase1; c++) {
    tableau[numRows][c] -= tableau[eqRow][c];
  }

  const runSimplex = (numCols: number) => {
    const rhsCol = numCols;
    const maxIter = 5000;
    for (let iter = 0; iter < maxIter; iter++) {
      // Bland's rule: first column with reduced cost < -EPS
      let enterCol = -1;
      for (let c = 0; c < numCols; c++) {
        if (tableau[numRows][c] < -EPS) {
          enterCol = c;
          break;
        }
      }
      if (enterCol === -1) {
        return true; // Optimal reached
      }

      // Ratio test with Bland's tie-breaker (smallest basic variable index)
      let leaveRow = -1;
      let minRatio = Infinity;
      for (let r = 0; r < numRows; r++) {
        const a = tableau[r][enterCol];
        if (a > EPS) {
          const rhs = Math.max(0, tableau[r][rhsCol]);
          const ratio = rhs / a;
          if (
            ratio < minRatio - EPS ||
            (Math.abs(ratio - minRatio) <= EPS &&
              leaveRow !== -1 &&
              basis[r] < basis[leaveRow])
          ) {
            minRatio = ratio;
            leaveRow = r;
          }
        }
      }

      if (leaveRow === -1) {
        return false; // Unbounded
      }

      // Pivot on (leaveRow, enterCol)
      const pivotVal = tableau[leaveRow][enterCol];
      for (let c = 0; c <= rhsCol; c++) {
        tableau[leaveRow][c] /= pivotVal;
      }
      for (let r = 0; r <= numRows; r++) {
        if (r === leaveRow) continue;
        const factor = tableau[r][enterCol];
        if (Math.abs(factor) > EPS) {
          for (let c = 0; c <= rhsCol; c++) {
            tableau[r][c] -= factor * tableau[leaveRow][c];
          }
        }
      }
      basis[leaveRow] = enterCol;
    }
    return false;
  };

  const phase1Ok = runSimplex(totalColsPhase1);
  if (!phase1Ok || Math.abs(-tableau[numRows][totalColsPhase1]) > 1e-6) {
    return {
      dmId,
      weights: {},
      xi: 0,
      cri: computeInputBasedCRI(assessment, activeCriteria),
      threshold: crThreshold,
      isConsistent: false,
      constraintCheckOk: false,
      maxResidual: 1,
      totalWeight: 0,
      computedAt: now,
      stale: false,
      error: 'Model Linear BWM tidak menemukan solusi layak (Phase I gagal).',
    };
  }

  // If artificial column is still in basis (with value ~0), pivot it out
  const artRowIdx = basis.indexOf(artCol);
  if (artRowIdx !== -1) {
    let swapCol = -1;
    for (let c = 0; c < artCol; c++) {
      if (Math.abs(tableau[artRowIdx][c]) > 1e-8) {
        swapCol = c;
        break;
      }
    }
    if (swapCol !== -1) {
      const pv = tableau[artRowIdx][swapCol];
      for (let c = 0; c <= totalColsPhase1; c++) {
        tableau[artRowIdx][c] /= pv;
      }
      for (let r = 0; r <= numRows; r++) {
        if (r === artRowIdx) continue;
        const f = tableau[r][swapCol];
        if (Math.abs(f) > EPS) {
          for (let c = 0; c <= totalColsPhase1; c++) {
            tableau[r][c] -= f * tableau[artRowIdx][c];
          }
        }
      }
      basis[artRowIdx] = swapCol;
    }
  }

  // Build Phase 2 tableau (drop artificial column)
  const totalColsPhase2 = artCol;
  for (let r = 0; r < numRows; r++) {
    tableau[r][totalColsPhase2] = tableau[r][totalColsPhase1];
  }

  // Phase 2 objective: Minimize xi (column xiCol has cost 1, others 0)
  for (let c = 0; c <= totalColsPhase2; c++) {
    tableau[numRows][c] = 0;
  }
  tableau[numRows][xiCol] = 1;

  // Eliminate basic variables from objective row
  for (let r = 0; r < numRows; r++) {
    const bCol = basis[r];
    if (bCol === xiCol) {
      for (let c = 0; c <= totalColsPhase2; c++) {
        tableau[numRows][c] -= tableau[r][c];
      }
    }
  }

  const phase2Ok = runSimplex(totalColsPhase2);
  if (!phase2Ok) {
    return {
      dmId,
      weights: {},
      xi: 0,
      cri: computeInputBasedCRI(assessment, activeCriteria),
      threshold: crThreshold,
      isConsistent: false,
      constraintCheckOk: false,
      maxResidual: 1,
      totalWeight: 0,
      computedAt: now,
      stale: false,
      error: 'Optimasi Simplex Phase II tidak konvergen.',
    };
  }

  // Extract solution
  const sol = new Array(n + 1).fill(0);
  for (let r = 0; r < numRows; r++) {
    const bCol = basis[r];
    if (bCol <= xiCol) {
      sol[bCol] = Math.max(0, tableau[r][totalColsPhase2]);
    }
  }

  const weights: Record<string, number> = {};
  let totalWeight = 0;
  activeCriteria.forEach((c, idx) => {
    weights[c.id] = sol[idx];
    totalWeight += sol[idx];
  });
  const xi = sol[xiCol];

  // Verify constraints directly against original BWM formulation
  let maxDeviation = 0;
  for (let j = 0; j < n; j++) {
    if (j !== bestIdx) {
      const aBj = assessment.bo[activeCriteria[j].id];
      const dev = Math.abs(sol[bestIdx] - aBj * sol[j]);
      if (dev > maxDeviation) maxDeviation = dev;
    }
    if (j !== worstIdx) {
      const ajW = assessment.ow[activeCriteria[j].id];
      const dev = Math.abs(sol[j] - ajW * sol[worstIdx]);
      if (dev > maxDeviation) maxDeviation = dev;
    }
  }
  const maxResidual = Math.max(0, maxDeviation - xi);
  const constraintCheckOk =
    maxResidual <= 1e-6 && Math.abs(totalWeight - 1) <= 1e-6 && xi >= -1e-9;

  const cri = computeInputBasedCRI(assessment, activeCriteria);
  const isConsistent = cri <= crThreshold + 1e-9;

  return {
    dmId,
    weights,
    xi,
    cri,
    threshold: crThreshold,
    isConsistent,
    constraintCheckOk,
    maxResidual,
    totalWeight,
    computedAt: now,
    stale: false,
  };
}
