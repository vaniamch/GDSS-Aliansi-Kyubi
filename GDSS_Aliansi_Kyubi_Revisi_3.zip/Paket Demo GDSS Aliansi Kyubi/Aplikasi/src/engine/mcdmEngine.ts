import type {
  Alternative,
  BWMResult,
  ComparisonResult,
  ConsensusAnalysisResult,
  Criterion,
  DecisionMaker,
  GroupAggregationResult,
  MARCOSAlternativeRow,
  MARCOSResult,
  SensitivityScenario,
} from '../types/gdss';

const EPS = 1e-12;

export function getRecommendedProgram(criterion: Criterion | undefined): string {
  if (!criterion) return 'Intervensi lintas sektor terpadu';
  const code = criterion.code.toUpperCase();
  const nameLower = criterion.name.toLowerCase();

  if (code === 'C1' || nameLower.includes('miskin') || nameLower.includes('p0')) {
    return 'Bansos & pemberdayaan ekonomi';
  }
  if (code === 'C2' || nameLower.includes('sekolah') || nameLower.includes('pendidikan')) {
    return 'Akses & beasiswa pendidikan';
  }
  if (code === 'C3' || nameLower.includes('pengeluaran') || nameLower.includes('daya beli')) {
    return 'Peningkatan daya beli / padat karya';
  }
  if (code === 'C4' || nameLower.includes('harapan hidup') || nameLower.includes('kesehatan')) {
    return 'Layanan kesehatan dasar';
  }
  if (code === 'C5' || nameLower.includes('sanitasi')) {
    return 'Program sanitasi (STBM)';
  }
  if (code === 'C6' || nameLower.includes('air minum')) {
    return 'Penyediaan air minum (SPAM)';
  }
  if (code === 'C7' || nameLower.includes('pengangguran') || nameLower.includes('tpt')) {
    return 'Pelatihan kerja & UMKM';
  }
  if (code === 'C8' || nameLower.includes('pdrb')) {
    return 'Infrastruktur ekonomi wilayah';
  }
  return `Program prioritas ${criterion.name}`;
}

/**
 * Weighted Geometric Mean aggregation + Coefficient of Variation (CV = STDEV.S / MEAN)
 */
export function computeGroupAggregation(
  activeCriteria: Criterion[],
  activeDMs: DecisionMaker[],
  bwmResults: Record<string, BWMResult>
): { result: GroupAggregationResult | null; error?: string } {
  if (activeCriteria.length === 0) {
    return { result: null, error: 'Tidak ada kriteria aktif.' };
  }
  if (activeDMs.length === 0) {
    return { result: null, error: 'Tidak ada Decision Maker aktif.' };
  }

  const lambdaSum = activeDMs.reduce((acc, dm) => acc + dm.lambda, 0);
  if (Math.abs(lambdaSum - 1) > 1e-4) {
    return {
      result: null,
      error: `Total bobot kepentingan Decision Maker (Σλ) saat ini ${lambdaSum.toFixed(4)}, harus tepat sama dengan 1,0000.`,
    };
  }

  for (const dm of activeDMs) {
    const res = bwmResults[dm.id];
    if (!res || res.error || res.stale || !res.constraintCheckOk) {
      return {
        result: null,
        error: `Hasil Linear BWM untuk ${dm.name} belum tersedia, tidak valid, atau kedaluwarsa. Jalankan optimasi BWM terlebih dahulu.`,
      };
    }
    for (const c of activeCriteria) {
      if (typeof res.weights[c.id] !== 'number' || Number.isNaN(res.weights[c.id])) {
        return {
          result: null,
          error: `Bobot kriteria ${c.code} untuk ${dm.name} tidak ditemukan. Jalankan ulang Solver BWM.`,
        };
      }
    }
  }

  const geoMeans: Record<string, number> = {};
  const weights: Record<string, number> = {};
  const mean: Record<string, number> = {};
  const stdDev: Record<string, number> = {};
  const cv: Record<string, number> = {};

  let geoMeanSum = 0;

  for (const c of activeCriteria) {
    let prod = 1;
    const dmVals: number[] = [];
    for (const dm of activeDMs) {
      const w = Math.max(bwmResults[dm.id].weights[c.id] ?? 0, 1e-12);
      dmVals.push(bwmResults[dm.id].weights[c.id] ?? 0);
      prod *= Math.pow(w, dm.lambda);
    }
    geoMeans[c.id] = prod;
    geoMeanSum += prod;

    const avg = dmVals.reduce((s, v) => s + v, 0) / dmVals.length;
    mean[c.id] = avg;
    if (dmVals.length > 1) {
      const variance =
        dmVals.reduce((s, v) => s + Math.pow(v - avg, 2), 0) / (dmVals.length - 1);
      stdDev[c.id] = Math.sqrt(variance);
    } else {
      stdDev[c.id] = 0;
    }
    cv[c.id] = avg > EPS ? stdDev[c.id] / avg : 0;
  }

  if (geoMeanSum <= EPS) {
    return { result: null, error: 'Jumlah rata-rata geometrik bernilai nol.' };
  }

  for (const c of activeCriteria) {
    weights[c.id] = geoMeans[c.id] / geoMeanSum;
  }

  let highestAgreementCode = activeCriteria[0].code;
  let lowestCv = Infinity;
  let highestDisagreementCode = activeCriteria[0].code;
  let highestCv = -Infinity;

  for (const c of activeCriteria) {
    if (cv[c.id] < lowestCv) {
      lowestCv = cv[c.id];
      highestAgreementCode = c.code;
    }
    if (cv[c.id] > highestCv) {
      highestCv = cv[c.id];
      highestDisagreementCode = c.code;
    }
  }

  return {
    result: {
      weights,
      geoMeans,
      geoMeanSum,
      cv,
      stdDev,
      mean,
      highestAgreementCode,
      highestDisagreementCode,
      computedAt: new Date().toISOString(),
      stale: false,
    },
  };
}

/**
 * Validates decision matrix before running MARCOS / TOPSIS / SAW
 */
export function validateDecisionMatrix(
  alternatives: Alternative[],
  activeCriteria: Criterion[],
  weights: Record<string, number>
): string[] {
  const errors: string[] = [];
  if (alternatives.length < 2) {
    errors.push('Minimal harus terdapat 2 alternatif kabupaten untuk melakukan pemeringkatan.');
  }
  if (activeCriteria.length === 0) {
    errors.push('Minimal harus terdapat 1 kriteria aktif.');
  }

  const wSum = activeCriteria.reduce((acc, c) => acc + (weights[c.id] ?? 0), 0);
  if (Math.abs(wSum - 1) > 1e-3) {
    errors.push(`Total bobot kriteria (${wSum.toFixed(4)}) harus sama dengan 1.`);
  }

  for (const c of activeCriteria) {
    let hasPositive = false;
    for (const alt of alternatives) {
      const val = alt.values[c.id];
      if (typeof val !== 'number' || Number.isNaN(val)) {
        errors.push(`Nilai kriteria ${c.code} (${c.name}) pada ${alt.name} kosong atau bukan angka.`);
        if (errors.length > 6) return errors;
      } else {
        if (c.type === 'Cost' && val <= 0) {
          errors.push(
            `Kriteria Cost ${c.code} (${c.name}) memiliki nilai ≤ 0 (${val}) pada ${alt.name}. Normalisasi MARCOS (x_AI / x_ij) akan menyebabkan pembagian nol.`
          );
          if (errors.length > 6) return errors;
        }
        if (c.type === 'Benefit' && val < 0) {
          errors.push(
            `Kriteria Benefit ${c.code} (${c.name}) memiliki nilai negatif (${val}) pada ${alt.name}.`
          );
          if (errors.length > 6) return errors;
        }
        if (val > 0) hasPositive = true;
      }
    }
    if (c.type === 'Benefit' && alternatives.length > 0 && !hasPositive) {
      errors.push(
        `Kriteria Benefit ${c.code} (${c.name}) bernilai 0 di seluruh alternatif sehingga nilai AI = 0 (pembagian nol).`
      );
    }
  }

  return errors;
}

/**
 * Stevic, Pamucar, Puska, & Chatterjee (2020) MARCOS Solver
 */
export function computeMARCOS(
  alternatives: Alternative[],
  activeCriteria: Criterion[],
  weights: Record<string, number>
): { result: MARCOSResult | null; errors: string[] } {
  const errors = validateDecisionMatrix(alternatives, activeCriteria, weights);
  if (errors.length > 0) {
    return { result: null, errors };
  }

  const warnings: string[] = [];
  const aai: Record<string, number> = {};
  const ai: Record<string, number> = {};

  for (const c of activeCriteria) {
    const vals = alternatives.map((a) => a.values[c.id]);
    const minVal = Math.min(...vals);
    const maxVal = Math.max(...vals);
    if (c.type === 'Benefit') {
      aai[c.id] = minVal;
      ai[c.id] = maxVal;
    } else {
      aai[c.id] = maxVal;
      ai[c.id] = minVal;
    }
    if (Math.abs(maxVal - minVal) <= EPS) {
      warnings.push(
        `Kriteria ${c.code} (${c.name}) memiliki nilai seragam di seluruh alternatif.`
      );
    }
  }

  const nAai: Record<string, number> = {};
  const nAi: Record<string, number> = {};
  const vAai: Record<string, number> = {};
  const vAi: Record<string, number> = {};
  let sAai = 0;
  let sAi = 0;

  for (const c of activeCriteria) {
    const w = weights[c.id] ?? 0;
    if (c.type === 'Benefit') {
      nAai[c.id] = Math.abs(ai[c.id]) > EPS ? aai[c.id] / ai[c.id] : 0;
      nAi[c.id] = Math.abs(ai[c.id]) > EPS ? ai[c.id] / ai[c.id] : 0;
    } else {
      nAai[c.id] = Math.abs(aai[c.id]) > EPS ? ai[c.id] / aai[c.id] : 0;
      nAi[c.id] = Math.abs(ai[c.id]) > EPS ? ai[c.id] / ai[c.id] : 0;
    }
    vAai[c.id] = nAai[c.id] * w;
    vAi[c.id] = nAi[c.id] * w;
    sAai += vAai[c.id];
    sAi += vAi[c.id];
  }

  if (sAai <= EPS || sAi <= EPS) {
    return {
      result: null,
      errors: ['Nilai S_AAI atau S_AI bernilai nol sehingga derajat utilitas Ki tidak terdefinisi.'],
    };
  }

  const rows: MARCOSAlternativeRow[] = alternatives.map((alt) => {
    const rawValues: Record<string, number> = {};
    const normalizedValues: Record<string, number> = {};
    const weightedValues: Record<string, number> = {};
    const severityIndex: Record<string, number> = {};
    let si = 0;

    let maxSeverity = -Infinity;
    let mostCriticalCrit: Criterion | undefined = activeCriteria[0];

    for (const c of activeCriteria) {
      const x = alt.values[c.id];
      rawValues[c.id] = x;

      const nij = c.type === 'Benefit' ? x / ai[c.id] : ai[c.id] / x;
      normalizedValues[c.id] = nij;

      const vij = nij * (weights[c.id] ?? 0);
      weightedValues[c.id] = vij;
      si += vij;

      const denom = nAi[c.id] - nAai[c.id];
      const sev = Math.abs(denom) > EPS ? (nij - nAai[c.id]) / denom : 0;
      severityIndex[c.id] = sev;
      if (sev > maxSeverity) {
        maxSeverity = sev;
        mostCriticalCrit = c;
      }
    }

    const kMinus = si / sAai;
    const kPlus = si / sAi;
    const denomK = kMinus + kPlus;
    const fKMinus = denomK > EPS ? kPlus / denomK : 0;
    const fKPlus = denomK > EPS ? kMinus / denomK : 0;

    let fK = 0;
    if (fKMinus > EPS && fKPlus > EPS) {
      fK = (kMinus + kPlus) / (1 + (1 - fKPlus) / fKPlus + (1 - fKMinus) / fKMinus);
    }

    return {
      alternativeId: alt.id,
      name: alt.name,
      province: alt.province,
      rawValues,
      normalizedValues,
      weightedValues,
      si,
      kMinus,
      kPlus,
      fKMinus,
      fKPlus,
      fK,
      rank: 0,
      severityIndex,
      mostCriticalCriterionCode: mostCriticalCrit?.code ?? '-',
      mostCriticalCriterionName: mostCriticalCrit?.name ?? '-',
      recommendedProgram: getRecommendedProgram(mostCriticalCrit),
    };
  });

  // Sort descending by f(Ki), deterministic tie-break by name
  const sorted = [...rows].sort((a, b) => {
    if (Math.abs(b.fK - a.fK) > 1e-12) return b.fK - a.fK;
    return a.name.localeCompare(b.name, 'id');
  });
  sorted.forEach((row, idx) => {
    row.rank = idx + 1;
  });

  return {
    result: {
      aai,
      ai,
      nAai,
      nAi,
      vAai,
      vAi,
      sAai,
      sAi,
      rows: sorted,
      computedAt: new Date().toISOString(),
      stale: false,
      warnings,
    },
    errors: [],
  };
}

/**
 * Spearman rank correlation coefficient between two score/rank arrays matched by alternativeId.
 * Uses exact tie-aware Pearson correlation on average ranks (equivalent to 1 - 6*sum(d^2)/(n(n^2-1)) when no ties).
 */
export function computeSpearman(
  ranksA: Record<string, number>,
  ranksB: Record<string, number>,
  altIds: string[]
): number {
  const n = altIds.length;
  if (n < 2) return 1;

  const a = altIds.map((id) => ranksA[id] ?? 0);
  const b = altIds.map((id) => ranksB[id] ?? 0);

  const meanA = a.reduce((s, v) => s + v, 0) / n;
  const meanB = b.reduce((s, v) => s + v, 0) / n;

  let num = 0;
  let denA = 0;
  let denB = 0;
  for (let i = 0; i < n; i++) {
    const da = a[i] - meanA;
    const db = b[i] - meanB;
    num += da * db;
    denA += da * da;
    denB += db * db;
  }
  const den = Math.sqrt(denA * denB);
  return den > EPS ? num / den : 1;
}

/**
 * Comparative SAW & TOPSIS using the same group weights
 */
export function computeComparisonMethods(
  alternatives: Alternative[],
  activeCriteria: Criterion[],
  weights: Record<string, number>,
  marcosResult: MARCOSResult
): ComparisonResult | null {
  if (alternatives.length < 2 || activeCriteria.length === 0) return null;

  // SAW using MARCOS normalization (identical to S_i)
  const sawItems = marcosResult.rows.map((r) => ({
    id: r.alternativeId,
    name: r.name,
    score: r.si,
  }));
  sawItems.sort((a, b) => (Math.abs(b.score - a.score) > 1e-12 ? b.score - a.score : a.name.localeCompare(b.name)));
  const sawRanks: Record<string, { score: number; rank: number }> = {};
  sawItems.forEach((item, idx) => {
    sawRanks[item.id] = { score: item.score, rank: idx + 1 };
  });

  // TOPSIS: Vector normalization r_ij = x_ij / sqrt(sum x_ij^2)
  const norms: Record<string, number> = {};
  for (const c of activeCriteria) {
    const sumSq = alternatives.reduce((s, a) => s + Math.pow(a.values[c.id] ?? 0, 2), 0);
    norms[c.id] = Math.sqrt(sumSq);
  }

  const weightedMatrix: Record<string, Record<string, number>> = {};
  const aPlus: Record<string, number> = {};
  const aMinus: Record<string, number> = {};

  for (const alt of alternatives) {
    weightedMatrix[alt.id] = {};
    for (const c of activeCriteria) {
      const denom = norms[c.id];
      const rij = denom > EPS ? (alt.values[c.id] ?? 0) / denom : 0;
      weightedMatrix[alt.id][c.id] = rij * (weights[c.id] ?? 0);
    }
  }

  for (const c of activeCriteria) {
    const colVals = alternatives.map((a) => weightedMatrix[a.id][c.id]);
    const minV = Math.min(...colVals);
    const maxV = Math.max(...colVals);
    if (c.type === 'Benefit') {
      aPlus[c.id] = maxV;
      aMinus[c.id] = minV;
    } else {
      aPlus[c.id] = minV;
      aMinus[c.id] = maxV;
    }
  }

  const topsisItems = alternatives.map((alt) => {
    let sumSqPlus = 0;
    let sumSqMinus = 0;
    for (const c of activeCriteria) {
      const y = weightedMatrix[alt.id][c.id];
      sumSqPlus += Math.pow(y - aPlus[c.id], 2);
      sumSqMinus += Math.pow(y - aMinus[c.id], 2);
    }
    const dPlus = Math.sqrt(sumSqPlus);
    const dMinus = Math.sqrt(sumSqMinus);
    const cc = dPlus + dMinus > EPS ? dMinus / (dPlus + dMinus) : 0;
    return { id: alt.id, name: alt.name, dPlus, dMinus, cc };
  });

  topsisItems.sort((a, b) => (Math.abs(b.cc - a.cc) > 1e-12 ? b.cc - a.cc : a.name.localeCompare(b.name)));
  const topsisRanks: Record<string, { dPlus: number; dMinus: number; cc: number; rank: number }> = {};
  topsisItems.forEach((item, idx) => {
    topsisRanks[item.id] = {
      dPlus: item.dPlus,
      dMinus: item.dMinus,
      cc: item.cc,
      rank: idx + 1,
    };
  });

  const altIds = alternatives.map((a) => a.id);
  const marcosRankMap: Record<string, number> = {};
  const sawRankMap: Record<string, number> = {};
  const topsisRankMap: Record<string, number> = {};
  marcosResult.rows.forEach((r) => {
    marcosRankMap[r.alternativeId] = r.rank;
    sawRankMap[r.alternativeId] = sawRanks[r.alternativeId].rank;
    topsisRankMap[r.alternativeId] = topsisRanks[r.alternativeId].rank;
  });

  return {
    sawRanks,
    topsisRanks,
    spearmanMarcosTopsis: computeSpearman(marcosRankMap, topsisRankMap, altIds),
    spearmanMarcosSaw: computeSpearman(marcosRankMap, sawRankMap, altIds),
    spearmanTopsisSaw: computeSpearman(topsisRankMap, sawRankMap, altIds),
  };
}

/**
 * Consensus analysis: MARCOS per DM, Spearman matrix, Kendall's W, most debated / agreed
 */
export function computeConsensusAnalysis(
  alternatives: Alternative[],
  activeCriteria: Criterion[],
  activeDMs: DecisionMaker[],
  bwmResults: Record<string, BWMResult>,
  groupMarcos: MARCOSResult
): ConsensusAnalysisResult | null {
  if (alternatives.length < 2 || activeDMs.length === 0) return null;

  const dmRankings: Record<string, Record<string, { fK: number; rank: number }>> = {};
  const validDMs: DecisionMaker[] = [];

  for (const dm of activeDMs) {
    const bwm = bwmResults[dm.id];
    if (!bwm || bwm.error || !bwm.constraintCheckOk) continue;
    const { result } = computeMARCOS(alternatives, activeCriteria, bwm.weights);
    if (!result) continue;
    validDMs.push(dm);
    dmRankings[dm.id] = {};
    result.rows.forEach((r) => {
      dmRankings[dm.id][r.alternativeId] = { fK: r.fK, rank: r.rank };
    });
  }

  if (validDMs.length === 0) return null;

  const altIds = alternatives.map((a) => a.id);
  const groupRankMap: Record<string, number> = {};
  groupMarcos.rows.forEach((r) => {
    groupRankMap[r.alternativeId] = r.rank;
  });

  const labels = [...validDMs.map((d) => d.name), 'Kelompok'];
  const rankMaps = [
    ...validDMs.map((d) => {
      const m: Record<string, number> = {};
      altIds.forEach((id) => {
        m[id] = dmRankings[d.id][id].rank;
      });
      return m;
    }),
    groupRankMap,
  ];

  const values: number[][] = labels.map((_, i) =>
    labels.map((__, j) => (i === j ? 1 : computeSpearman(rankMaps[i], rankMaps[j], altIds)))
  );

  // Kendall's W across valid DMs
  const m = validDMs.length;
  const n = alternatives.length;
  let kendallsW = 1;
  if (m >= 2 && n >= 2) {
    const rSumList = altIds.map((id) =>
      validDMs.reduce((acc, dm) => acc + dmRankings[dm.id][id].rank, 0)
    );
    const rMean = rSumList.reduce((s, v) => s + v, 0) / n;
    const sSq = rSumList.reduce((s, r) => s + Math.pow(r - rMean, 2), 0);
    kendallsW = (12 * sSq) / (m * m * (n * n * n - n));
  }

  const alternativeRanges = groupMarcos.rows.map((r) => {
    const ranksByDm: Record<string, number> = {};
    let minRank = Infinity;
    let maxRank = -Infinity;
    for (const dm of validDMs) {
      const rk = dmRankings[dm.id][r.alternativeId].rank;
      ranksByDm[dm.id] = rk;
      if (rk < minRank) minRank = rk;
      if (rk > maxRank) maxRank = rk;
    }
    return {
      alternativeId: r.alternativeId,
      name: r.name,
      province: r.province,
      ranksByDm,
      groupRank: r.rank,
      minRank,
      maxRank,
      range: maxRank - minRank,
    };
  });

  const mostDebated = [...alternativeRanges]
    .sort((a, b) => b.range - a.range || a.groupRank - b.groupRank)
    .slice(0, 5)
    .map((x) => ({ name: x.name, range: x.range, groupRank: x.groupRank }));

  const mostAgreed = [...alternativeRanges]
    .sort((a, b) => a.range - b.range || a.groupRank - b.groupRank)
    .slice(0, 5)
    .map((x) => ({ name: x.name, range: x.range, groupRank: x.groupRank }));

  return {
    dmRankings,
    spearmanMatrix: { labels, values },
    kendallsW,
    alternativeRanges,
    mostDebated,
    mostAgreed,
  };
}

/**
 * 8-Scenario Sensitivity Analysis matching research methodology (dynamic for any criteria/DM count)
 */
export function computeSensitivityAnalysis(
  alternatives: Alternative[],
  activeCriteria: Criterion[],
  activeDMs: DecisionMaker[],
  bwmResults: Record<string, BWMResult>,
  groupWeights: Record<string, number>,
  baseMarcos: MARCOSResult,
  targetCriterionId: string,
  deltaPct = 20
): SensitivityScenario[] {
  if (alternatives.length < 2 || activeCriteria.length === 0) return [];

  const altIds = alternatives.map((a) => a.id);
  const baseRankMap: Record<string, number> = {};
  const baseTop5 = new Set<string>();
  const baseTop10 = new Set<string>();

  baseMarcos.rows.forEach((r) => {
    baseRankMap[r.alternativeId] = r.rank;
    if (r.rank <= 5) baseTop5.add(r.alternativeId);
    if (r.rank <= 10) baseTop10.add(r.alternativeId);
  });

  const targetCrit =
    activeCriteria.find((c) => c.id === targetCriterionId) ?? activeCriteria[0];

  const evalScenario = (
    id: string,
    name: string,
    description: string,
    w: Record<string, number>
  ): SensitivityScenario => {
    const { result } = computeMARCOS(alternatives, activeCriteria, w);
    if (!result) {
      return {
        id,
        name,
        description,
        weights: w,
        spearmanVsBase: 0,
        rank1Name: '-',
        top5Retained: 0,
        top10Retained: 0,
        maxRankShift: 0,
      };
    }

    const scenRankMap: Record<string, number> = {};
    let top5Retained = 0;
    let top10Retained = 0;
    let maxRankShift = 0;

    result.rows.forEach((r) => {
      scenRankMap[r.alternativeId] = r.rank;
      if (r.rank <= 5 && baseTop5.has(r.alternativeId)) top5Retained++;
      if (r.rank <= 10 && baseTop10.has(r.alternativeId)) top10Retained++;
      const shift = Math.abs(r.rank - baseRankMap[r.alternativeId]);
      if (shift > maxRankShift) maxRankShift = shift;
    });

    return {
      id,
      name,
      description,
      weights: w,
      spearmanVsBase: computeSpearman(baseRankMap, scenRankMap, altIds),
      rank1Name: result.rows[0]?.name ?? '-',
      top5Retained,
      top10Retained,
      maxRankShift,
    };
  };

  const scenarios: SensitivityScenario[] = [];

  // S0: Basis
  scenarios.push(
    evalScenario(
      'S0',
      'Basis: Bobot Kelompok',
      `Bobot agregasi geometrik berbobot (λ aktif)`,
      groupWeights
    )
  );

  // S1: Equal weights 1/n
  const equalW: Record<string, number> = {};
  activeCriteria.forEach((c) => {
    equalW[c.id] = 1 / activeCriteria.length;
  });
  scenarios.push(
    evalScenario(
      'S1',
      `Bobot Kriteria Sama Rata (1/${activeCriteria.length})`,
      'Semua kriteria diberi bobot seragam tanpa preferensi BWM',
      equalW
    )
  );

  // S2..: Single DM only
  activeDMs.forEach((dm, idx) => {
    const res = bwmResults[dm.id];
    if (res && !res.error && res.constraintCheckOk) {
      scenarios.push(
        evalScenario(
          `S${2 + idx}`,
          `Hanya Bobot ${dm.name}`,
          `Seluruh keputusan menggunakan bobot tunggal ${dm.name} (${dm.perspective})`,
          res.weights
        )
      );
    }
  });

  // Equal DM lambda = 1/m
  const nextIdx = 2 + activeDMs.length;
  const equalDMs = activeDMs.map((d) => ({ ...d, lambda: 1 / activeDMs.length }));
  const { result: equalLambdaAgg } = computeGroupAggregation(
    activeCriteria,
    equalDMs,
    bwmResults
  );
  if (equalLambdaAgg) {
    scenarios.push(
      evalScenario(
        `S${nextIdx}`,
        `Bobot DM Sama Rata (λ = 1/${activeDMs.length})`,
        'Semua Decision Maker diberi pengaruh yang setara',
        equalLambdaAgg.weights
      )
    );
  }

  // Target criterion +deltaPct% normalized
  const factorUp = 1 + deltaPct / 100;
  const rawUp: Record<string, number> = {};
  let sumUp = 0;
  activeCriteria.forEach((c) => {
    const val = (groupWeights[c.id] ?? 0) * (c.id === targetCrit.id ? factorUp : 1);
    rawUp[c.id] = val;
    sumUp += val;
  });
  const normUp: Record<string, number> = {};
  activeCriteria.forEach((c) => {
    normUp[c.id] = sumUp > EPS ? rawUp[c.id] / sumUp : 0;
  });
  scenarios.push(
    evalScenario(
      `S${nextIdx + 1}`,
      `${targetCrit.code} Dinaikkan ${deltaPct}%, Dinormalisasi`,
      `Bobot ${targetCrit.name} dinaikkan ${deltaPct}% lalu seluruh bobot dinormalisasi ulang`,
      normUp
    )
  );

  // Target criterion -deltaPct% normalized
  const factorDown = Math.max(0.05, 1 - deltaPct / 100);
  const rawDown: Record<string, number> = {};
  let sumDown = 0;
  activeCriteria.forEach((c) => {
    const val = (groupWeights[c.id] ?? 0) * (c.id === targetCrit.id ? factorDown : 1);
    rawDown[c.id] = val;
    sumDown += val;
  });
  const normDown: Record<string, number> = {};
  activeCriteria.forEach((c) => {
    normDown[c.id] = sumDown > EPS ? rawDown[c.id] / sumDown : 0;
  });
  scenarios.push(
    evalScenario(
      `S${nextIdx + 2}`,
      `${targetCrit.code} Diturunkan ${deltaPct}%, Dinormalisasi`,
      `Bobot ${targetCrit.name} diturunkan ${deltaPct}% lalu seluruh bobot dinormalisasi ulang`,
      normDown
    )
  );

  return scenarios;
}
