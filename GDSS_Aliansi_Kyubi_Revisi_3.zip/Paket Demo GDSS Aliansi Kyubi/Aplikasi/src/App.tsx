import React, { useEffect, useState } from 'react';
import { Menu } from 'lucide-react';
import { DM_ALLOWED_PAGES, NAV_ITEMS, Sidebar } from './components/Sidebar';
import { WorkflowTracker } from './components/WorkflowTracker';
import { GDSSProvider, useGDSS } from './context/GDSSContext';
import { AgregasiPage } from './pages/AgregasiPage';
import { AlternatifPage } from './pages/AlternatifPage';
import { AnalisisPage } from './pages/AnalisisPage';
import { BerandaPage } from './pages/BerandaPage';
import { DecisionMakersPage } from './pages/DecisionMakersPage';
import { DiskusiPage } from './pages/DiskusiPage';
import { DmPortalPage } from './pages/DmPortalPage';
import { LoginPage } from './pages/LoginPage';
import { KriteriaPage } from './pages/KriteriaPage';
import { LinearBwmPage } from './pages/LinearBwmPage';
import { MarcosPage } from './pages/MarcosPage';
import { PanduanPage } from './pages/PanduanPage';
import { RankingPage } from './pages/RankingPage';
import type { PageId } from './types/gdss';

function GDSSShell() {
  const { session, isAdmin, currentDM, dmAccounts } = useGDSS();
  const homePage: PageId = session?.role === 'dm' ? 'portal' : 'beranda';
  const [activePage, setActivePage] = useState<PageId>(homePage);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Setelah login / ganti akun, buka halaman awal sesuai peran (DM → halaman khusus DM).
  useEffect(() => {
    setActivePage(homePage);
  }, [session?.username, homePage]);

  const currentNav = NAV_ITEMS.find((n) => n.id === activePage);

  // Akun DM hanya dapat membuka halaman khususnya + halaman hasil (tanpa halaman pengelolaan data).
  // Admin tidak dapat membuka Halaman DM ('portal'); DM tidak dapat membuka halaman pengelolaan data.
  const canOpen = (id: PageId) => (isAdmin ? id !== 'portal' : DM_ALLOWED_PAGES.includes(id));
  const page: PageId = canOpen(activePage) ? activePage : homePage;
  const navigate = (next: PageId) => setActivePage(canOpen(next) ? next : homePage);
  const dmLabel = dmAccounts.find((a) => a.dm.id === currentDM?.id)?.label;

  const renderPage = () => {
    switch (page) {
      case 'beranda':
        return <BerandaPage onNavigate={navigate} />;
      case 'alternatif':
        return <AlternatifPage />;
      case 'kriteria':
        return <KriteriaPage />;
      case 'dm':
        return <DecisionMakersPage onNavigate={navigate} />;
      case 'bwm':
        return <LinearBwmPage onNavigate={navigate} />;
      case 'agregasi':
        return <AgregasiPage onNavigate={navigate} />;
      case 'marcos':
        return <MarcosPage onNavigate={navigate} />;
      case 'ranking':
        return <RankingPage onNavigate={navigate} />;
      case 'analisis':
        return <AnalisisPage onNavigate={navigate} />;
      case 'diskusi':
        return <DiskusiPage />;
      case 'panduan':
        return <PanduanPage onNavigate={navigate} />;
      case 'portal':
        return <DmPortalPage onNavigate={navigate} />;
      default:
        return <BerandaPage onNavigate={navigate} />;
    }
  };

  if (!session) return <LoginPage />;

  return (
    <div className="min-h-screen bg-[#F4F7FB] text-slate-900">
      <Sidebar
        activePage={activePage}
        onNavigate={navigate}
        mobileOpen={mobileOpen}
        onCloseMobile={() => setMobileOpen(false)}
      />

      <div className="lg:pl-[264px] flex min-h-screen flex-col">
        {/* Compact Mobile Top Bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between gap-4 border-b border-slate-200 bg-white/95 px-4 py-3 backdrop-blur lg:hidden no-print">
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold text-slate-700"
          >
            <Menu className="h-4 w-4" />
            <span>Menu</span>
          </button>
          <span className="font-display text-sm font-bold text-slate-900 truncate">
            {currentNav?.label ?? 'GDSS BWM + MARCOS'}
          </span>
          <span className="w-12" />
        </header>

        <main className="flex-1 mx-auto w-full max-w-[1280px] px-4 py-6 sm:px-6 lg:px-8">
          {isAdmin ? (
            <WorkflowTracker activePage={page} onNavigate={navigate} />
          ) : (
            <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-blue-100 bg-blue-50/60 px-4 py-2.5 text-xs text-slate-700 no-print">
              <span>
                Masuk sebagai <span className="font-semibold">{dmLabel ?? 'DM'} — {currentDM?.name}</span>.
                Isi penilaian BWM Anda di Halaman Saya; hasil ranking diperbarui otomatis.
              </span>
              {page !== 'portal' && (
                <button
                  type="button"
                  onClick={() => navigate('portal')}
                  className="rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800 whitespace-nowrap"
                >
                  Ke Halaman Saya
                </button>
              )}
            </div>
          )}
          {renderPage()}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <GDSSProvider>
      <GDSSShell />
    </GDSSProvider>
  );
}
