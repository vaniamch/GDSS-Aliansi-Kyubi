import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { createPresetState } from '../data/demoPresets';
import { solveLinearBWM } from '../engine/linearBwmSolver';
import { computeGroupAggregation, computeMARCOS } from '../engine/mcdmEngine';
import type {
  Alternative,
  BWMAssessment,
  BWMResult,
  Criterion,
  DatasetMode,
  DecisionMaker,
  DiscussionNote,
  GDSSState,
  HistoryEntry,
  UserSession,
} from '../types/gdss';

const STORAGE_KEY = 'gdss_bwm_marcos_state_v1';
const SESSION_KEY = 'gdss_session_v1';
const SERVER_POLL_MS = 3000;

/** Akun demo multi-user. Admin tetap; akun DM dibuat otomatis mengikuti urutan Decision Maker. */
export const ADMIN_ACCOUNT = { username: 'admin', password: 'admin123' };
export interface DMAccount {
  username: string;
  password: string;
  label: string; // contoh: "DM 1"
  dm: DecisionMaker;
}
export function buildDMAccounts(dms: DecisionMaker[]): DMAccount[] {
  return dms.map((dm, i) => ({
    username: `dm${i + 1}`,
    password: `dm${i + 1}123`,
    label: `DM ${i + 1}`,
    dm,
  }));
}

interface GDSSContextValue {
  state: GDSSState;
  // Multi-user session
  session: UserSession | null;
  isAdmin: boolean;
  currentDM: DecisionMaker | null;
  dmAccounts: DMAccount[];
  login: (username: string, password: string) => { ok: boolean; error?: string };
  logout: () => void;
  isHydrated: boolean;
  isSaving: boolean;
  activeCriteria: Criterion[];
  activeDMs: DecisionMaker[];
  lambdaSum: number;
  isLambdaValid: boolean;
  allDMsAssessed: boolean;
  allBWMFreshAndValid: boolean;
  isAggregationFresh: boolean;
  isMarcosFresh: boolean;
  // Actions
  loadPreset: (mode: DatasetMode) => void;
  addAlternative: (alt: Omit<Alternative, 'id'>) => void;
  updateAlternative: (id: string, patch: Partial<Alternative>) => void;
  updateAlternativeValue: (id: string, criterionId: string, value: number) => void;
  canEditDM: (dmId: string) => boolean;
  deleteAlternative: (id: string) => void;
  importAlternatives: (alts: Alternative[], replaceExisting: boolean) => void;
  addCriterion: (c: Omit<Criterion, 'id' | 'code'>) => void;
  updateCriterion: (id: string, patch: Partial<Criterion>) => void;
  deleteCriterion: (id: string) => void;
  addDecisionMaker: (dm: Omit<DecisionMaker, 'id'>) => void;
  updateDecisionMaker: (id: string, patch: Partial<DecisionMaker>) => void;
  deleteDecisionMaker: (id: string) => void;
  normalizeLambdas: () => void;
  updateBWMAssessment: (dmId: string, patch: Partial<BWMAssessment>) => void;
  updateCrThreshold: (val: number) => void;
  runSingleBWM: (dmId: string) => BWMResult;
  runAllBWM: () => Record<string, BWMResult>;
  runGroupAggregation: () => { ok: boolean; error?: string };
  runMARCOS: () => { ok: boolean; errors: string[] };
  updateSensitivityParams: (pct: number, criterionId: string) => void;
  addDiscussion: (note: Omit<DiscussionNote, 'id' | 'createdAt'>) => void;
  deleteDiscussion: (id: string) => void;
  resetAllData: () => void;
}

const GDSSContext = createContext<GDSSContextValue | null>(null);

function makeHistory(
  category: HistoryEntry['category'],
  action: string,
  summary: string,
  version: number
): HistoryEntry {
  return {
    id: `hist-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    category,
    action,
    summary,
    version,
  };
}

function markAllResultsStale(state: GDSSState, scope: 'bwm' | 'agg' | 'marcos'): GDSSState {
  let bwmResults = state.bwmResults;
  let groupAggregation = state.groupAggregation;
  let marcosResult = state.marcosResult;

  if (scope === 'bwm') {
    const nextBwm: Record<string, BWMResult> = {};
    Object.entries(state.bwmResults).forEach(([k, v]) => {
      nextBwm[k] = { ...v, stale: true };
    });
    bwmResults = nextBwm;
  }

  if ((scope === 'bwm' || scope === 'agg') && state.groupAggregation) {
    groupAggregation = { ...state.groupAggregation, stale: true };
  }

  if (state.marcosResult) {
    marcosResult = { ...state.marcosResult, stale: true };
  }

  return {
    ...state,
    bwmResults,
    groupAggregation,
    marcosResult,
  };
}

function hasStaleResults(s: GDSSState): boolean {
  return (
    Object.values(s.bwmResults ?? {}).some((r) => r?.stale) ||
    Boolean(s.groupAggregation?.stale) ||
    Boolean(s.marcosResult?.stale)
  );
}

function inputsChanged(prev: GDSSState, next: GDSSState): boolean {
  return (
    prev.criteria !== next.criteria ||
    prev.alternatives !== next.alternatives ||
    prev.decisionMakers !== next.decisionMakers ||
    prev.bwmAssessments !== next.bwmAssessments ||
    prev.crThreshold !== next.crThreshold
  );
}

/**
 * Perhitungan real-time: Linear BWM (semua DM aktif) → Agregasi WGM → MARCOS.
 * Dipanggil otomatis setiap kali input berubah, sehingga tidak perlu menekan tombol hitung ulang.
 * Bila suatu tahap belum bisa dihitung (input tidak valid), hasil lama ditandai kedaluwarsa.
 */
export function recomputeAll(s: GDSSState): GDSSState {
  const crit = s.criteria.filter((c) => c.active);
  const dms = s.decisionMakers.filter((d) => d.active);
  const activeIds = new Set(dms.map((d) => d.id));
  const knownIds = new Set(s.decisionMakers.map((d) => d.id));

  const bwmResults: Record<string, BWMResult> = {};
  Object.entries(s.bwmResults ?? {}).forEach(([id, r]) => {
    if (!activeIds.has(id) && knownIds.has(id)) bwmResults[id] = r;
  });
  dms.forEach((dm) => {
    bwmResults[dm.id] = solveLinearBWM(
      dm.id,
      s.bwmAssessments[dm.id] as BWMAssessment,
      crit,
      s.crThreshold
    );
  });

  const { result: agg } = computeGroupAggregation(crit, dms, bwmResults);
  let groupAggregation = agg;
  let marcosResult = s.marcosResult ? { ...s.marcosResult, stale: true } : null;
  if (!agg) {
    groupAggregation = s.groupAggregation ? { ...s.groupAggregation, stale: true } : null;
  } else {
    const { result: marcos } = computeMARCOS(s.alternatives, crit, agg.weights);
    if (marcos) marcosResult = marcos;
  }

  return { ...s, bwmResults, groupAggregation, marcosResult };
}

function prepareIncoming(s: GDSSState): GDSSState {
  return hasStaleResults(s) || !s.marcosResult ? recomputeAll(s) : s;
}

function readSession(): UserSession | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as UserSession) : null;
  } catch {
    return null;
  }
}

export function GDSSProvider({ children }: { children: React.ReactNode }) {
  const [state, setRawState] = useState<GDSSState>(() => {
    try {
      const cached = localStorage.getItem(STORAGE_KEY);
      if (cached) {
        return prepareIncoming(JSON.parse(cached) as GDSSState);
      }
    } catch {
      // ignore invalid cache
    }
    return prepareIncoming(createPresetState('PENELITIAN'));
  });

  // Setiap perubahan lokal melewati pembungkus ini → seluruh hasil dihitung ulang otomatis.
  const localEditSeqRef = useRef(0);
  const skipNextSaveRef = useRef(false);
  const lastServerJsonRef = useRef<string | null>(null);
  const setState = useCallback((action: React.SetStateAction<GDSSState>) => {
    localEditSeqRef.current += 1;
    setRawState((prev) => {
      const next =
        typeof action === 'function'
          ? (action as (p: GDSSState) => GDSSState)(prev)
          : action;
      if (next === prev) return prev;
      if (!inputsChanged(prev, next) && !hasStaleResults(next)) return next;
      return recomputeAll(next);
    });
  }, []);

  /** Mengadopsi state dari pengguna lain (tab lain / server) tanpa mengirim balik. */
  const adoptExternalState = useCallback((incoming: GDSSState) => {
    skipNextSaveRef.current = true;
    setRawState(prepareIncoming(incoming));
  }, []);

  // ---- Sesi multi-user (per tab browser, sehingga Admin & DM bisa dibuka berdampingan) ----
  const [session, setSession] = useState<UserSession | null>(() => readSession());
  const dmAccounts = useMemo(() => buildDMAccounts(state.decisionMakers), [state.decisionMakers]);
  const isAdmin = session?.role === 'admin';
  const currentDM =
    session?.role === 'dm'
      ? state.decisionMakers.find((d) => d.id === session.dmId) ?? null
      : null;
  const isAdminRef = useRef(isAdmin);
  isAdminRef.current = isAdmin;
  const currentDmIdRef = useRef<string | null>(null);
  currentDmIdRef.current = currentDM?.id ?? null;
  const editorLabelRef = useRef('Admin');
  {
    const acc = dmAccounts.find((a) => a.dm.id === currentDM?.id);
    editorLabelRef.current = isAdmin ? 'Admin' : acc ? `${acc.label} — ${acc.dm.name}` : 'DM';
  }
  /**
   * Penilaian BWM (kriteria terbaik/terburuk, BO, OW) hanya boleh diubah oleh DM pemiliknya.
   * Admin TIDAK dapat mengubah penilaian DM mana pun (Jeno, James, Karina, dst.).
   */
  const canEditDM = (dmId: string) =>
    !isAdminRef.current && currentDmIdRef.current !== null && currentDmIdRef.current === dmId;

  const persistSession = (next: UserSession | null) => {
    setSession(next);
    try {
      if (next) sessionStorage.setItem(SESSION_KEY, JSON.stringify(next));
      else sessionStorage.removeItem(SESSION_KEY);
    } catch {
      // ignore
    }
  };

  const login = (username: string, password: string): { ok: boolean; error?: string } => {
    const u = username.trim().toLowerCase();
    if (u === ADMIN_ACCOUNT.username) {
      if (password !== ADMIN_ACCOUNT.password) return { ok: false, error: 'Password admin salah.' };
      persistSession({ role: 'admin', username: u, loggedInAt: new Date().toISOString() });
      return { ok: true };
    }
    const acc = dmAccounts.find((a) => a.username === u);
    if (!acc) return { ok: false, error: 'Username tidak terdaftar.' };
    if (password !== acc.password) return { ok: false, error: 'Password salah.' };
    persistSession({
      role: 'dm',
      dmId: acc.dm.id,
      username: u,
      loggedInAt: new Date().toISOString(),
    });
    return { ok: true };
  };

  const logout = () => persistSession(null);

  // Jika DM yang sedang login dihapus admin, sesi DM otomatis berakhir.
  useEffect(() => {
    if (session?.role === 'dm' && !state.decisionMakers.some((d) => d.id === session.dmId)) {
      persistSession(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.decisionMakers, session]);

  const [isHydrated, setIsHydrated] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const saveTimerRef = useRef<number | null>(null);
  const skipFirstSaveRef = useRef(true);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const res = await fetch('/api/state');
        if (res.ok) {
          const data = (await res.json()) as { state: GDSSState | null };
          if (active && data.state && typeof data.state === 'object') {
            lastServerJsonRef.current = JSON.stringify(data.state);
            setRawState(prepareIncoming(data.state));
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data.state));
          }
        }
      } catch {
        // Fallback silently to localStorage state
      } finally {
        if (active) setIsHydrated(true);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    if (skipFirstSaveRef.current) {
      skipFirstSaveRef.current = false;
      return;
    }
    if (skipNextSaveRef.current) {
      // State berasal dari pengguna lain — jangan dikirim balik (mencegah loop sinkronisasi).
      skipNextSaveRef.current = false;
      return;
    }

    const serialized = JSON.stringify(state);
    try {
      localStorage.setItem(STORAGE_KEY, serialized);
    } catch {
      // ignore storage quota errors
    }

    if (saveTimerRef.current) {
      window.clearTimeout(saveTimerRef.current);
    }
    saveTimerRef.current = window.setTimeout(async () => {
      saveTimerRef.current = null;
      setIsSaving(true);
      try {
        const res = await fetch('/api/state', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ state }),
        });
        if (res.ok) lastServerJsonRef.current = serialized;
      } catch {
        // localStorage already persisted
      } finally {
        setIsSaving(false);
      }
    }, 350);

    return () => {
      if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
    };
  }, [state, isHydrated]);

  // Sinkronisasi real-time antar-tab pada browser yang sama (mis. Admin & DM 1 dibuka berdampingan).
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key !== STORAGE_KEY || !e.newValue) return;
      try {
        adoptExternalState(JSON.parse(e.newValue) as GDSSState);
      } catch {
        // ignore invalid payload
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, [adoptExternalState]);

  // Sinkronisasi antar-perangkat lewat server (npm run dev). Mode demo statis mengembalikan null.
  useEffect(() => {
    if (!isHydrated) return;
    let stopped = false;
    const timer = window.setInterval(async () => {
      if (saveTimerRef.current) return; // ada perubahan lokal yang belum terkirim
      const seqAtStart = localEditSeqRef.current;
      try {
        const res = await fetch('/api/state', { cache: 'no-store' });
        if (!res.ok) return;
        const data = (await res.json()) as { state: GDSSState | null };
        if (stopped || !data.state || typeof data.state !== 'object') return;
        const json = JSON.stringify(data.state);
        if (json === lastServerJsonRef.current) return;
        if (seqAtStart !== localEditSeqRef.current || saveTimerRef.current) return;
        lastServerJsonRef.current = json;
        adoptExternalState(data.state);
        try {
          localStorage.setItem(STORAGE_KEY, json);
        } catch {
          // ignore
        }
      } catch {
        // server tidak tersedia
      }
    }, SERVER_POLL_MS);
    return () => {
      stopped = true;
      window.clearInterval(timer);
    };
  }, [isHydrated, adoptExternalState]);

  const activeCriteria = useMemo(
    () => state.criteria.filter((c) => c.active),
    [state.criteria]
  );

  const activeDMs = useMemo(
    () => state.decisionMakers.filter((d) => d.active),
    [state.decisionMakers]
  );

  const lambdaSum = useMemo(
    () => activeDMs.reduce((sum, dm) => sum + dm.lambda, 0),
    [activeDMs]
  );

  const isLambdaValid = activeDMs.length > 0 && Math.abs(lambdaSum - 1) <= 1e-4;

  const allDMsAssessed = useMemo(() => {
    if (activeDMs.length === 0 || activeCriteria.length < 2) return false;
    return activeDMs.every((dm) => {
      const a = state.bwmAssessments[dm.id];
      if (!a || !a.bestCriterionId || !a.worstCriterionId) return false;
      if (a.bestCriterionId === a.worstCriterionId) return false;
      return activeCriteria.every(
        (c) =>
          typeof a.bo[c.id] === 'number' &&
          a.bo[c.id] >= 1 &&
          a.bo[c.id] <= 9 &&
          typeof a.ow[c.id] === 'number' &&
          a.ow[c.id] >= 1 &&
          a.ow[c.id] <= 9
      );
    });
  }, [activeDMs, activeCriteria, state.bwmAssessments]);

  const allBWMFreshAndValid = useMemo(() => {
    if (activeDMs.length === 0) return false;
    return activeDMs.every((dm) => {
      const res = state.bwmResults[dm.id];
      return Boolean(res && !res.stale && !res.error && res.constraintCheckOk);
    });
  }, [activeDMs, state.bwmResults]);

  const isAggregationFresh = Boolean(
    state.groupAggregation && !state.groupAggregation.stale && allBWMFreshAndValid && isLambdaValid
  );

  const isMarcosFresh = Boolean(
    state.marcosResult && !state.marcosResult.stale && isAggregationFresh
  );

  const loadPreset = (mode: DatasetMode) => {
    const preset = createPresetState(mode);
    const labels = {
      PENELITIAN: 'Data penelitian Aliansi Kyubi',
      DEMO_62: 'Dataset DEMO 62 Kabupaten (Perpres 63/2020)',
      DEMO_12: 'Dataset Mini DEMO 12 Kabupaten',
      KUSTOM: 'Data Kustom',
      KOSONG: 'Workspace Kosong',
    };
    setState((prev) => ({
      ...preset,
      version: prev.version + 1,
      discussions: mode === 'PENELITIAN' ? prev.discussions : preset.discussions,
      history: [
        makeHistory('data', 'Muat Dataset', `Memuat ${labels[mode]}.`, prev.version + 1),
        ...prev.history,
      ],
    }));
  };

  const addAlternative = (alt: Omit<Alternative, 'id'>) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const newAlt: Alternative = {
        ...alt,
        id: `alt-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      };
      const updated = markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          datasetMode: ['KOSONG', 'PENELITIAN'].includes(prev.datasetMode) ? 'KUSTOM' : prev.datasetMode,
          alternatives: [...prev.alternatives, newAlt],
          history: [
            makeHistory(
              'data',
              'Tambah Alternatif',
              `Menambahkan kabupaten ${newAlt.name} (${newAlt.province}).`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'marcos'
      );
      return updated;
    });
  };

  const updateAlternative = (id: string, patch: Partial<Alternative>) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const target = prev.alternatives.find((a) => a.id === id);
      const updated = markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          datasetMode: prev.datasetMode === 'PENELITIAN' ? 'KUSTOM' : prev.datasetMode,
          alternatives: prev.alternatives.map((a) => (a.id === id ? { ...a, ...patch } : a)),
          history: [
            makeHistory(
              'data',
              'Ubah Alternatif',
              `Memperbarui data kabupaten ${patch.name ?? target?.name ?? id}.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'marcos'
      );
      return updated;
    });
  };

  /** Input nilai langsung di sel tabel (khusus Admin). Riwayat untuk sel yang sama digabung. */
  const updateAlternativeValue = (id: string, criterionId: string, value: number) => {
    if (!Number.isFinite(value)) return;
    setState((prev) => {
      const target = prev.alternatives.find((a) => a.id === id);
      const crit = prev.criteria.find((c) => c.id === criterionId);
      if (!target || target.values[criterionId] === value) return prev;
      const nextVer = prev.version + 1;
      const summary = `Input manual nilai ${crit?.code ?? criterionId} kabupaten ${target.name}`;
      const entry = makeHistory('data', 'Input Nilai Manual (Admin)', `${summary}: ${value}.`, nextVer);
      const head = prev.history[0];
      const history =
        head && head.action === entry.action && head.summary.startsWith(summary)
          ? [entry, ...prev.history.slice(1)]
          : [entry, ...prev.history];
      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          datasetMode: prev.datasetMode === 'PENELITIAN' ? 'KUSTOM' : prev.datasetMode,
          alternatives: prev.alternatives.map((a) =>
            a.id === id ? { ...a, values: { ...a.values, [criterionId]: value } } : a
          ),
          history,
        },
        'marcos'
      );
    });
  };

  const deleteAlternative = (id: string) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const target = prev.alternatives.find((a) => a.id === id);
      const updated = markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          datasetMode: prev.datasetMode === 'PENELITIAN' ? 'KUSTOM' : prev.datasetMode,
          alternatives: prev.alternatives.filter((a) => a.id !== id),
          history: [
            makeHistory(
              'data',
              'Hapus Alternatif',
              `Menghapus kabupaten ${target?.name ?? id}.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'marcos'
      );
      return updated;
    });
  };

  const importAlternatives = (alts: Alternative[], replaceExisting: boolean) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const merged = replaceExisting ? alts : [...prev.alternatives, ...alts];
      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          datasetMode: 'KUSTOM',
          alternatives: merged,
          history: [
            makeHistory(
              'data',
              'Import Data Alternatif',
              `${replaceExisting ? 'Mengganti' : 'Menambahkan'} ${alts.length} baris data kabupaten dari file eksternal.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'marcos'
      );
    });
  };

  const addCriterion = (c: Omit<Criterion, 'id' | 'code'>) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const nextNum =
        prev.criteria.reduce((max, item) => {
          const parsed = parseInt(item.code.replace(/\D/g, ''), 10);
          return Number.isFinite(parsed) && parsed > max ? parsed : max;
        }, 0) + 1;
      const newCrit: Criterion = {
        ...c,
        id: `c${Date.now()}`,
        code: `C${nextNum}`,
      };
      const nextAlts = prev.alternatives.map((a) => ({
        ...a,
        values: { ...a.values, [newCrit.id]: 1 },
      }));
      const nextAssessments: Record<string, BWMAssessment> = {};
      Object.entries(prev.bwmAssessments).forEach(([dmId, ass]) => {
        nextAssessments[dmId] = {
          ...ass,
          bo: { ...ass.bo, [newCrit.id]: 3 },
          ow: { ...ass.ow, [newCrit.id]: 3 },
          updatedAt: new Date().toISOString(),
        };
      });

      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          criteria: [...prev.criteria, newCrit],
          alternatives: nextAlts,
          bwmAssessments: nextAssessments,
          history: [
            makeHistory(
              'criteria',
              'Tambah Kriteria',
              `Menambahkan kriteria ${newCrit.code} (${newCrit.name}) bertipe ${newCrit.type}.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'bwm'
      );
    });
  };

  const updateCriterion = (id: string, patch: Partial<Criterion>) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const target = prev.criteria.find((c) => c.id === id);
      const affectsBWM =
        typeof patch.active === 'boolean' && patch.active !== target?.active;
      const updated = markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          criteria: prev.criteria.map((c) => (c.id === id ? { ...c, ...patch } : c)),
          history: [
            makeHistory(
              'criteria',
              'Ubah Kriteria',
              `Memperbarui kriteria ${target?.code ?? id} (${patch.name ?? target?.name ?? ''}${patch.type ? ` · ${patch.type}` : ''}).`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        affectsBWM ? 'bwm' : 'marcos'
      );
      return updated;
    });
  };

  const deleteCriterion = (id: string) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const target = prev.criteria.find((c) => c.id === id);
      const remaining = prev.criteria.filter((c) => c.id !== id);
      const nextAlts = prev.alternatives.map((a) => {
        const vals = { ...a.values };
        delete vals[id];
        return { ...a, values: vals };
      });
      const nextAssessments: Record<string, BWMAssessment> = {};
      Object.entries(prev.bwmAssessments).forEach(([dmId, ass]) => {
        const bo = { ...ass.bo };
        const ow = { ...ass.ow };
        delete bo[id];
        delete ow[id];
        const fallbackBest = remaining[0]?.id ?? '';
        const fallbackWorst = remaining[remaining.length - 1]?.id ?? '';
        const bestId = ass.bestCriterionId === id ? fallbackBest : ass.bestCriterionId;
        const worstId = ass.worstCriterionId === id ? fallbackWorst : ass.worstCriterionId;
        if (bestId) bo[bestId] = 1;
        if (worstId) ow[worstId] = 1;
        nextAssessments[dmId] = {
          ...ass,
          bestCriterionId: bestId,
          worstCriterionId: worstId,
          bo,
          ow,
          updatedAt: new Date().toISOString(),
        };
      });

      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          criteria: remaining,
          alternatives: nextAlts,
          bwmAssessments: nextAssessments,
          sensitivityCriterionId:
            prev.sensitivityCriterionId === id
              ? (remaining[0]?.id ?? '')
              : prev.sensitivityCriterionId,
          history: [
            makeHistory(
              'criteria',
              'Hapus Kriteria',
              `Menghapus kriteria ${target?.code ?? id} (${target?.name ?? ''}).`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'bwm'
      );
    });
  };

  const addDecisionMaker = (dm: Omit<DecisionMaker, 'id'>) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const newDm: DecisionMaker = {
        ...dm,
        id: `dm-${Date.now()}`,
      };
      const actCrit = prev.criteria.filter((c) => c.active);
      const bestId = actCrit[0]?.id ?? '';
      const worstId = actCrit[actCrit.length - 1]?.id ?? '';
      const bo: Record<string, number> = {};
      const ow: Record<string, number> = {};
      actCrit.forEach((c) => {
        bo[c.id] = c.id === bestId ? 1 : c.id === worstId ? 5 : 3;
        ow[c.id] = c.id === worstId ? 1 : c.id === bestId ? 5 : 3;
      });

      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          decisionMakers: [...prev.decisionMakers, newDm],
          bwmAssessments: {
            ...prev.bwmAssessments,
            [newDm.id]: {
              dmId: newDm.id,
              bestCriterionId: bestId,
              worstCriterionId: worstId,
              bo,
              ow,
              updatedAt: new Date().toISOString(),
            },
          },
          history: [
            makeHistory(
              'dm',
              'Tambah Decision Maker',
              `Menambahkan DM ${newDm.name} (${newDm.perspective}, λ=${newDm.lambda.toFixed(2)}).`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'agg'
      );
    });
  };

  const updateDecisionMaker = (id: string, patch: Partial<DecisionMaker>) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const target = prev.decisionMakers.find((d) => d.id === id);
      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          decisionMakers: prev.decisionMakers.map((d) =>
            d.id === id ? { ...d, ...patch } : d
          ),
          history: [
            makeHistory(
              'dm',
              'Ubah Decision Maker',
              `Memperbarui DM ${patch.name ?? target?.name ?? id}${patch.lambda !== undefined ? ` (λ=${patch.lambda})` : ''}.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'agg'
      );
    });
  };

  const deleteDecisionMaker = (id: string) => {
    setState((prev) => {
      const nextVer = prev.version + 1;
      const target = prev.decisionMakers.find((d) => d.id === id);
      const nextAss = { ...prev.bwmAssessments };
      const nextRes = { ...prev.bwmResults };
      delete nextAss[id];
      delete nextRes[id];

      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          decisionMakers: prev.decisionMakers.filter((d) => d.id !== id),
          bwmAssessments: nextAss,
          bwmResults: nextRes,
          history: [
            makeHistory(
              'dm',
              'Hapus Decision Maker',
              `Menghapus DM ${target?.name ?? id}.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'agg'
      );
    });
  };

  const normalizeLambdas = () => {
    setState((prev) => {
      const active = prev.decisionMakers.filter((d) => d.active);
      if (active.length === 0) return prev;
      const total = active.reduce((s, d) => s + d.lambda, 0);
      const nextVer = prev.version + 1;

      const updatedDMs = prev.decisionMakers.map((d) => {
        if (!d.active) return d;
        const val =
          total > 0
            ? Math.round((d.lambda / total) * 10000) / 10000
            : Math.round((1 / active.length) * 10000) / 10000;
        return { ...d, lambda: val };
      });
      // Adjust rounding residual on first active DM so sum === 1.0000
      const activeIdx = updatedDMs.findIndex((d) => d.active);
      if (activeIdx !== -1) {
        const sumOthers = updatedDMs.reduce(
          (acc, d, i) => (d.active && i !== activeIdx ? acc + d.lambda : acc),
          0
        );
        updatedDMs[activeIdx] = {
          ...updatedDMs[activeIdx],
          lambda: Math.round((1 - sumOthers) * 10000) / 10000,
        };
      }

      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          decisionMakers: updatedDMs,
          history: [
            makeHistory(
              'dm',
              'Normalisasi Bobot λ',
              'Menormalisasi bobot kepentingan λ seluruh DM aktif agar berjumlah tepat 1,0000.',
              nextVer
            ),
            ...prev.history,
          ],
        },
        'agg'
      );
    });
  };

  const updateBWMAssessment = (dmId: string, patch: Partial<BWMAssessment>) => {
    setState((prev) => {
      const existing = prev.bwmAssessments[dmId] ?? {
        dmId,
        bestCriterionId: prev.criteria.find((c) => c.active)?.id ?? '',
        worstCriterionId: prev.criteria.filter((c) => c.active).slice(-1)[0]?.id ?? '',
        bo: {},
        ow: {},
        updatedAt: new Date().toISOString(),
      };
      const nextAss: BWMAssessment = {
        ...existing,
        ...patch,
        bo: patch.bo ? { ...patch.bo } : { ...existing.bo },
        ow: patch.ow ? { ...patch.ow } : { ...existing.ow },
        updatedAt: new Date().toISOString(),
        updatedBy: editorLabelRef.current,
      };
      if (nextAss.bestCriterionId) nextAss.bo[nextAss.bestCriterionId] = 1;
      if (nextAss.worstCriterionId) nextAss.ow[nextAss.worstCriterionId] = 1;

      const nextBwmRes = { ...prev.bwmResults };
      if (nextBwmRes[dmId]) {
        nextBwmRes[dmId] = { ...nextBwmRes[dmId], stale: true };
      }

      // Riwayat: perubahan berturut-turut oleh akun yang sama untuk DM yang sama digabung.
      const dmName = prev.decisionMakers.find((d) => d.id === dmId)?.name ?? dmId;
      const summary = `Penilaian BWM ${dmName} diperbarui oleh ${editorLabelRef.current}`;
      const head = prev.history[0];
      const entry = makeHistory('bwm', 'Ubah Penilaian BWM', `${summary}.`, prev.version + 1);
      const history =
        head && head.action === entry.action && head.summary === entry.summary
          ? [entry, ...prev.history.slice(1)]
          : [entry, ...prev.history];

      return {
        ...prev,
        version: prev.version + 1,
        history,
        bwmAssessments: { ...prev.bwmAssessments, [dmId]: nextAss },
        bwmResults: nextBwmRes,
        groupAggregation: prev.groupAggregation
          ? { ...prev.groupAggregation, stale: true }
          : null,
        marcosResult: prev.marcosResult ? { ...prev.marcosResult, stale: true } : null,
      };
    });
  };

  const updateCrThreshold = (val: number) => {
    setState((prev) => ({
      ...prev,
      crThreshold: val,
    }));
  };

  const runSingleBWM = (dmId: string): BWMResult => {
    const assessment = state.bwmAssessments[dmId];
    const result = solveLinearBWM(dmId, assessment, activeCriteria, state.crThreshold);
    const dm = state.decisionMakers.find((d) => d.id === dmId);

    setState((prev) => {
      const nextVer = prev.version + 1;
      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          bwmResults: { ...prev.bwmResults, [dmId]: result },
          history: [
            makeHistory(
              'bwm',
              `Optimasi Linear BWM (${dm?.name ?? dmId})`,
              result.error
                ? `Gagal: ${result.error}`
                : `Sukses: ξ=${result.xi.toFixed(4)}, CRI=${result.cri.toFixed(4)} (${result.isConsistent ? 'Konsisten' : 'Melebihi Ambang'}).`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'agg'
      );
    });

    return result;
  };

  const runAllBWM = (): Record<string, BWMResult> => {
    const nextResults: Record<string, BWMResult> = { ...state.bwmResults };
    const summaryParts: string[] = [];

    activeDMs.forEach((dm) => {
      const res = solveLinearBWM(
        dm.id,
        state.bwmAssessments[dm.id],
        activeCriteria,
        state.crThreshold
      );
      nextResults[dm.id] = res;
      summaryParts.push(
        `${dm.name}: ${res.error ? 'Gagal' : `ξ=${res.xi.toFixed(4)}, CRI=${res.cri.toFixed(4)}`}`
      );
    });

    setState((prev) => {
      const nextVer = prev.version + 1;
      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          bwmResults: nextResults,
          history: [
            makeHistory(
              'bwm',
              'Optimasi Linear BWM (Semua DM)',
              summaryParts.join(' | '),
              nextVer
            ),
            ...prev.history,
          ],
        },
        'agg'
      );
    });

    return nextResults;
  };

  const runGroupAggregation = (): { ok: boolean; error?: string } => {
    const { result, error } = computeGroupAggregation(
      activeCriteria,
      activeDMs,
      state.bwmResults
    );
    if (!result) {
      return { ok: false, error };
    }

    setState((prev) => {
      const nextVer = prev.version + 1;
      return markAllResultsStale(
        {
          ...prev,
          version: nextVer,
          groupAggregation: result,
          history: [
            makeHistory(
              'aggregation',
              'Agregasi Bobot Kelompok',
              `Weighted Geometric Mean dihitung. Kesepakatan tertinggi: ${result.highestAgreementCode}, perbedaan terbesar: ${result.highestDisagreementCode}.`,
              nextVer
            ),
            ...prev.history,
          ],
        },
        'marcos'
      );
    });

    return { ok: true };
  };

  const runMARCOS = (): { ok: boolean; errors: string[] } => {
    if (!state.groupAggregation || state.groupAggregation.stale) {
      return {
        ok: false,
        errors: ['Agregasi bobot kelompok belum dijalankan atau sudah kedaluwarsa.'],
      };
    }

    const { result, errors } = computeMARCOS(
      state.alternatives,
      activeCriteria,
      state.groupAggregation.weights
    );
    if (!result) {
      return { ok: false, errors };
    }

    setState((prev) => {
      const nextVer = prev.version + 1;
      const top1 = result.rows[0];
      return {
        ...prev,
        version: nextVer,
        marcosResult: result,
        history: [
          makeHistory(
            'marcos',
            'Perhitungan MARCOS',
            `Berhasil meranking ${result.rows.length} kabupaten. Prioritas #1: ${top1?.name ?? '-'} (f(Ki)=${top1?.fK.toFixed(4) ?? '-'}).`,
            nextVer
          ),
          ...prev.history,
        ],
      };
    });

    return { ok: true, errors: [] };
  };

  const updateSensitivityParams = (pct: number, criterionId: string) => {
    setState((prev) => ({
      ...prev,
      sensitivityPct: pct,
      sensitivityCriterionId: criterionId,
    }));
  };

  const addDiscussion = (note: Omit<DiscussionNote, 'id' | 'createdAt'>) => {
    setState((prev) => ({
      ...prev,
      discussions: [
        {
          ...note,
          id: `disc-${Date.now()}`,
          createdAt: new Date().toISOString(),
        },
        ...prev.discussions,
      ],
    }));
  };

  const deleteDiscussion = (id: string) => {
    setState((prev) => ({
      ...prev,
      discussions: prev.discussions.filter((d) => d.id !== id),
    }));
  };

  const resetAllData = () => {
    const fresh = createPresetState('PENELITIAN');
    setState(fresh);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    fetch('/api/state', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ state: fresh }),
    }).catch(() => {});
  };

  // Hanya Admin yang dapat menginput / mengubah nilai. Pemanggilan dari akun DM diabaikan.
  function adminOnly<A extends unknown[], R>(fn: (...args: A) => R, fallback: R) {
    return (...args: A): R => (isAdminRef.current ? fn(...args) : fallback);
  }
  const noop = undefined as void;
  const denied = { ok: false, error: 'Hanya Admin yang dapat mengubah nilai.' };

  const addDiscussionGuarded = (note: Omit<DiscussionNote, 'id' | 'createdAt'>) => {
    if (!session) return;
    if (isAdminRef.current) return addDiscussion(note);
    // DM hanya dapat menulis catatan atas namanya sendiri.
    if (!currentDM) return;
    addDiscussion({
      ...note,
      author: `${currentDM.name} (${currentDM.perspective})`,
      dmId: currentDM.id,
    });
  };
  const deleteDiscussionGuarded = (id: string) => {
    const note = state.discussions.find((d) => d.id === id);
    if (isAdminRef.current || (currentDM && note?.dmId === currentDM.id)) deleteDiscussion(id);
  };

  return (
    <GDSSContext.Provider
      value={{
        state,
        session,
        isAdmin,
        currentDM,
        dmAccounts,
        login,
        logout,
        isHydrated,
        isSaving,
        activeCriteria,
        activeDMs,
        lambdaSum,
        isLambdaValid,
        allDMsAssessed,
        allBWMFreshAndValid,
        isAggregationFresh,
        isMarcosFresh,
        loadPreset: adminOnly(loadPreset, noop),
        addAlternative: adminOnly(addAlternative, noop),
        updateAlternative: adminOnly(updateAlternative, noop),
        updateAlternativeValue: adminOnly(updateAlternativeValue, noop),
        canEditDM,
        deleteAlternative: adminOnly(deleteAlternative, noop),
        importAlternatives: adminOnly(importAlternatives, noop),
        addCriterion: adminOnly(addCriterion, noop),
        updateCriterion: adminOnly(updateCriterion, noop),
        deleteCriterion: adminOnly(deleteCriterion, noop),
        addDecisionMaker: adminOnly(addDecisionMaker, noop),
        updateDecisionMaker: adminOnly(updateDecisionMaker, noop),
        deleteDecisionMaker: adminOnly(deleteDecisionMaker, noop),
        normalizeLambdas: adminOnly(normalizeLambdas, noop),
        updateBWMAssessment: (dmId: string, patch: Partial<BWMAssessment>) => {
          if (canEditDM(dmId)) updateBWMAssessment(dmId, patch);
        },
        updateCrThreshold: adminOnly(updateCrThreshold, noop),
        runSingleBWM: (dmId: string) =>
          isAdminRef.current ? runSingleBWM(dmId) : state.bwmResults[dmId],
        runAllBWM: () => (isAdminRef.current ? runAllBWM() : state.bwmResults),
        runGroupAggregation: adminOnly(runGroupAggregation, denied),
        runMARCOS: adminOnly(runMARCOS, { ok: false, errors: [denied.error] }),
        updateSensitivityParams: adminOnly(updateSensitivityParams, noop),
        addDiscussion: addDiscussionGuarded,
        deleteDiscussion: deleteDiscussionGuarded,
        resetAllData: adminOnly(resetAllData, noop),
      }}
    >
      {children}
    </GDSSContext.Provider>
  );
}

export function useGDSS() {
  const ctx = useContext(GDSSContext);
  if (!ctx) throw new Error('useGDSS must be used inside GDSSProvider');
  return ctx;
}
