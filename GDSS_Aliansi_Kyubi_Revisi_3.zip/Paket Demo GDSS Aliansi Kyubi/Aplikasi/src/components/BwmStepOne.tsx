import React from 'react';
import { ArrowRight, CheckCircle2, MousePointerClick, ThumbsDown, ThumbsUp } from 'lucide-react';
import type { Criterion } from '../types/gdss';

interface BwmStepOneProps {
  criteria: Criterion[];
  bestId: string;
  worstId: string;
  /** Nilai a_BW (preferensi Best terhadap Worst) dari vektor BO. */
  aBW?: number;
  dmName: string;
  readOnly?: boolean;
  /** Dipanggil dengan pasangan Best & Worst baru (otomatis ditukar bila sama). */
  onChange?: (bestId: string, worstId: string) => void;
}

/**
 * Langkah 1 Linear BWM: menentukan kriteria Best & Worst.
 * Ditampilkan sebagai panel lebar penuh dengan kartu kriteria yang dapat diklik,
 * sehingga pilihan Best (hijau) dan Worst (merah) langsung terlihat.
 */
export function BwmStepOne({
  criteria,
  bestId,
  worstId,
  aBW,
  dmName,
  readOnly = false,
  onChange,
}: BwmStepOneProps) {
  const best = criteria.find((c) => c.id === bestId);
  const worst = criteria.find((c) => c.id === worstId);
  const isDone = Boolean(best && worst && bestId !== worstId);

  const pickBest = (id: string) => {
    if (readOnly || !onChange || id === bestId) return;
    // Bila kriteria yang dipilih sebelumnya Worst, posisi Best & Worst ditukar.
    onChange(id, id === worstId ? bestId : worstId);
  };
  const pickWorst = (id: string) => {
    if (readOnly || !onChange || id === worstId) return;
    onChange(id === bestId ? worstId : bestId, id);
  };

  return (
    <section
      id="bwm-step-1"
      aria-labelledby="bwm-step-1-title"
      className="scroll-mt-6 rounded-2xl border-2 border-blue-600 bg-gradient-to-br from-blue-50 via-white to-white p-5 shadow-sm ring-4 ring-blue-100/70 sm:p-6"
    >
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-4 min-w-0">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-blue-700 font-display text-2xl font-bold text-white shadow-md">
            1
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold uppercase tracking-wider text-blue-700">
              Langkah 1 · Linear BWM
            </div>
            <h3
              id="bwm-step-1-title"
              className="font-display text-xl font-bold leading-tight text-slate-900"
            >
              Tentukan Kriteria Terbaik (Best) dan Terburuk (Worst)
            </h3>
            <p className="mt-1 max-w-2xl text-sm leading-relaxed text-slate-600">
              Menurut <span className="font-semibold text-slate-800">{dmName}</span>, pilih satu
              kriteria <span className="font-semibold text-emerald-700">paling penting (Best)</span>{' '}
              dan satu kriteria{' '}
              <span className="font-semibold text-rose-700">paling tidak penting (Worst)</span>.
              Keduanya menjadi acuan perbandingan pada Langkah 2 dan Langkah 3.
            </p>
          </div>
        </div>
        <span
          className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold whitespace-nowrap ${
            isDone
              ? 'bg-emerald-100 text-emerald-800'
              : 'bg-amber-100 text-amber-800'
          }`}
        >
          <CheckCircle2 className="h-4 w-4" />
          {isDone ? 'Langkah 1 selesai' : 'Belum lengkap'}
        </span>
      </div>

      {!readOnly && (
        <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-600">
          <MousePointerClick className="h-4 w-4 text-blue-600" />
          <span>Klik tombol pada kartu kriteria:</span>
          <span className="inline-flex items-center gap-1 rounded-md bg-emerald-600 px-2 py-0.5 font-semibold text-white">
            <ThumbsUp className="h-3 w-3" /> Best
          </span>
          <span>atau</span>
          <span className="inline-flex items-center gap-1 rounded-md bg-rose-600 px-2 py-0.5 font-semibold text-white">
            <ThumbsDown className="h-3 w-3" /> Worst
          </span>
        </div>
      )}

      {/* Kartu kriteria */}
      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {criteria.map((c) => {
          const isBest = c.id === bestId;
          const isWorst = c.id === worstId;
          const tone = isBest
            ? 'border-emerald-500 bg-emerald-50 ring-2 ring-emerald-200'
            : isWorst
              ? 'border-rose-500 bg-rose-50 ring-2 ring-rose-200'
              : 'border-slate-200 bg-white';
          return (
            <div
              key={c.id}
              className={`flex flex-col justify-between rounded-xl border-2 p-3.5 transition-colors ${tone}`}
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`font-mono text-xl font-bold ${
                      isBest ? 'text-emerald-800' : isWorst ? 'text-rose-800' : 'text-slate-800'
                    }`}
                  >
                    {c.code}
                  </span>
                  {isBest && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                      <ThumbsUp className="h-3 w-3" /> Best
                    </span>
                  )}
                  {isWorst && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-rose-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                      <ThumbsDown className="h-3 w-3" /> Worst
                    </span>
                  )}
                </div>
                <div className="mt-1 text-xs font-semibold leading-snug text-slate-900">
                  {c.name}
                </div>
                <div className="mt-0.5 text-[11px] text-slate-500">
                  {c.type} · {c.unit}
                </div>
              </div>
              {!readOnly && (
                <div className="mt-3 grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => pickBest(c.id)}
                    aria-pressed={isBest}
                    className={`inline-flex items-center justify-center gap-1 rounded-lg border px-2 py-1.5 text-xs font-semibold transition-colors ${
                      isBest
                        ? 'border-emerald-600 bg-emerald-600 text-white'
                        : 'border-emerald-300 bg-white text-emerald-700 hover:bg-emerald-50'
                    }`}
                  >
                    <ThumbsUp className="h-3.5 w-3.5" /> Best
                  </button>
                  <button
                    type="button"
                    onClick={() => pickWorst(c.id)}
                    aria-pressed={isWorst}
                    className={`inline-flex items-center justify-center gap-1 rounded-lg border px-2 py-1.5 text-xs font-semibold transition-colors ${
                      isWorst
                        ? 'border-rose-600 bg-rose-600 text-white'
                        : 'border-rose-300 bg-white text-rose-700 hover:bg-rose-50'
                    }`}
                  >
                    <ThumbsDown className="h-3.5 w-3.5" /> Worst
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Ringkasan pilihan */}
      <div className="mt-4 grid grid-cols-1 items-stretch gap-3 md:grid-cols-[1fr_auto_1fr_auto]">
        <div className="rounded-xl border-2 border-emerald-300 bg-emerald-50/80 px-4 py-3">
          <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-emerald-800">
            <ThumbsUp className="h-3.5 w-3.5" /> Best · Paling Penting
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-emerald-800">
              {best?.code ?? '—'}
            </span>
            <span className="text-sm font-semibold text-slate-800">
              {best?.name ?? 'Belum dipilih'}
            </span>
          </div>
        </div>
        <div className="hidden items-center justify-center md:flex">
          <ArrowRight className="h-5 w-5 text-slate-400" />
        </div>
        <div className="rounded-xl border-2 border-rose-300 bg-rose-50/80 px-4 py-3">
          <div className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-rose-800">
            <ThumbsDown className="h-3.5 w-3.5" /> Worst · Paling Tidak Penting
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-bold text-rose-800">
              {worst?.code ?? '—'}
            </span>
            <span className="text-sm font-semibold text-slate-800">
              {worst?.name ?? 'Belum dipilih'}
            </span>
          </div>
        </div>
        <div className="flex flex-col justify-center rounded-xl border-2 border-blue-200 bg-white px-4 py-3 text-center">
          <div className="text-[11px] font-semibold text-slate-500">Best terhadap Worst</div>
          <div className="font-mono text-2xl font-bold text-slate-900">
            a<sub className="text-sm">BW</sub> = {isDone ? aBW ?? '—' : '—'}
          </div>
        </div>
      </div>
    </section>
  );
}
