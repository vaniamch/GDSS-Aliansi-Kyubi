import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2 } from 'lucide-react';
import type { BWMAssessment, BWMResult, Criterion } from '../types/gdss';

const inRange = (v: unknown) => typeof v === 'number' && v >= 1 && v <= 9;

/** Indikator alur Langkah 1 → 4 Linear BWM beserta status setiap langkah. */
export function BwmStepper({
  criteria,
  assessment,
  result,
}: {
  criteria: Criterion[];
  assessment?: BWMAssessment;
  result?: BWMResult;
}) {
  const s1 = Boolean(
    assessment?.bestCriterionId &&
      assessment.worstCriterionId &&
      assessment.bestCriterionId !== assessment.worstCriterionId
  );
  const s2 = Boolean(assessment && criteria.every((c) => inRange(assessment.bo[c.id])));
  const s3 = Boolean(assessment && criteria.every((c) => inRange(assessment.ow[c.id])));
  const s4 = Boolean(result && !result.error && !result.stale && result.constraintCheckOk);

  const steps = [
    { n: 1, label: 'Best & Worst', ok: s1, anchor: 'bwm-step-1' },
    { n: 2, label: 'Best-to-Others (BO)', ok: s2, anchor: 'bwm-step-2' },
    { n: 3, label: 'Others-to-Worst (OW)', ok: s3, anchor: 'bwm-step-3' },
    { n: 4, label: 'Bobot Optimal', ok: s4, anchor: 'bwm-step-4' },
  ];

  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white p-3">
      <ol className="flex min-w-max items-center gap-2">
        {steps.map((st, i) => (
          <li key={st.n} className="flex items-center gap-2">
            <button
              type="button"
              onClick={() =>
                document.getElementById(st.anchor)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
              }
              className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold whitespace-nowrap ${
                st.n === 1
                  ? 'bg-blue-700 text-white shadow-sm'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span
                className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-bold ${
                  st.n === 1
                    ? 'bg-white text-blue-700'
                    : st.ok
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-200 text-slate-600'
                }`}
              >
                {st.n}
              </span>
              <span>Langkah {st.n} · {st.label}</span>
              {st.ok ? (
                <CheckCircle2 className={`h-4 w-4 ${st.n === 1 ? 'text-emerald-300' : 'text-emerald-600'}`} />
              ) : (
                <AlertTriangle className={`h-4 w-4 ${st.n === 1 ? 'text-amber-300' : 'text-amber-500'}`} />
              )}
            </button>
            {i < steps.length - 1 && <span className="h-px w-6 bg-slate-300" aria-hidden="true" />}
          </li>
        ))}
      </ol>
    </div>
  );
}

/** Input skala 1–9: boleh dikosongkan sementara saat mengetik, nilai disimpan bila valid. */
function ScaleInput({
  value,
  disabled,
  onCommit,
  label,
}: {
  value: number;
  disabled?: boolean;
  onCommit: (v: number) => void;
  label: string;
}) {
  const [draft, setDraft] = useState(String(value));
  useEffect(() => setDraft(String(value)), [value]);
  return (
    <input
      type="number"
      min={1}
      max={9}
      step={1}
      aria-label={label}
      disabled={disabled}
      value={draft}
      onChange={(e) => {
        setDraft(e.target.value);
        const v = Number(e.target.value);
        if (e.target.value !== '' && Number.isInteger(v) && v >= 1 && v <= 9) onCommit(v);
      }}
      onBlur={() => setDraft(String(value))}
      className="w-16 rounded border border-slate-300 px-2 py-1 text-right font-mono tabular-nums focus:border-blue-500 focus:outline-none disabled:bg-slate-100 disabled:text-slate-500"
    />
  );
}

/** Langkah 2 (BO) dan Langkah 3 (OW) berdampingan. */
export function BwmVectorInputs({
  criteria,
  assessment,
  readOnly,
  onBO,
  onOW,
}: {
  criteria: Criterion[];
  assessment: BWMAssessment;
  readOnly: boolean;
  onBO: (critId: string, v: number) => void;
  onOW: (critId: string, v: number) => void;
}) {
  const bestCode = criteria.find((c) => c.id === assessment.bestCriterionId)?.code;
  const worstCode = criteria.find((c) => c.id === assessment.worstCriterionId)?.code;

  const renderTable = (kind: 'bo' | 'ow') => {
    const isBO = kind === 'bo';
    return (
      <div id={isBO ? 'bwm-step-2' : 'bwm-step-3'} className="scroll-mt-6">
        <h3 className="text-xs font-semibold text-slate-800 mb-2">
          <span className="mr-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-800 text-[11px] font-bold text-white">
            {isBO ? 2 : 3}
          </span>
          {isBO ? (
            <>
              Langkah 2 · Best-to-Others (BO): Seberapa penting{' '}
              <span className="font-mono text-emerald-700">{bestCode}</span> dibanding j
            </>
          ) : (
            <>
              Langkah 3 · Others-to-Worst (OW): Seberapa penting j dibanding{' '}
              <span className="font-mono text-rose-700">{worstCode}</span>
            </>
          )}
        </h3>
        <div className="rounded-lg border border-slate-200 overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                <th className="py-2 px-3 text-left font-medium">Kriteria</th>
                <th className="py-2 px-3 text-right font-medium w-24">
                  {isBO ? 'Nilai BO' : 'Nilai OW'}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {criteria.map((c) => {
                const fixed = isBO
                  ? c.id === assessment.bestCriterionId
                  : c.id === assessment.worstCriterionId;
                const val = fixed ? 1 : (isBO ? assessment.bo[c.id] : assessment.ow[c.id]) ?? 1;
                return (
                  <tr key={c.id}>
                    <td className="py-2 px-3">
                      <span className="font-mono font-semibold text-slate-800">{c.code}</span>{' '}
                      <span className="text-slate-600">{c.name}</span>
                    </td>
                    <td className="py-2 px-3 text-right">
                      <ScaleInput
                        label={`${isBO ? 'BO' : 'OW'} ${c.code}`}
                        value={val}
                        disabled={fixed || readOnly}
                        onCommit={(v) => (isBO ? onBO(c.id, v) : onOW(c.id, v))}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
      {renderTable('bo')}
      {renderTable('ow')}
    </div>
  );
}
