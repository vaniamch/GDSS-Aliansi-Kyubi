import React from 'react';
import {
  BarChart3,
  BookOpen,
  Calculator,
  Database,
  GitMerge,
  Home,
  LogOut,
  MessageSquareText,
  RotateCcw,
  Scale,
  SlidersHorizontal,
  Trophy,
  UserRound,
  Users,
  X,
} from 'lucide-react';
import { useGDSS } from '../context/GDSSContext';
import type { PageId } from '../types/gdss';

export interface NavItem {
  id: PageId;
  label: string;
  stepNum?: string;
  icon: React.ComponentType<{ className?: string }>;
}

export const NAV_ITEMS: NavItem[] = [
  { id: 'beranda', label: 'Beranda', icon: Home },
  { id: 'alternatif', label: 'Data Alternatif', stepNum: '1', icon: Database },
  { id: 'kriteria', label: 'Kelola Kriteria', stepNum: '2', icon: SlidersHorizontal },
  { id: 'dm', label: 'Decision Makers', stepNum: '3', icon: Users },
  { id: 'bwm', label: 'Linear BWM Solver', stepNum: '4', icon: Scale },
  { id: 'agregasi', label: 'Agregasi Bobot', stepNum: '5', icon: GitMerge },
  { id: 'marcos', label: 'MARCOS Solver', stepNum: '6', icon: Calculator },
  { id: 'ranking', label: 'Hasil Ranking', stepNum: '7', icon: Trophy },
  { id: 'analisis', label: 'Analisis & Konsensus', stepNum: '8', icon: BarChart3 },
  { id: 'portal', label: 'Halaman DM', icon: UserRound },
  { id: 'diskusi', label: 'Diskusi & Riwayat', icon: MessageSquareText },
  { id: 'panduan', label: 'Panduan Lengkap', icon: BookOpen },
];

/** Halaman yang dapat dibuka akun Decision Maker (halaman pengelolaan data khusus Admin). */
export const DM_ALLOWED_PAGES: PageId[] = ['portal', 'beranda', 'ranking', 'analisis', 'diskusi', 'panduan'];

interface SidebarProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export function Sidebar({
  activePage,
  onNavigate,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const { state, resetAllData, isSaving, session, isAdmin, currentDM, dmAccounts, logout } =
    useGDSS();
  const myAccount = dmAccounts.find((a) => a.dm.id === currentDM?.id);

  // Akun DM: halaman khusus DM tampil paling atas; halaman lain bersifat baca saja.
  // Admin tidak memiliki akses ke Halaman DM (halaman kerja pribadi tiap Decision Maker).
  const navItems: NavItem[] = isAdmin
    ? NAV_ITEMS.filter((n) => n.id !== 'portal')
    : [
        {
          id: 'portal',
          label: `Halaman Saya (${myAccount?.label ?? 'DM'})`,
          icon: UserRound,
        },
        ...NAV_ITEMS.filter((n) => DM_ALLOWED_PAGES.includes(n.id) && n.id !== 'portal'),
      ];

  const datasetLabel =
    state.datasetMode === 'PENELITIAN'
      ? 'Data Penelitian'
      : state.datasetMode === 'DEMO_62'
      ? 'DEMO · 62 Kab.'
      : state.datasetMode === 'DEMO_12'
        ? 'DEMO · 12 Kab.'
        : state.datasetMode === 'KUSTOM'
          ? 'Data Kustom'
          : 'Workspace Kosong';

  const handleNav = (id: PageId) => {
    onNavigate(id);
    onCloseMobile();
  };

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-950/50 lg:hidden"
          onClick={onCloseMobile}
          aria-hidden="true"
        />
      )}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-[264px] flex-col bg-[#0B1528] text-slate-100 border-r border-slate-800/80 transition-transform duration-200 lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        } no-print`}
      >
        <div className="flex items-start justify-between gap-3 px-5 py-5 border-b border-slate-800/80">
          <div>
            <div className="font-display text-base font-bold tracking-tight text-white">
              GDSS BWM + MARCOS
            </div>
            <p className="mt-1 text-xs leading-relaxed text-slate-400">
              Prioritas Pengentasan Kemiskinan Daerah Tertinggal
            </p>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white lg:hidden"
            aria-label="Tutup menu navigasi"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1" aria-label="Menu Utama">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center justify-between gap-2.5 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-300 hover:bg-slate-800/70 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5 min-w-0">
                  <Icon
                    className={`h-4 w-4 shrink-0 ${
                      isActive ? 'text-white' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.stepNum && (
                  <span
                    className={`font-mono text-[11px] tabular-nums shrink-0 ${
                      isActive ? 'text-blue-100' : 'text-slate-500'
                    }`}
                  >
                    0{item.stepNum}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-800/80 px-4 py-4 space-y-3">
          <div className="text-xs text-slate-400 space-y-1">
            <div className="flex items-center justify-between">
              <span>Mode Data</span>
              <span className="font-mono text-slate-200">{datasetLabel}</span>
            </div>
            <div className="flex items-center justify-between">
              <span>Versi State</span>
              <span className="font-mono text-slate-200">
                v{state.version} · {isSaving ? 'Menyimpan...' : 'Tersimpan'}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-2">
            <div className="min-w-0">
              <div className="text-[10px] uppercase tracking-wide text-slate-500">Masuk sebagai</div>
              <div className="truncate text-xs font-semibold text-white">
                {isAdmin
                  ? 'Administrator'
                  : `${myAccount?.label ?? 'DM'} — ${currentDM?.name ?? session?.username}`}
              </div>
            </div>
            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-slate-300 hover:bg-slate-800 hover:text-white shrink-0"
              title="Keluar"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>Keluar</span>
            </button>
          </div>

          <button
            type="button"
            hidden={!isAdmin}
            onClick={() => {
              if (window.confirm('Reset data, pengaturan, dan riwayat ke preset penelitian?')) resetAllData();
            }}
            className="w-full flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-2 text-xs font-medium text-slate-200 hover:bg-slate-800 hover:text-white transition-colors whitespace-nowrap"
          >
            <RotateCcw className="h-3.5 w-3.5 shrink-0" />
            <span>Reset ke Preset Penelitian</span>
          </button>
        </div>
      </aside>
    </>
  );
}
