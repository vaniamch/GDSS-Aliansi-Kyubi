import React from 'react';
import { AlertTriangle, ArrowRight, CheckCircle2, Circle, Clock } from 'lucide-react';
import { useGDSS } from '../context/GDSSContext';
import type { PageId } from '../types/gdss';

interface WorkflowTrackerProps {
  activePage: PageId;
  onNavigate: (page: PageId) => void;
}

type StepStatus = 'done' | 'stale' | 'ready' | 'pending';

interface StepItem {
  id: PageId;
  num: number;
  label: string;
  status: StepStatus;
}

export function WorkflowTracker({ activePage, onNavigate }: WorkflowTrackerProps) {
  const {
    state,
    activeCriteria,
    activeDMs,
    isLambdaValid,
    allDMsAssessed,
    allBWMFreshAndValid,
    isAggregationFresh,
    isMarcosFresh,
    isAdmin,
  } = useGDSS();

  const hasAlts = state.alternatives.length >= 2;
  const hasCrits = activeCriteria.length >= 2;
  const hasDMs = activeDMs.length >= 1 && isLambdaValid;

  const hasAnyStaleBWM = activeDMs.some((d) => state.bwmResults[d.id]?.stale);
  const bwmStatus: StepStatus = allBWMFreshAndValid
    ? 'done'
    : hasAnyStaleBWM
      ? 'stale'
      : allDMsAssessed
        ? 'ready'
        : 'pending';

  const aggStatus: StepStatus = isAggregationFresh
    ? 'done'
    : state.groupAggregation?.stale
      ? 'stale'
      : allBWMFreshAndValid && isLambdaValid
        ? 'ready'
        : 'pending';

  const marcosStatus: StepStatus = isMarcosFresh
    ? 'done'
    : state.marcosResult?.stale
      ? 'stale'
      : isAggregationFresh && hasAlts
        ? 'ready'
        : 'pending';

  const steps: StepItem[] = [
    { id: 'alternatif', num: 1, label: 'Data Alternatif', status: hasAlts ? 'done' : 'pending' },
    { id: 'kriteria', num: 2, label: 'Kriteria', status: hasCrits ? 'done' : 'pending' },
    { id: 'dm', num: 3, label: 'Decision Makers', status: hasDMs ? 'done' : 'pending' },
    {
      id: 'bwm',
      num: 4,
      label: 'Penilaian & Solver BWM',
      status: bwmStatus,
    },
    { id: 'agregasi', num: 5, label: 'Agregasi Bobot', status: aggStatus },
    { id: 'marcos', num: 6, label: 'MARCOS Solver', status: marcosStatus },
    {
      id: 'ranking',
      num: 7,
      label: 'Ranking Akhir',
      status: isMarcosFresh ? 'done' : marcosStatus === 'stale' ? 'stale' : 'pending',
    },
    {
      id: 'analisis',
      num: 8,
      label: 'Analisis & Konsensus',
      status: isMarcosFresh ? 'done' : marcosStatus === 'stale' ? 'stale' : 'pending',
    },
  ];

  // Determine clear next-step recommendation
  let nextPage: PageId = 'alternatif';
  let nextMessage = '';
  let nextBtnLabel = 'Lanjutkan';
  let isWarning = false;

  if (!hasAlts) {
    nextPage = 'alternatif';
    nextMessage =
      'Langkah 1: Tambahkan minimal 2 alternatif kabupaten (atau muat Dataset DEMO / import CSV-Excel).';
    nextBtnLabel = 'Buka Data Alternatif';
  } else if (!hasCrits) {
    nextPage = 'kriteria';
    nextMessage = 'Langkah 2: Pastikan minimal 2 kriteria aktif tersedia dan bertipe Benefit/Cost.';
    nextBtnLabel = 'Kelola Kriteria';
  } else if (!hasDMs) {
    nextPage = 'dm';
    nextMessage =
      'Langkah 3: Pastikan minimal 1 Decision Maker aktif dan total bobot kepentingan Σλ = 1,0000.';
    nextBtnLabel = 'Perbaiki Bobot DM';
    isWarning = true;
  } else if (!allDMsAssessed) {
    nextPage = 'bwm';
    nextMessage =
      'Langkah 4: Menunggu setiap DM aktif melengkapi pilihan Best, Worst, serta vektor BO dan OW (skala 1–9) melalui akunnya masing-masing.';
    nextBtnLabel = 'Tinjau Penilaian BWM';
  } else if (!allBWMFreshAndValid) {
    nextPage = 'bwm';
    nextMessage =
      'Perhatian: Ada penilaian BWM yang belum valid (mis. Best = Worst atau nilai di luar 1–9). Bobot langsung dihitung otomatis setelah diperbaiki.';
    nextBtnLabel = 'Periksa Penilaian BWM';
    isWarning = true;
  } else if (!isAggregationFresh) {
    nextPage = 'agregasi';
    nextMessage =
      'Perhatian: Bobot kelompok belum dapat dihitung otomatis — periksa Σλ dan hasil Linear BWM setiap DM.';
    nextBtnLabel = 'Buka Agregasi';
    isWarning = true;
  } else if (!isMarcosFresh) {
    nextPage = 'marcos';
    nextMessage =
      'Perhatian: MARCOS belum dapat dihitung otomatis — periksa validasi matriks keputusan (mis. nilai kriteria Cost ≤ 0).';
    nextBtnLabel = 'Periksa MARCOS';
    isWarning = true;
  } else {
    nextPage = 'ranking';
    nextMessage =
      'Seluruh perhitungan diperbarui otomatis (real-time) dan valid. Lihat Hasil Ranking Akhir, Analisis Konsensus antar-DM, atau Export Laporan.';
    nextBtnLabel = 'Lihat Ranking Akhir';
  }

  const renderStatusIcon = (status: StepStatus) => {
    if (status === 'done') return <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 shrink-0" />;
    if (status === 'stale') return <AlertTriangle className="h-3.5 w-3.5 text-amber-600 shrink-0" />;
    if (status === 'ready') return <Clock className="h-3.5 w-3.5 text-blue-600 shrink-0" />;
    return <Circle className="h-3.5 w-3.5 text-slate-300 shrink-0" />;
  };

  return (
    <div className="mb-6 space-y-3 no-print">
      <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white p-2.5">
        <div className="flex items-center gap-1.5 min-w-max">
          {steps.map((step, idx) => {
            const isCurrent = activePage === step.id;
            return (
              <React.Fragment key={step.id}>
                <button
                  type="button"
                  onClick={() => onNavigate(step.id)}
                  className={`flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    isCurrent
                      ? 'bg-blue-50 text-blue-800 border border-blue-200'
                      : 'text-slate-700 hover:bg-slate-50 border border-transparent'
                  }`}
                >
                  {renderStatusIcon(step.status)}
                  <span className="font-mono text-[11px] text-slate-400">0{step.num}</span>
                  <span>{step.label}</span>
                </button>
                {idx < steps.length - 1 && (
                  <ArrowRight className="h-3.5 w-3.5 text-slate-300 shrink-0" />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      <div
        className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-2.5 text-xs ${
          isWarning
            ? 'border-amber-200 bg-amber-50/70 text-amber-900'
            : 'border-blue-100 bg-blue-50/60 text-slate-700'
        }`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          {isWarning ? (
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
          ) : (
            <CheckCircle2 className="h-4 w-4 text-blue-600 shrink-0" />
          )}
          <span className="leading-relaxed">
            {!isAdmin && nextPage !== 'ranking' ? 'Menunggu Admin — ' : ''}
            {nextMessage}
          </span>
        </div>
        {activePage !== nextPage && (
          <button
            type="button"
            onClick={() => onNavigate(nextPage)}
            className={`inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              isWarning
                ? 'bg-amber-600 text-white hover:bg-amber-700'
                : 'bg-blue-700 text-white hover:bg-blue-800'
            }`}
          >
            <span>{nextBtnLabel}</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </div>
  );
}
