import React from 'react';
import { Lock, Zap } from 'lucide-react';

/** Penanda bahwa hasil pada halaman dihitung ulang otomatis (real-time) setiap input berubah. */
export function AutoCalcBadge({ label = 'Real-time · dihitung otomatis' }: { label?: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-800 whitespace-nowrap"
      title="Setiap perubahan nilai langsung memperbarui Linear BWM, agregasi bobot, dan MARCOS tanpa tombol hitung ulang."
    >
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
      </span>
      <Zap className="h-3.5 w-3.5" />
      <span>{label}</span>
    </span>
  );
}

/** Banner mode baca untuk akun Decision Maker (input nilai hanya oleh Admin). */
export function ReadOnlyNotice({ text }: { text?: string }) {
  return (
    <div className="flex items-start gap-2.5 rounded-xl border border-slate-300 bg-slate-50 px-4 py-3 text-xs text-slate-700 no-print">
      <Lock className="h-4 w-4 text-slate-500 shrink-0 mt-0.5" />
      <span>
        <span className="font-semibold">Mode baca.</span>{' '}
        {text ??
          'Hanya Admin yang dapat menginput dan mengubah nilai. Tampilan ini ikut diperbarui otomatis saat Admin mengubah data.'}
      </span>
    </div>
  );
}
