import React from 'react';
import { AlertTriangle, CheckCircle2, Clock } from 'lucide-react';

export interface PageHeaderProps {
  title: string;
  description: string;
  statusLabel: string;
  statusTone?: 'ok' | 'warning' | 'pending' | 'info';
  actions?: React.ReactNode;
}

export function PageHeader({
  title,
  description,
  statusLabel,
  statusTone = 'info',
  actions,
}: PageHeaderProps) {
  const toneClasses = {
    ok: 'text-emerald-700',
    warning: 'text-amber-700',
    pending: 'text-slate-600',
    info: 'text-blue-700',
  }[statusTone];

  const StatusIcon =
    statusTone === 'ok'
      ? CheckCircle2
      : statusTone === 'warning'
        ? AlertTriangle
        : Clock;

  return (
    <div className="mb-6 flex flex-col gap-4 border-b border-slate-200 pb-5 md:flex-row md:items-end md:justify-between">
      <div className="space-y-1.5 max-w-3xl">
        <div className={`inline-flex items-center gap-1.5 text-xs font-medium ${toneClasses}`}>
          <StatusIcon className="h-3.5 w-3.5 shrink-0" />
          <span>{statusLabel}</span>
        </div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-slate-900">
          {title}
        </h1>
        <p className="text-sm leading-relaxed text-slate-600">{description}</p>
      </div>
      {actions && (
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">{actions}</div>
      )}
    </div>
  );
}
