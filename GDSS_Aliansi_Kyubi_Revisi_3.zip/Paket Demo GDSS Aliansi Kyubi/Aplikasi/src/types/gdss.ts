export type CriterionType = 'Benefit' | 'Cost';

export interface Criterion {
  id: string;
  code: string;
  name: string;
  description: string;
  unit: string;
  type: CriterionType;
  active: boolean;
}

export interface Alternative {
  id: string;
  name: string;
  province: string;
  values: Record<string, number>;
  isDemo?: boolean;
}

export interface DecisionMaker {
  id: string;
  name: string;
  perspective: string;
  institution: string;
  lambda: number;
  active: boolean;
}

export interface BWMAssessment {
  dmId: string;
  bestCriterionId: string;
  worstCriterionId: string;
  bo: Record<string, number>;
  ow: Record<string, number>;
  updatedAt: string;
  /** Akun yang terakhir mengubah penilaian (mis. "Admin" atau "DM 1 — Jeno"). */
  updatedBy?: string;
}

export interface BWMResult {
  dmId: string;
  weights: Record<string, number>;
  xi: number;
  cri: number;
  threshold: number;
  isConsistent: boolean;
  constraintCheckOk: boolean;
  maxResidual: number;
  totalWeight: number;
  computedAt: string;
  stale: boolean;
  error?: string;
}

export interface GroupAggregationResult {
  weights: Record<string, number>;
  geoMeans: Record<string, number>;
  geoMeanSum: number;
  cv: Record<string, number>;
  stdDev: Record<string, number>;
  mean: Record<string, number>;
  highestAgreementCode: string;
  highestDisagreementCode: string;
  computedAt: string;
  stale: boolean;
}

export interface MARCOSAlternativeRow {
  alternativeId: string;
  name: string;
  province: string;
  rawValues: Record<string, number>;
  normalizedValues: Record<string, number>;
  weightedValues: Record<string, number>;
  si: number;
  kMinus: number;
  kPlus: number;
  fKMinus: number;
  fKPlus: number;
  fK: number;
  rank: number;
  severityIndex: Record<string, number>;
  mostCriticalCriterionCode: string;
  mostCriticalCriterionName: string;
  recommendedProgram: string;
}

export interface MARCOSResult {
  aai: Record<string, number>;
  ai: Record<string, number>;
  nAai: Record<string, number>;
  nAi: Record<string, number>;
  vAai: Record<string, number>;
  vAi: Record<string, number>;
  sAai: number;
  sAi: number;
  rows: MARCOSAlternativeRow[];
  computedAt: string;
  stale: boolean;
  warnings: string[];
}

export interface ComparisonResult {
  sawRanks: Record<string, { score: number; rank: number }>;
  topsisRanks: Record<string, { dPlus: number; dMinus: number; cc: number; rank: number }>;
  spearmanMarcosTopsis: number;
  spearmanMarcosSaw: number;
  spearmanTopsisSaw: number;
}

export interface ConsensusAnalysisResult {
  dmRankings: Record<string, Record<string, { fK: number; rank: number }>>;
  spearmanMatrix: {
    labels: string[];
    values: number[][];
  };
  kendallsW: number;
  alternativeRanges: {
    alternativeId: string;
    name: string;
    province: string;
    ranksByDm: Record<string, number>;
    groupRank: number;
    minRank: number;
    maxRank: number;
    range: number;
  }[];
  mostDebated: { name: string; range: number; groupRank: number }[];
  mostAgreed: { name: string; range: number; groupRank: number }[];
}

export interface SensitivityScenario {
  id: string;
  name: string;
  description: string;
  weights: Record<string, number>;
  spearmanVsBase: number;
  rank1Name: string;
  top5Retained: number;
  top10Retained: number;
  maxRankShift: number;
}

export interface DiscussionNote {
  id: string;
  author: string;
  dmId?: string;
  category: 'Catatan' | 'Keputusan' | 'Validasi';
  content: string;
  createdAt: string;
}

export interface HistoryEntry {
  id: string;
  timestamp: string;
  category: 'data' | 'criteria' | 'dm' | 'bwm' | 'aggregation' | 'marcos' | 'system';
  action: string;
  summary: string;
  version: number;
}

export type PageId =
  | 'beranda'
  | 'alternatif'
  | 'kriteria'
  | 'dm'
  | 'bwm'
  | 'agregasi'
  | 'marcos'
  | 'ranking'
  | 'analisis'
  | 'diskusi'
  | 'panduan'
  | 'portal';

export type UserRole = 'admin' | 'dm';

export interface UserSession {
  role: UserRole;
  /** Terisi bila role = 'dm' (id Decision Maker yang login). */
  dmId?: string;
  username: string;
  loggedInAt: string;
}

export type DatasetMode = 'PENELITIAN' | 'DEMO_62' | 'DEMO_12' | 'KUSTOM' | 'KOSONG';

export interface GDSSState {
  version: number;
  datasetMode: DatasetMode;
  crThreshold: number;
  sensitivityPct: number;
  sensitivityCriterionId: string;
  criteria: Criterion[];
  alternatives: Alternative[];
  decisionMakers: DecisionMaker[];
  bwmAssessments: Record<string, BWMAssessment>;
  bwmResults: Record<string, BWMResult>;
  groupAggregation: GroupAggregationResult | null;
  marcosResult: MARCOSResult | null;
  discussions: DiscussionNote[];
  history: HistoryEntry[];
}
