import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { STUDY_SOURCE } from '../data/demoPresets';
import type {
  Alternative,
  Criterion,
  DatasetMode,
  DecisionMaker,
  GroupAggregationResult,
  MARCOSResult,
} from '../types/gdss';

export function exportAlternativesToExcel(
  alternatives: Alternative[],
  criteria: Criterion[],
  filename = 'Data_Alternatif_GDSS.xlsx'
) {
  const rows = alternatives.map((alt, idx) => {
    const row: Record<string, string | number> = {
      No: idx + 1,
      Kabupaten: alt.name,
      Provinsi: alt.province,
    };
    criteria.forEach((c) => {
      row[`${c.code} (${c.name})`] = alt.values[c.id] ?? '';
    });
    return row;
  });

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Data_Alternatif');
  XLSX.writeFile(wb, filename);
}

export function exportAlternativesToCSV(
  alternatives: Alternative[],
  criteria: Criterion[],
  filename = 'Data_Alternatif_GDSS.csv'
) {
  const headers = ['Kabupaten', 'Provinsi', ...criteria.map((c) => c.code)];
  const lines = [
    headers.join(','),
    ...alternatives.map((alt) =>
      [
        `"${alt.name.replace(/"/g, '""')}"`,
        `"${alt.province.replace(/"/g, '""')}"`,
        ...criteria.map((c) => alt.values[c.id] ?? ''),
      ].join(',')
    ),
  ];
  const blob = new Blob([lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function parseLocalizedNumber(raw: unknown): number | null {
  if (typeof raw === 'number') return Number.isFinite(raw) ? raw : null;
  if (typeof raw === 'string') {
    const trimmed = raw.trim().replace(/\s+/g, '');
    if (!trimmed) return null;
    // Handle Indonesian thousands/decimal formatting or standard decimal
    let normalized = trimmed;
    if (trimmed.includes(',') && trimmed.includes('.')) {
      if (trimmed.lastIndexOf(',') > trimmed.lastIndexOf('.')) {
        normalized = trimmed.replace(/\./g, '').replace(',', '.');
      } else {
        normalized = trimmed.replace(/,/g, '');
      }
    } else if (trimmed.includes(',')) {
      normalized = trimmed.replace(',', '.');
    }
    const num = Number(normalized);
    return Number.isFinite(num) ? num : null;
  }
  return null;
}

export async function parseImportedFile(
  file: File,
  criteria: Criterion[]
): Promise<Alternative[]> {
  const buffer = await file.arrayBuffer();
  const wb = XLSX.read(buffer, { type: 'array', raw: true });
  const studySheet = wb.SheetNames.find((name) => name.trim().toLowerCase() === 'data_3t');
  const sheetName = studySheet ?? wb.SheetNames[0];
  if (!sheetName) {
    throw new Error('File tidak memiliki sheet data.');
  }
  const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[sheetName], {
    range: studySheet ? 3 : 0,
    raw: true,
    defval: '',
  });

  if (rawRows.length === 0) {
    throw new Error('File kosong atau tidak memiliki baris data.');
  }

  const alternatives: Alternative[] = [];
  const seen = new Set<string>();
  const importId = Date.now();

  const sampleKeys = Object.keys(rawRows[0]);
  const findKey = (candidates: string[]) =>
    sampleKeys.find((k) =>
      candidates.some((cand) => k.toLowerCase().trim().includes(cand.toLowerCase()))
    );

  const nameKey =
    findKey(['kabupaten', 'kota']) ?? findKey(['daerah', 'nama', 'alternatif']);
  const provKey = findKey(['provinsi', 'propinsi', 'province']);
  if (!nameKey || !provKey || nameKey === provKey) {
    throw new Error('Header Kabupaten dan Provinsi wajib tersedia.');
  }

  const critKeyMap: Record<string, string | undefined> = {};
  criteria.forEach((c) => {
    const match = sampleKeys.find((k) => {
      const kl = k.toLowerCase().trim();
      return (
        kl === c.code.toLowerCase() ||
        kl.startsWith(`${c.code.toLowerCase()} `) ||
        kl.startsWith(`${c.code.toLowerCase()}(`) ||
        kl.includes(c.name.toLowerCase())
      );
    });
    critKeyMap[c.id] = match;
    if (!match && c.active) {
      throw new Error(`Kolom ${c.code} (${c.name}) tidak ditemukan.`);
    }
  });

  rawRows.forEach((row, idx) => {
    const rowNumber = Number(row.__rowNum__ ?? idx + (studySheet ? 4 : 1)) + 1;
    const rawName = String(row[nameKey] ?? '').replace(/\*/g, '').trim();
    const rawProv = String(row[provKey] ?? '').trim();
    if (studySheet && rawProv.toLowerCase() === 'jumlah alternatif terfilter:') return;
    if (!rawName || !rawProv) {
      throw new Error(`Baris ${rowNumber}: nama kabupaten dan provinsi wajib diisi.`);
    }
    const key = JSON.stringify([rawName.toLowerCase(), rawProv.toLowerCase()]);
    if (seen.has(key)) {
      throw new Error(`Baris ${rowNumber}: ${rawName}, ${rawProv} tercantum lebih dari sekali.`);
    }
    seen.add(key);
    const values: Record<string, number> = {};

    for (const c of criteria) {
      const col = critKeyMap[c.id];
      const parsed = col ? parseLocalizedNumber(row[col]) : null;
      if (parsed === null || (c.type === 'Cost' ? parsed <= 0 : parsed < 0)) {
        if (!c.active) continue;
        const rule = c.type === 'Cost' ? 'angka lebih dari 0' : 'angka 0 atau lebih';
        throw new Error(`Baris ${rowNumber} (${rawName}): nilai ${c.code} harus ${rule}.`);
      }
      values[c.id] = parsed;
    }

    alternatives.push({
      id: `imp-${importId}-${idx}`,
      name: rawName,
      province: rawProv,
      isDemo: false,
      values,
    });
  });

  if (alternatives.length === 0) {
    throw new Error('Tidak ada baris alternatif valid yang dapat dibaca dari file.');
  }

  return alternatives;
}

function rankingSource(datasetMode: DatasetMode) {
  if (datasetMode === 'PENELITIAN') return STUDY_SOURCE;
  return datasetMode.startsWith('DEMO') ? 'DEMO (Simulasi)' : 'Data Kustom';
}

export function exportRankingToExcel(
  marcos: MARCOSResult,
  criteria: Criterion[],
  groupAgg: GroupAggregationResult,
  decisionMakers: DecisionMaker[],
  datasetMode: DatasetMode
) {
  const wb = XLSX.utils.book_new();

  const rankingSheetData = marcos.rows.map((r) => ({
    Ranking: r.rank,
    Kabupaten: r.name,
    Provinsi: r.province,
    'Skor Si': Number(r.si.toFixed(6)),
    'Ki-': Number(r.kMinus.toFixed(6)),
    'Ki+': Number(r.kPlus.toFixed(6)),
    'Nilai Utilitas f(Ki)': Number(r.fK.toFixed(6)),
    'Kriteria Paling Kritis': `${r.mostCriticalCriterionCode} - ${r.mostCriticalCriterionName}`,
    'Program Disarankan': r.recommendedProgram,
    Sumber: rankingSource(datasetMode),
  }));
  XLSX.utils.book_append_sheet(
    wb,
    XLSX.utils.json_to_sheet(rankingSheetData),
    'Hasil_Ranking'
  );

  const weightsData = criteria.map((c) => ({
    Kode: c.code,
    Kriteria: c.name,
    Tipe: c.type,
    Satuan: c.unit,
    'Bobot Kelompok (Wj)': Number((groupAgg.weights[c.id] ?? 0).toFixed(6)),
    'Koefisien Variasi (CV)': Number((groupAgg.cv[c.id] ?? 0).toFixed(4)),
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(weightsData), 'Bobot_Kelompok');

  const dmData = decisionMakers.map((dm) => ({
    Nama: dm.name,
    Perspektif: dm.perspective,
    Instansi: dm.institution,
    'Bobot Lambda': dm.lambda,
    Status: dm.active ? 'Aktif' : 'Nonaktif',
  }));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(dmData), 'Decision_Makers');

  XLSX.writeFile(wb, 'Laporan_Ranking_GDSS_BWM_MARCOS.xlsx');
}

export function exportRankingToPDF(
  marcos: MARCOSResult,
  criteria: Criterion[],
  groupAgg: GroupAggregationResult,
  datasetMode: DatasetMode
) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  doc.setFontSize(13);
  doc.text('LAPORAN PRIORITAS INTERVENSI PENGENTASAN KEMISKINAN', 14, 16);
  doc.setFontSize(10);
  doc.text('Metode: Linear Best-Worst Method (BWM) + MARCOS (Group DSS)', 14, 22);
  doc.setFontSize(8.5);
  doc.setTextColor(90);
  const modeLabel = `Sumber data: ${rankingSource(datasetMode)}`;
  doc.text(
    `${modeLabel}  |  Dicetak: ${new Date().toLocaleString('id-ID')}  |  Total Alternatif: ${marcos.rows.length}`,
    14,
    27
  );
  doc.setTextColor(0);

  autoTable(doc, {
    startY: 32,
    head: [['Kode', 'Kriteria', 'Tipe', 'Bobot Kelompok', 'CV']],
    body: criteria.map((c) => [
      c.code,
      c.name,
      c.type,
      (groupAgg.weights[c.id] ?? 0).toFixed(4),
      (groupAgg.cv[c.id] ?? 0).toFixed(2),
    ]),
    styles: { fontSize: 7.5, cellPadding: 1.8 },
    headStyles: { fillColor: [15, 23, 42] },
  });

  const finalY = (doc as unknown as { lastAutoTable?: { finalY: number } }).lastAutoTable?.finalY ?? 85;

  autoTable(doc, {
    startY: finalY + 6,
    head: [['Rank', 'Kabupaten', 'Provinsi', 'Si', 'f(Ki)', 'Paling Kritis', 'Rekomendasi Program']],
    body: marcos.rows.map((r) => [
      r.rank,
      r.name,
      r.province,
      r.si.toFixed(4),
      r.fK.toFixed(4),
      r.mostCriticalCriterionCode,
      r.recommendedProgram,
    ]),
    styles: { fontSize: 7.5, cellPadding: 1.8 },
    headStyles: { fillColor: [29, 78, 216] },
  });

  doc.save('Laporan_Ranking_GDSS_BWM_MARCOS.pdf');
}
