import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as XLSX from 'xlsx';
import { createPresetState } from '../src/data/demoPresets';
import {
  computeComparisonMethods,
  computeConsensusAnalysis,
  computeMARCOS,
  computeSensitivityAnalysis,
} from '../src/engine/mcdmEngine';
import { parseImportedFile } from '../src/utils/exportUtils';

const { alternatives, criteria, decisionMakers, bwmResults, groupAggregation, marcosResult } =
  createPresetState('PENELITIAN');
assert.ok(groupAggregation && marcosResult);
assert.equal(alternatives.length, 62);
assert.deepEqual(
  marcosResult.rows.slice(0, 5).map((row) => row.name),
  ['Nduga', 'Mamberamo Tengah', 'Lanny Jaya', 'Intan Jaya', 'Tolikara'],
);
assert.equal(marcosResult.rows[0].fK.toFixed(4), '0.7664');
assert.equal(marcosResult.rows[0].mostCriticalCriterionCode, 'C2');

const { weights } = groupAggregation;
const comparison = computeComparisonMethods(alternatives, criteria, weights, marcosResult);
assert.equal(comparison?.spearmanMarcosTopsis.toFixed(4), '0.9423');
assert.equal(comparison?.spearmanMarcosSaw, 1);
const consensus = computeConsensusAnalysis(alternatives, criteria, decisionMakers, bwmResults, marcosResult);
assert.equal(consensus?.kendallsW.toFixed(4), '0.9378');
const scenarios = computeSensitivityAnalysis(
  alternatives, criteria, decisionMakers, bwmResults, weights, marcosResult, 'c1', 20,
);
assert.deepEqual(scenarios.map((s) => s.maxRankShift), [0, 11, 19, 7, 13, 4, 6, 6]);
assert.equal(scenarios.filter((s) => s.rank1Name === 'Nduga').length, 8);

const headers = ['Kabupaten', 'Provinsi', ...criteria.map((c) => c.code)];
const sample = ['Nduga', 'Papua', 37.18, 1.42, 3976, 55.43, 95.65, 86.65, 0, 815251];
function csvFile(...rows: (string | number)[][]) {
  return new File([rows.map((row) => row.join(',')).join('\n')], 'uji.csv');
}
const [csvAlternative] = await parseImportedFile(csvFile(headers, sample), criteria);
assert.equal(csvAlternative.values.c7, 0);
const localized = new File([headers.join(';') + '\n' + ['Nduga', 'Papua', '37,18', ...sample.slice(3)].join(';')], 'lokal.csv');
assert.equal((await parseImportedFile(localized, criteria))[0].values.c1, 37.18);
const missingValue = [...sample];
missingValue[3] = '';
await assert.rejects(parseImportedFile(csvFile(headers, missingValue), criteria), /Baris 2 .*C2/);
const zeroCost = [...sample];
zeroCost[3] = 0;
await assert.rejects(parseImportedFile(csvFile(headers, zeroCost), criteria), /Baris 2 .*C2/);
await assert.rejects(parseImportedFile(csvFile(headers.slice(0, -1), sample.slice(0, -1)), criteria), /Kolom C8/);
await assert.rejects(parseImportedFile(csvFile(headers, sample, sample), criteria), /lebih dari sekali/);

const workbookPath = process.argv[2];
if (workbookPath) {
  const buffer = readFileSync(workbookPath);
  const imported = await parseImportedFile(new File([buffer], 'Aliansi Kyubi Project 2.xlsx'), criteria);
  assert.equal(imported.length, 62);
  assert.deepEqual(
    imported.map(({ name, province, values }) => [name, province.toUpperCase(), values]),
    alternatives.map(({ name, province, values }) => [name, province.toUpperCase(), values]),
  );

  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const ranking = XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets.Ranking, { header: 1, range: 'A5:J66' });
  const importedRanking = computeMARCOS(imported, criteria, weights).result;
  assert.equal(importedRanking?.rows.length, ranking.length);
  importedRanking.rows.forEach((row, i) => {
    const [rank, name, , , , , score, criterion, , program] = ranking[i];
    assert.equal(row.rank, rank);
    assert.equal(row.name, name);
    assert.equal(row.mostCriticalCriterionCode, criterion);
    assert.equal(row.recommendedProgram, program);
    assert.ok(Math.abs(row.fK - Number(score)) < 1e-8, row.name);
  });
  console.log('Impor workbook dan 62 baris ranking cocok.');
}
console.log('Preset penelitian, analisis, dan validasi impor lulus.');
