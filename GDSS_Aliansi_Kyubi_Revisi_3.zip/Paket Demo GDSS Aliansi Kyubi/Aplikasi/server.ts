import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';

const PORT = 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'gdss_state.json');

async function ensureDataDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

async function readStoredState(): Promise<unknown | null> {
  try {
    const raw = await fs.readFile(DB_FILE, 'utf8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function writeStoredState(payload: unknown): Promise<void> {
  await ensureDataDir();
  const tmpFile = `${DB_FILE}.tmp`;
  await fs.writeFile(tmpFile, JSON.stringify(payload, null, 2), 'utf8');
  await fs.rename(tmpFile, DB_FILE);
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, timestamp: new Date().toISOString() });
  });

  app.get('/api/state', async (_req, res) => {
    const state = await readStoredState();
    res.json({ state });
  });

  app.put('/api/state', async (req, res) => {
    try {
      const { state } = req.body as { state?: unknown };
      if (!state || typeof state !== 'object') {
        res.status(400).json({ error: 'Payload state tidak valid.' });
        return;
      }
      await writeStoredState(state);
      res.json({ ok: true, savedAt: new Date().toISOString() });
    } catch (err) {
      console.error('Failed to persist GDSS state:', err);
      res.status(500).json({ error: 'Gagal menyimpan state ke database lokal server.' });
    }
  });

  app.delete('/api/state', async (_req, res) => {
    try {
      await fs.rm(DB_FILE, { force: true });
      res.json({ ok: true });
    } catch (err) {
      console.error('Failed to reset state:', err);
      res.status(500).json({ error: 'Gagal menghapus state tersimpan.' });
    }
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*all', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GDSS Linear BWM + MARCOS server listening on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Server failed to start:', err);
  process.exit(1);
});
